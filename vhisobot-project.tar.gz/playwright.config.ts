import { defineConfig, devices } from "@playwright/test";

const apiBaseURL =
  process.env.E2E_API_URL ?? "http://127.0.0.1:18081";
const webBaseURL =
  process.env.E2E_WEB_URL ??
  process.env.E2E_BASE_URL ??
  "http://127.0.0.1:24446";
const mobileBaseURL =
  process.env.E2E_MOBILE_URL ??
  "http://127.0.0.1:18393";

const isLocalURL = (url: string): boolean =>
  url.startsWith("http://127.0.0.1:") || url.startsWith("http://localhost:");

// The auth fixture reads this value directly so it can mint sessions before a
// browser page is loaded. Keep the default local URL in sync with webServer.
process.env.E2E_API_URL ??= apiBaseURL;

const webServers = [
  isLocalURL(apiBaseURL)
    ? {
        command:
          "pnpm --filter @workspace/api-server run build && NODE_ENV=test PORT=18081 pnpm --filter @workspace/api-server run start",
        url: `${apiBaseURL}/api/healthz`,
        timeout: 120_000,
        reuseExistingServer: false,
      }
    : null,
  isLocalURL(webBaseURL)
    ? {
        command:
          `NODE_ENV=test E2E_API_URL=${apiBaseURL} PORT=24446 BASE_PATH=/ pnpm --filter @workspace/debt-web run dev`,
        url: webBaseURL,
        timeout: 120_000,
        reuseExistingServer: false,
      }
    : null,
  isLocalURL(mobileBaseURL)
    ? {
        command:
          `NODE_ENV=development EXPO_PUBLIC_API_URL=${apiBaseURL} PORT=18393 pnpm --filter @workspace/debt-mobile exec expo start --web --localhost --port 18393`,
        url: mobileBaseURL,
        timeout: 180_000,
        reuseExistingServer: false,
      }
    : null,
].filter((server): server is NonNullable<typeof server> => server !== null);

export default defineConfig({
  testDir: "./tests",
  timeout: 30_000,
  fullyParallel: true,
  forbidOnly: Boolean(process.env.CI),
  retries: process.env.CI ? 2 : 0,
  reporter: process.env.CI ? "github" : "list",
  use: {
    baseURL: webBaseURL,
    trace: "retain-on-failure",
    screenshot: "only-on-failure",
  },
  outputDir: "test-results",
  webServer: webServers,
  projects: [
    {
      name: "web",
      testMatch: /web\/.*\.spec\.ts/,
      use: { ...devices["Desktop Chrome"], baseURL: webBaseURL },
    },
    {
      name: "mobile-web",
      testMatch: /mobile\/.*\.spec\.ts/,
      use: { ...devices["Pixel 7"], baseURL: mobileBaseURL },
    },
  ],
});