import './_group.css';
import { BookOpen } from 'lucide-react';
import { useState } from 'react';

// ---------------------------------------------------------------------------
// Standalone color constants (from artifacts/debt-mobile/constants/colors.ts)
// ---------------------------------------------------------------------------
const C = {
  background: '#fdfbf8',
  foreground: '#20302b',
  card: '#fffdfb',
  primary: '#2e6b5d',
  primaryForeground: '#fdfbf8',
  mutedForeground: '#687873',
  accent: '#f0e0d0',
  border: '#e9e6e2',
  input: '#e9e6e2',
  destructive: '#b83c2e',
  radius: 8,
} as const;

// ---------------------------------------------------------------------------
// Inlined PrimaryButton (from artifacts/debt-mobile/components/finance-ui.tsx)
// ---------------------------------------------------------------------------
function PrimaryButton({
  label,
  onPress,
  disabled,
}: {
  label: string;
  onPress: () => void;
  disabled?: boolean;
}) {
  const [pressed, setPressed] = useState(false);
  return (
    <button
      disabled={disabled}
      onMouseDown={() => setPressed(true)}
      onMouseUp={() => setPressed(false)}
      onMouseLeave={() => setPressed(false)}
      onClick={onPress}
      style={{
        minHeight: 50,
        paddingLeft: 18,
        paddingRight: 18,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        flexDirection: 'row',
        gap: 8,
        backgroundColor: C.primary,
        borderRadius: C.radius,
        opacity: disabled ? 0.45 : pressed ? 0.82 : 1,
        border: 'none',
        cursor: disabled ? 'not-allowed' : 'pointer',
        width: '100%',
      }}
    >
      <span
        style={{
          fontSize: 15,
          fontWeight: 700,
          color: C.primaryForeground,
          fontFamily: 'inherit',
        }}
      >
        {label}
      </span>
    </button>
  );
}

// ---------------------------------------------------------------------------
// Main preview component — 402 × 874 mobile frame
// ---------------------------------------------------------------------------
export function Current() {
  // Stubbed state — no real auth or API calls
  const [code, setCode] = useState('');
  const [pin, setPin] = useState('');
  const error = ''; // static; no API

  const handleSubmit = () => {
    // no-op: standalone preview
  };

  const isPending = false;
  const isDisabled = !code.trim() || isPending;

  return (
    /* Outer centering wrapper so the frame floats nicely on the canvas */
    <div className="mobile-signin-root min-h-screen flex items-center justify-center bg-neutral-200">
      {/* ── Mobile device frame 402 × 874 ── */}
      <div
        style={{
          width: 402,
          height: 874,
          backgroundColor: C.background,
          borderRadius: 40,
          boxShadow: '0 24px 80px rgba(0,0,0,0.22), 0 2px 8px rgba(0,0,0,0.12)',
          overflow: 'hidden',
          display: 'flex',
          flexDirection: 'column',
          position: 'relative',
        }}
      >
        {/* Scrollable content — mirrors KeyboardAwareScrollViewCompat */}
        <div
          style={{
            flex: 1,
            overflowY: 'auto',
            backgroundColor: C.background,
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'center',
            paddingLeft: 24,
            paddingRight: 24,
            paddingTop: 44,
            paddingBottom: 44,
            gap: 14,
            fontFamily:
              '"Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
          }}
        >
          {/* ── Mark / logo circle ── */}
          <div
            style={{
              width: 62,
              height: 62,
              borderRadius: 31,
              backgroundColor: C.accent,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              flexShrink: 0,
            }}
          >
            <BookOpen size={31} color={C.primary} strokeWidth={2} />
          </div>

          {/* ── Title ── */}
          <p
            style={{
              fontSize: 41,
              lineHeight: '43px',
              fontWeight: 700,
              letterSpacing: -1.5,
              color: C.foreground,
              margin: 0,
              whiteSpace: 'pre-line',
            }}
          >
            {'Qarz\nHisobi'}
          </p>

          {/* ── Subtitle ── */}
          <p
            style={{
              fontSize: 16,
              lineHeight: '23px',
              maxWidth: 280,
              marginBottom: 12,
              color: C.mutedForeground,
              margin: 0,
            }}
          >
            Qarzlar va va&apos;dalarni xotirjam yuriting.
          </p>

          {/* ── Form card ── */}
          <div
            style={{
              padding: 19,
              borderWidth: 1,
              borderStyle: 'solid',
              borderColor: C.border,
              borderRadius: C.radius + 8,
              backgroundColor: C.card,
              display: 'flex',
              flexDirection: 'column',
              gap: 10,
            }}
          >
            {/* Form title */}
            <p
              style={{
                fontSize: 18,
                fontWeight: 700,
                color: C.foreground,
                margin: 0,
              }}
            >
              Telegram orqali kiring
            </p>

            {/* Help text */}
            <p
              style={{
                fontSize: 13,
                lineHeight: '19px',
                marginBottom: 8,
                color: C.mutedForeground,
                margin: 0,
              }}
            >
              Botdagi /web buyrug&apos;idan kod oling. Kod 10 daqiqa va bir marta
              ishlaydi.
            </p>

            {/* Access code label */}
            <label
              style={{
                fontSize: 13,
                fontWeight: 700,
                marginTop: 4,
                color: C.foreground,
                display: 'block',
              }}
            >
              Kirish kodi
            </label>

            {/* Access code input */}
            <input
              type="text"
              value={code}
              onChange={(e) => setCode(e.target.value.toUpperCase())}
              placeholder="Masalan: 7A2C…"
              style={{
                borderWidth: 1,
                borderStyle: 'solid',
                height: 49,
                paddingLeft: 13,
                paddingRight: 13,
                fontSize: 16,
                color: C.foreground,
                borderColor: C.input,
                borderRadius: C.radius,
                backgroundColor: 'transparent',
                outline: 'none',
                fontFamily: 'inherit',
                width: '100%',
                boxSizing: 'border-box',
              }}
            />

            {/* PIN label */}
            <label
              style={{
                fontSize: 13,
                fontWeight: 700,
                marginTop: 4,
                color: C.foreground,
                display: 'block',
              }}
            >
              PIN (yoqilgan bo&apos;lsa)
            </label>

            {/* PIN input */}
            <input
              type="password"
              inputMode="numeric"
              value={pin}
              onChange={(e) =>
                setPin(e.target.value.replace(/\D/g, '').slice(0, 4))
              }
              maxLength={4}
              placeholder="••••"
              style={{
                borderWidth: 1,
                borderStyle: 'solid',
                height: 49,
                paddingLeft: 13,
                paddingRight: 13,
                fontSize: 16,
                color: C.foreground,
                borderColor: C.input,
                borderRadius: C.radius,
                backgroundColor: 'transparent',
                outline: 'none',
                fontFamily: 'inherit',
                width: '100%',
                boxSizing: 'border-box',
              }}
            />

            {/* Error message (static empty in preview) */}
            {error ? (
              <p
                style={{
                  fontSize: 13,
                  fontWeight: 600,
                  color: C.destructive,
                  margin: 0,
                }}
              >
                {error}
              </p>
            ) : null}

            {/* Submit button */}
            <PrimaryButton
              label={isPending ? 'Tekshirilmoqda…' : 'Kirish'}
              onPress={handleSubmit}
              disabled={isDisabled}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
