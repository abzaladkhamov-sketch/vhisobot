import { type ReactNode } from 'react';
import { QueryClient, QueryClientProvider, QueryCache, MutationCache } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
  Redirect,
} from 'wouter';

import { AuthProvider, useAuth } from '@/hooks/use-auth';
import { AppShell } from '@/components/layout/app-shell';
import { PinUnlockDialog } from '@/components/pin-unlock-dialog';

import AuthPage from '@/pages/auth';
import DashboardPage from '@/pages/dashboard';
import TransactionsPage from '@/pages/transactions';
import ContactsPage from '@/pages/contacts';
import SettingsPage from '@/pages/settings';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { retry: false },
    mutations: { retry: false },
  },
  queryCache: new QueryCache({
    onError: (err: any) => {
      const status = err?.status;
      const msg = err?.message?.toLowerCase() || '';
      const code = err?.code;
      if (status === 423 || code === 'PIN_REQUIRED' || msg.includes('pin_required') || msg.includes('pin')) {
        window.dispatchEvent(new Event('require-pin'));
      } else if (status === 401) {
        window.dispatchEvent(new Event('require-login'));
      }
    }
  }),
  mutationCache: new MutationCache({
    onError: (err: any) => {
      const status = err?.status;
      const msg = err?.message?.toLowerCase() || '';
      const code = err?.code;
      if (status === 423 || code === 'PIN_REQUIRED' || msg.includes('pin_required') || msg.includes('pin')) {
        window.dispatchEvent(new Event('require-pin'));
      } else if (status === 401) {
        window.dispatchEvent(new Event('require-login'));
      }
    }
  })
});

function ProtectedRoute({ component: Component, path }: { component: any, path: string }) {
  const { token } = useAuth();
  
  return (
    <Route path={path}>
      {token ? <Component /> : <Redirect to="/" />}
    </Route>
  );
}

function Router() {
  return (
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={AuthPage} />
        
        <Route path="/:rest*">
          <AppShell>
            <Switch>
              <ProtectedRoute path="/dashboard" component={DashboardPage} />
              <ProtectedRoute path="/transactions" component={TransactionsPage} />
              <ProtectedRoute path="/contacts" component={ContactsPage} />
              <ProtectedRoute path="/settings" component={SettingsPage} />
              <Route component={NotFound} />
            </Switch>
          </AppShell>
        </Route>
      </Switch>
      <PinUnlockDialog />
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <AuthProvider>
            <Router />
          </AuthProvider>
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
