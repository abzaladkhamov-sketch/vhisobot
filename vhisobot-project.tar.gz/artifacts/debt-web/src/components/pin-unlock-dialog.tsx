import { useEffect, useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { useUnlockPrivacy } from '@workspace/api-client-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';

export function PinUnlockDialog() {
  const [open, setOpen] = useState(false);
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const unlock = useUnlockPrivacy();
  const queryClient = useQueryClient();

  useEffect(() => {
    const handleRequired = () => setOpen(true);
    window.addEventListener('require-pin', handleRequired);
    return () => window.removeEventListener('require-pin', handleRequired);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    unlock.mutate({ data: { pin } }, {
      onSuccess: () => {
        setOpen(false);
        setPin('');
        // Retry failed queries so the UI continues smoothly
        queryClient.invalidateQueries();
      },
      onError: () => {
        setError('PIN kod noto\'g\'ri. Iltimos, qayta urinib ko\'ring.');
        setPin('');
      }
    });
  };
  
  return (
    <Dialog open={open} onOpenChange={(val) => {
      // Prevent closing if we really need a PIN, but allowing them to back out is fine
      // If they back out, they just see empty/loading states or errors.
      setOpen(val);
    }}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Qulfdan chiqarish</DialogTitle>
          <DialogDescription>
            Maxfiyligingizni himoya qilish uchun seansingiz qulflangan. Davom etish uchun PIN kodingizni kiriting.
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-6 pt-4">
          <div className="space-y-2">
            <Label htmlFor="pin">4 xonali PIN kod</Label>
            <Input 
              id="pin" 
              type="password" 
              inputMode="numeric"
              pattern="[0-9]*"
              maxLength={4}
              value={pin}
              onChange={(e) => setPin(e.target.value)}
              placeholder="••••"
              required
              className="text-center text-2xl tracking-[0.5em]"
              autoFocus
            />
            {error && <p className="text-sm text-destructive font-medium">{error}</p>}
          </div>
          
          <div className="flex justify-end">
            <Button type="submit" disabled={unlock.isPending || pin.length !== 4}>
              {unlock.isPending ? 'Tekshirilmoqda...' : 'Ochish'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
