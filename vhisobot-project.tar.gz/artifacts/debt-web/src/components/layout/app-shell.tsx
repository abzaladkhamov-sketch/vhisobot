import { ReactNode } from 'react';
import { Link, useLocation } from 'wouter';
import { useAuth } from '@/hooks/use-auth';
import { BookOpen, Users, Settings, LogOut, Shield } from 'lucide-react';

export function AppShell({ children }: { children: ReactNode }) {
  const { user, logout } = useAuth();
  const [location] = useLocation();

  const navItems = [
    { href: '/dashboard', label: 'Bosh sahifa', icon: BookOpen },
    { href: '/transactions', label: 'O\'tkazmalar', icon: BookOpen },
    { href: '/contacts', label: 'Kontaktlar', icon: Users },
    { href: '/settings', label: 'Sozlamalar', icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-background flex flex-col md:flex-row">
      {/* Sidebar for Desktop / Top Nav for Mobile */}
      <nav className="w-full md:w-64 bg-card border-b md:border-r border-card-border flex-shrink-0 flex md:flex-col justify-between md:justify-start">
        <div className="p-4 flex items-center md:items-start md:flex-col gap-4">
          <div className="flex items-center gap-2 px-2 pb-2 md:pb-6">
            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary">
              <Shield size={16} />
            </div>
            <div>
              <h1 className="font-serif font-bold text-lg leading-tight">Qarz Hisobi</h1>
              <p className="text-xs text-muted-foreground hidden md:block">{user?.displayName}</p>
            </div>
          </div>
          
          <div className="hidden md:flex flex-col w-full gap-1">
            {navItems.map((item) => {
              const active = location.startsWith(item.href);
              const Icon = item.icon;
              return (
                <Link key={item.href} href={item.href} className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${active ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:bg-secondary hover:text-foreground'}`}>
                  <Icon size={16} />
                  {item.label}
                </Link>
              );
            })}
          </div>
        </div>

        <div className="hidden md:block p-4 border-t border-card-border">
          <button 
            onClick={() => logout()}
            className="flex items-center gap-3 w-full px-3 py-2 text-sm font-medium text-muted-foreground hover:text-foreground rounded-md transition-colors"
          >
            <LogOut size={16} />
            Chiqish
          </button>
        </div>

        {/* Mobile quick nav */}
        <div className="md:hidden flex items-center p-2 gap-1 overflow-x-auto">
          {navItems.map((item) => {
            const active = location.startsWith(item.href);
            return (
              <Link key={item.href} href={item.href} className={`px-3 py-2 rounded-md text-sm font-medium whitespace-nowrap ${active ? 'bg-primary/10 text-primary' : 'text-muted-foreground'}`}>
                {item.label}
              </Link>
            );
          })}
          <button onClick={() => logout()} className="px-3 py-2 rounded-md text-sm font-medium text-muted-foreground whitespace-nowrap">
            Chiqish
          </button>
        </div>
      </nav>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto">
        <div className="max-w-5xl mx-auto p-4 sm:p-6 lg:p-8">
          {children}
        </div>
      </main>
    </div>
  );
}
