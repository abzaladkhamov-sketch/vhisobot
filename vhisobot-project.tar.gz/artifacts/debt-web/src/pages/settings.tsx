import { useState, useEffect } from 'react';
import { useGetSettings, useUpdateSettings, getGetSettingsQueryKey, SettingsInputReportFrequency } from '@workspace/api-client-react';
import { useQueryClient } from '@tanstack/react-query';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { ShieldCheck, ShieldAlert } from 'lucide-react';

export default function SettingsPage() {
  const queryClient = useQueryClient();
  const { data: settings, isLoading } = useGetSettings({
    query: { queryKey: getGetSettingsQueryKey() }
  });
  
  const updateSettings = useUpdateSettings();
  
  const [frequency, setFrequency] = useState<SettingsInputReportFrequency>('off');

  useEffect(() => {
    if (settings) {
      setFrequency(settings.reportFrequency);
    }
  }, [settings]);

  const handleSave = () => {
    updateSettings.mutate({ data: { reportFrequency: frequency } }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetSettingsQueryKey() });
      }
    });
  };

  if (isLoading) return <div className="p-8">Sozlamalar yuklanmoqda...</div>;
  if (!settings) return null;

  return (
    <div className="space-y-8 animate-in fade-in-50 duration-500 max-w-2xl">
      <div>
        <h1 className="text-3xl font-serif font-bold text-foreground">Sozlamalar</h1>
        <p className="text-muted-foreground mt-1">Shaxsiy parametrlaringizni sozlang.</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Hisobotlar</CardTitle>
          <CardDescription>Bot sizga qarzlar holati bo'yicha qanchalik tez-tez hisobot yuborishi kerak?</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <Label>Hisobot yuborish oraliqlari</Label>
            <select 
              className="flex h-10 w-full md:w-1/2 rounded-md border border-input bg-transparent px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              value={frequency} 
              onChange={e => setFrequency(e.target.value as SettingsInputReportFrequency)}
            >
              <option value="off">O'chirilgan (Hech qachon)</option>
              <option value="weekly">Har haftada</option>
              <option value="monthly">Har oyda</option>
            </select>
          </div>

          <Button 
            onClick={handleSave} 
            disabled={updateSettings.isPending || frequency === settings.reportFrequency}
          >
            {updateSettings.isPending ? 'Saqlanmoqda...' : 'Sozlamalarni saqlash'}
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Maxfiylik holati</CardTitle>
          <CardDescription>Sizning xavfsizlik sozlashingiz.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4 p-4 rounded-lg bg-secondary/30 border border-secondary">
            {settings.pinEnabled ? (
              <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center text-primary shrink-0">
                <ShieldCheck size={20} />
              </div>
            ) : (
              <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center text-muted-foreground shrink-0">
                <ShieldAlert size={20} />
              </div>
            )}
            
            <div>
              <h3 className="font-medium">
                {settings.pinEnabled ? 'PIN kod himoyasi faol' : 'PIN kod himoyasi o\'chirilgan'}
              </h3>
              <p className="text-sm text-muted-foreground mt-1">
                {settings.pinEnabled 
                  ? 'Moliyaviy ma\'lumotlaringiz PIN kod bilan himoyalangan. Buni o\'zgartirish uchun Telegram botdan foydalaning.'
                  : 'Ma\'lumotlaringiz PIN kodsiz ochiq. Telegram bot orqali PIN kod o\'rnatishni tavsiya qilamiz.'}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
