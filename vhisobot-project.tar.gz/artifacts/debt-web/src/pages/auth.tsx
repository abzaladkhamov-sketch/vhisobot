import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { useAuth } from '@/hooks/use-auth';
import { useExchangeAccessCode } from '@workspace/api-client-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ShieldCheck } from 'lucide-react';

export default function AuthPage() {
  const [code, setCode] = useState('');
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const [, setLocation] = useLocation();
  const { token, user, setToken } = useAuth();
  
  const exchange = useExchangeAccessCode();

  useEffect(() => {
    // Already authenticated, redirect to dashboard
    if (token && user) {
      setLocation('/dashboard');
    }
  }, [token, user, setLocation]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    exchange.mutate({ 
      data: { code, pin: pin ? pin : null } 
    }, {
      onSuccess: (session) => {
        setToken(session.accessToken);
        setLocation('/dashboard');
      },
      onError: (err: any) => {
        // Simple error parsing
        const msg = err?.message || 'Kod yoki PIN noto\'g\'ri.';
        setError(msg);
      }
    });
  };

  return (
    <div className="min-h-screen bg-background flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
        <div className="mx-auto w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4 text-primary">
          <ShieldCheck size={24} />
        </div>
        <h2 className="mt-2 text-3xl font-serif font-bold tracking-tight text-foreground">
          Qarz Hisobi
        </h2>
        <p className="mt-2 text-sm text-muted-foreground">
          Va'dalarni saqlash uchun ishonchli joy.
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <Card>
          <CardHeader>
            <CardTitle>Kirish</CardTitle>
            <CardDescription>Telegram botdan olingan kirish kodini kiriting.</CardDescription>
          </CardHeader>
          <CardContent>
            <form className="space-y-6" onSubmit={handleSubmit}>
              <div className="space-y-2">
                <Label htmlFor="code">Kirish kodi</Label>
                <Input
                  id="code"
                  type="text"
                  required
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  placeholder="Kirish kodini kiriting"
                />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="pin">PIN kod (agar yoqilgan bo'lsa)</Label>
                  <span className="text-xs text-muted-foreground">Ixtiyoriy</span>
                </div>
                <Input
                  id="pin"
                  type="password"
                  inputMode="numeric"
                  pattern="[0-9]*"
                  maxLength={4}
                  value={pin}
                  onChange={(e) => setPin(e.target.value)}
                  placeholder="••••"
                  className="tracking-widest"
                />
              </div>

              {error && (
                <div className="text-sm font-medium text-destructive">
                  {error}
                </div>
              )}

              <Button type="submit" className="w-full" disabled={exchange.isPending}>
                {exchange.isPending ? 'Tekshirilmoqda...' : 'Kirish'}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
