import { useState } from 'react';
import { 
  useListTransactions, 
  useCreateTransaction, 
  useDecideTransaction,
  useCreateRepayment,
  useListContacts,
  useHideTransaction,
  useResendTransactionNotification,
  Transaction,
  TransactionInputDirection,
  getListTransactionsQueryKey,
  getGetDashboardQueryKey,
  DecisionInputDecision
} from '@workspace/api-client-react';
import { useQueryClient } from '@tanstack/react-query';
import { Link, useSearch } from 'wouter';
import { format } from 'date-fns';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Check, X, Plus, AlertCircle, RefreshCw } from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';

const statusMap: Record<string, string> = {
  pending: 'Tasdiqlash kutilmoqda',
  repayment_pending: 'Qaytaruv tasdiqlash kutilmoqda',
  confirmed: 'Tasdiqlangan',
  rejected: 'Rad etilgan',
  repayment: 'Qaytaruv'
};

export default function TransactionsPage() {
  const { user } = useAuth();
  const search = useSearch();
  const queryClient = useQueryClient();
  const [isNewOpen, setIsNewOpen] = useState(false);
  const [isRepayOpen, setIsRepayOpen] = useState(false);
  const [selectedTx, setSelectedTx] = useState<Transaction | null>(null);
  const [decisionError, setDecisionError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [hideError, setHideError] = useState('');

  const { data: contacts } = useListContacts({
    query: { queryKey: ['/api/contacts'] }
  });

  const contactId = Number(new URLSearchParams(search).get('contactId'));
  const selectedContactId = Number.isInteger(contactId) && contactId > 0 ? contactId : undefined;
  const selectedContact = contacts?.find((contact) => contact.id === selectedContactId);

  const { data: transactions, isLoading, isError, refetch } = useListTransactions(
    selectedContactId ? { contactId: selectedContactId } : undefined,
    {
      query: {
        queryKey: getListTransactionsQueryKey(
          selectedContactId ? { contactId: selectedContactId } : undefined,
        ),
      },
    },
  );
  const decideTx = useDecideTransaction();
  const hideTx = useHideTransaction();
  const resendTx = useResendTransactionNotification();

  const handleDecision = (id: number, decision: DecisionInputDecision) => {
    setDecisionError('');
    setSuccessMessage('');
    const isRepayment = transactions?.find((transaction) => transaction.id === id)?.status === 'repayment_pending';
    decideTx.mutate({ transactionId: id, data: { decision } }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListTransactionsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() });
        setSuccessMessage(
          decision === 'confirmed'
            ? isRepayment ? 'Qaytaruv tasdiqlandi. Balans yangilandi.' : 'Qarz tasdiqlandi. Balans yangilandi.'
            : isRepayment ? 'Qaytaruv rad etildi. Balans o‘zgarmadi.' : 'Qarz rad etildi. U balansga qo‘shilmadi.',
        );
      },
      onError: (error: any) => {
        setDecisionError(
          error?.message ??
            "Tasdiqlash amalga oshmadi. Balansni yangilab, qayta urinib ko‘ring.",
        );
      },
    });
  };

  const handleHide = (transaction: Transaction) => {
    if (!transaction.canHide || hideTx.isPending) return;
    if (!window.confirm('Bu yozuvni faqat sizning tarixingizdan yashiraymi? Balans va audit o‘zgarmaydi.')) {
      return;
    }
    setHideError('');
    setSuccessMessage('');
    hideTx.mutate(
      { transactionId: transaction.id },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListTransactionsQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() });
          setSuccessMessage('Yozuv tarixingizdan yashirildi. Balans va audit o‘zgarmadi.');
        },
        onError: (error: any) => {
          setHideError(error?.message ?? 'Yozuvni tarixdan yashirib bo‘lmadi.');
        },
      },
    );
  };

  const handleResend = (transactionId: number) => {
    if (resendTx.isPending) return;
    setDecisionError('');
    setSuccessMessage('');
    resendTx.mutate(
      { transactionId },
      {
        onSuccess: (transaction) => {
          queryClient.invalidateQueries({ queryKey: getListTransactionsQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() });
          setSuccessMessage(
            transaction.deliveryStatus === 'sent'
              ? 'Telegram xabari qayta yuborildi.'
              : 'Qayta yuborish boshlandi. So‘rov hali ham ko‘rib chiqish uchun mavjud.',
          );
        },
        onError: (error: any) => {
          setDecisionError(error?.message ?? 'Qayta yuborib bo‘lmadi. Birozdan keyin urinib ko‘ring.');
        },
      },
    );
  };

  if (isLoading) return <div className="p-8 text-center text-muted-foreground">Daftar yuklanmoqda...</div>;

  if (isError) {
    return (
      <div className="p-8 text-center space-y-4">
        <p className="text-muted-foreground">Ma’lumotlarni yuklab bo‘lmadi.</p>
        <Button variant="outline" className="gap-2" onClick={() => void refetch()}>
          <RefreshCw size={16} /> Qayta urinib ko‘rish
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-in fade-in-50 duration-500">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-serif font-bold text-foreground">
            {selectedContact ? `${selectedContact.displayName} tarixi` : "O'tkazmalar"}
          </h1>
          <p className="text-muted-foreground mt-1">Qarzlar va qaytaruvlar tarixi.</p>
          {selectedContact ? (
            <Link href="/transactions" className="inline-block mt-2 text-sm font-medium text-primary underline underline-offset-4">
              Barcha tarixni ko‘rish
            </Link>
          ) : null}
        </div>
        
        <div className="flex gap-2">
          <Dialog open={isNewOpen} onOpenChange={setIsNewOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus size={16} /> Qarz kiritish
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Qarz kiritish</DialogTitle>
                <DialogDescription>Qarz balansga faqat ikkinchi tomon tasdiqlagandan keyin qo‘shiladi.</DialogDescription>
              </DialogHeader>
              <NewTransactionForm 
                contacts={contacts || []} 
                onSuccess={() => {
                  setIsNewOpen(false);
                  setSuccessMessage('Qarz so‘rovi yuborildi. Tasdiqlangach balans yangilanadi.');
                  queryClient.invalidateQueries({ queryKey: getListTransactionsQueryKey() });
                  queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() });
                }} 
              />
            </DialogContent>
          </Dialog>

          <Dialog open={isRepayOpen} onOpenChange={setIsRepayOpen}>
            <DialogTrigger asChild>
              <Button variant="outline">Qaytaruv kiritish</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Qaytaruv kiritish</DialogTitle>
                <DialogDescription>Qaytaruv alohida yoziladi va qolgan qarz avtomatik kamayadi.</DialogDescription>
              </DialogHeader>
              <NewRepaymentForm 
                contacts={contacts || []} 
                onSuccess={() => {
                  setIsRepayOpen(false);
                  setSuccessMessage('Qaytaruv saqlandi. Qolgan qarz avtomatik yangilandi.');
                  queryClient.invalidateQueries({ queryKey: getListTransactionsQueryKey() });
                  queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() });
                }} 
              />
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {decisionError ? (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Tasdiqlash amalga oshmadi</AlertTitle>
          <AlertDescription>{decisionError}</AlertDescription>
        </Alert>
      ) : null}

      {hideError ? (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Tarixdan yashirish amalga oshmadi</AlertTitle>
          <AlertDescription>{hideError}</AlertDescription>
        </Alert>
      ) : null}

      {successMessage ? (
        <Alert>
          <Check className="h-4 w-4" />
          <AlertTitle>Amal bajarildi</AlertTitle>
          <AlertDescription>{successMessage}</AlertDescription>
        </Alert>
      ) : null}

      <Card>
        <div className="divide-y border-t-0">
          {!transactions?.length ? (
            <div className="p-8 text-center text-muted-foreground">Ro'yxat bo'sh. Hech qanday yozuv topilmadi.</div>
          ) : (
            transactions.map((tx) => {
              const isMine = tx.enteredById === user?.id;
               const pendingAction = ['pending', 'repayment_pending'].includes(tx.status) && !isMine;
              const debtDirection = tx.creditorId === user?.id ? 'Sizga qarz' : 'Siz qarzdorsiz';
              const directionLabel =
                tx.status === 'repayment'
                  ? isMine
                    ? 'Qarzingiz kamaydi'
                    : 'Sizga qarz kamaydi'
                   : tx.status === 'repayment_pending'
                     ? 'Qaytaruv — balans hali o‘zgarmagan'
                   : tx.status === 'pending'
                    ? `${debtDirection} — balans hali o‘zgarmagan`
                    : tx.status === 'rejected'
                      ? `${debtDirection} — balansga qo‘shilmagan`
                      : debtDirection;
              
              return (
                <div key={tx.id} className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-secondary/10 transition-colors">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{tx.counterparty?.displayName || 'Noma\'lum'}</span>
                      <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${
                        tx.status === 'rejected'
                          ? 'bg-destructive/10 text-destructive'
                           : ['pending', 'repayment_pending'].includes(tx.status)
                            ? 'bg-secondary text-secondary-foreground'
                            : 'bg-primary/10 text-primary'
                      }`}>
                        {statusMap[tx.status] || tx.status}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {tx.note && <span className="mr-2">"{tx.note}"</span>}
                      {format(new Date(tx.createdAt), 'MMM d, yyyy')}
                    </p>
                    {tx.dueDate && (
                      <p className="text-xs text-destructive font-medium">
                        Muddat: {format(new Date(tx.dueDate), 'MMM d, yyyy')}
                      </p>
                    )}
                     {tx.deliveryStatus === 'manual_review' && (
                       <div className="flex flex-col items-start gap-2">
                         <p className="max-w-md text-xs font-medium text-amber-700 dark:text-amber-300">
                           Telegram xabari yetkazilmadi. So‘rov hali kutilmoqda — uni shu yerdan yoki Telegramdagi /pending orqali ko‘rib chiqing.
                         </p>
                         {tx.status === 'repayment_pending' && tx.debtorId === user?.id ? (
                           <Button
                             size="sm"
                             variant="outline"
                             className="gap-1.5"
                             onClick={() => handleResend(tx.id)}
                             disabled={resendTx.isPending}
                           >
                             <RefreshCw size={14} />
                             {resendTx.isPending ? 'Qayta yuborilmoqda...' : 'Telegramga qayta yuborish'}
                           </Button>
                         ) : null}
                       </div>
                     )}
                  </div>
                  
                  <div className="flex items-center sm:justify-end gap-4">
                    <div className="text-right">
                      <p className={`text-lg font-serif ${tx.creditorId === user?.id ? 'text-primary' : 'text-destructive'}`}>
                        {tx.amount} {tx.currency}
                      </p>
                      <p className="text-xs text-muted-foreground uppercase tracking-wider">
                        {directionLabel}
                      </p>
                    </div>
                    
                    {pendingAction && (
                      <div className="flex flex-col items-end gap-2">
                        <p className="max-w-xs text-right text-xs font-medium text-muted-foreground">
                          Tasdiqlashingiz kutilmoqda. To‘g‘ri bo‘lsa tasdiqlang, xato bo‘lsa rad eting.
                        </p>
                        <div className="flex gap-2">
                          <Button size="sm" className="gap-1.5" onClick={() => handleDecision(tx.id, 'confirmed')} disabled={decideTx.isPending}>
                            <Check size={14} />
                            {decideTx.isPending ? 'Tekshirilmoqda...' : 'Tasdiqlash'}
                          </Button>
                          <Button size="sm" variant="outline" className="gap-1.5" onClick={() => handleDecision(tx.id, 'rejected')} disabled={decideTx.isPending}>
                            <X size={14} />
                            Rad etish
                          </Button>
                        </div>
                      </div>
                    )}
                     {['pending', 'repayment_pending'].includes(tx.status) && isMine ? (
                      <p className="max-w-xs text-right text-xs font-medium text-muted-foreground">
                         {tx.status === 'repayment_pending'
                           ? 'Ikkinchi tomon qaytaruvni tasdiqlashini kuting.'
                           : 'Ikkinchi tomon tasdiqlashini kuting.'}
                      </p>
                    ) : null}
                    {tx.canHide ? (
                      <Button
                        size="sm"
                        variant="ghost"
                        className="text-muted-foreground"
                        onClick={() => handleHide(tx)}
                        disabled={hideTx.isPending}
                      >
                        {hideTx.isPending ? 'Yashirilmoqda...' : 'Tarixdan yashirish'}
                      </Button>
                    ) : null}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </Card>
    </div>
  );
}

function NewTransactionForm({ contacts, onSuccess }: { contacts: any[], onSuccess: () => void }) {
  const [contactId, setContactId] = useState('');
  const [direction, setDirection] = useState<TransactionInputDirection>('given');
  const [amount, setAmount] = useState('');
  const [currency, setCurrency] = useState('USD');
  const [note, setNote] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [error, setError] = useState('');
  
  const createTx = useCreateTransaction();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    const numericAmount = Number(amount);
    if (!contactId || !Number.isSafeInteger(numericAmount) || numericAmount <= 0) {
      setError('Kontakt va noldan katta butun summani kiriting.');
      return;
    }
    createTx.mutate({
      data: {
        contactId: Number(contactId),
        direction,
        amount: numericAmount,
        currency,
        note: note || null,
        dueDate: dueDate || null,
      }
    }, {
      onSuccess,
      onError: (mutationError: any) =>
        setError(
          mutationError?.message ??
            'Saqlab bo‘lmadi. Internetni tekshirib, qayta urinib ko‘ring.',
        ),
    });
  };

  const selectedContact = contacts.find((contact) => String(contact.id) === contactId);
  const summary = selectedContact && amount
    ? `${selectedContact.displayName}: ${direction === 'received' ? 'Oldim — men qarzdorman' : 'Berdim — undan olishim kerak'}, ${amount} ${currency}${dueDate ? `, muddat ${dueDate}` : ', muddatsiz'}`
    : '';

  return (
    <form onSubmit={handleSubmit} className="space-y-4 pt-4">
      <div className="space-y-2">
        <Label>Ikkinchi tomon</Label>
        <select 
          className="flex h-10 w-full rounded-md border border-input bg-transparent px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          value={contactId} 
          onChange={e => setContactId(e.target.value)}
          required
        >
          <option value="" disabled>Kontaktni tanlang...</option>
          {contacts.map(c => <option key={c.id} value={c.id}>{c.displayName}</option>)}
        </select>
      </div>

      <div className="space-y-2">
        <Label>Qarz yo‘nalishi</Label>
        <select 
          className="flex h-10 w-full rounded-md border border-input bg-transparent px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          value={direction} 
          onChange={e => setDirection(e.target.value as any)}
        >
          <option value="received">Oldim — men qarzdorman</option>
          <option value="given">Berdim — undan olishim kerak</option>
        </select>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Miqdor</Label>
            <Input type="number" min="1" step="1" value={amount} onChange={e => setAmount(e.target.value)} required />
        </div>
        <div className="space-y-2">
          <Label>Valyuta</Label>
          <Input type="text" pattern="[A-Z]{3}" placeholder="USD" value={currency} onChange={e => setCurrency(e.target.value.toUpperCase())} required />
        </div>
      </div>

      <div className="space-y-2">
        <Label>Muddat (ixtiyoriy)</Label>
        <Input type="date" value={dueDate} onChange={e => setDueDate(e.target.value)} />
      </div>

      <div className="space-y-2">
        <Label>Izoh (Ixtiyoriy)</Label>
        <Input type="text" placeholder="Kechagi kechki ovqat uchun" value={note} onChange={e => setNote(e.target.value)} />
      </div>

      {summary ? (
        <div className="rounded-md border bg-secondary/30 p-3 text-sm">
          <p className="font-medium">Yuborishdan oldingi xulosa</p>
          <p className="mt-1 text-muted-foreground">{summary}</p>
          <p className="mt-2 text-xs text-muted-foreground">Balans kontakt tasdiqlagach yangilanadi.</p>
        </div>
      ) : null}

      {error ? (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      ) : null}

      <div className="flex justify-end pt-2">
        <Button type="submit" disabled={createTx.isPending}>
          {createTx.isPending ? 'Yuborilmoqda...' : 'Qarz so‘rovini yuborish'}
        </Button>
      </div>
    </form>
  );
}

function NewRepaymentForm({ contacts, onSuccess }: { contacts: any[], onSuccess: () => void }) {
  const [contactId, setContactId] = useState('');
  const [amount, setAmount] = useState('');
  const [currency, setCurrency] = useState('USD');
  const [note, setNote] = useState('');
  const [error, setError] = useState('');
  
  const repay = useCreateRepayment();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    const numericAmount = Number(amount);
    if (!contactId || !Number.isSafeInteger(numericAmount) || numericAmount <= 0) {
      setError('Kontakt va noldan katta butun summani kiriting.');
      return;
    }
    repay.mutate({
      data: {
        contactId: Number(contactId),
        amount: numericAmount,
        currency,
        note: note || null,
      }
    }, {
      onSuccess,
      onError: (mutationError: any) =>
        setError(
          mutationError?.message ??
            'Saqlab bo‘lmadi. Internetni tekshirib, qayta urinib ko‘ring.',
        ),
    });
  };

  const selectedContact = contacts.find((contact) => String(contact.id) === contactId);
  const summary = selectedContact && amount
    ? `${selectedContact.displayName} ga ${amount} ${currency} qaytaruv kiritiladi.`
    : '';

  return (
    <form onSubmit={handleSubmit} className="space-y-4 pt-4">
      <div className="space-y-2">
        <Label>Qaytaruv kimga</Label>
        <select 
          className="flex h-10 w-full rounded-md border border-input bg-transparent px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          value={contactId} 
          onChange={e => setContactId(e.target.value)}
          required
        >
          <option value="" disabled>Kontaktni tanlang...</option>
          {contacts.map(c => <option key={c.id} value={c.id}>{c.displayName}</option>)}
        </select>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Qaytarilgan miqdor</Label>
            <Input type="number" min="1" step="1" value={amount} onChange={e => setAmount(e.target.value)} required />
        </div>
        <div className="space-y-2">
          <Label>Valyuta</Label>
          <Input type="text" pattern="[A-Z]{3}" placeholder="USD" value={currency} onChange={e => setCurrency(e.target.value.toUpperCase())} required />
        </div>
      </div>

      <div className="space-y-2">
        <Label>Izoh (Ixtiyoriy)</Label>
        <Input type="text" placeholder="Pul o'tkazmasi" value={note} onChange={e => setNote(e.target.value)} />
      </div>

      {summary ? (
        <div className="rounded-md border bg-secondary/30 p-3 text-sm">
          <p className="font-medium">Saqlashdan oldingi xulosa</p>
          <p className="mt-1 text-muted-foreground">{summary}</p>
           <p className="mt-2 text-xs text-muted-foreground">Balans kontakt tasdiqlagach yangilanadi.</p>
        </div>
      ) : null}

      {error ? (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      ) : null}

      <div className="flex justify-end pt-2">
        <Button type="submit" disabled={repay.isPending}>
          {repay.isPending ? 'Saqlanmoqda...' : 'Qaytaruvni saqlash'}
        </Button>
      </div>
    </form>
  );
}
