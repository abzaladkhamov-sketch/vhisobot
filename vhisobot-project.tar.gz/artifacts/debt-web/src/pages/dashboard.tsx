import { useGetDashboard, getGetDashboardQueryKey } from '@workspace/api-client-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { format } from 'date-fns';
import { Clock, AlertCircle, ArrowUpRight, ArrowDownLeft } from 'lucide-react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';

const statusMap: Record<string, string> = {
  pending: 'Tasdiqlash kutilmoqda',
  repayment_pending: 'Qaytaruv tasdiqlash kutilmoqda',
  confirmed: 'Tasdiqlangan',
  rejected: 'Rad etilgan',
  repayment: 'Qaytaruv'
};

export default function DashboardPage() {
  const { data: dashboard, isLoading, error, refetch } = useGetDashboard({
    query: {
      queryKey: getGetDashboardQueryKey(),
    }
  });

  if (isLoading) {
    return <div className="animate-pulse space-y-4">
      <div className="h-8 bg-muted rounded w-1/4"></div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="h-32 bg-muted rounded"></div>
        <div className="h-32 bg-muted rounded"></div>
      </div>
    </div>;
  }

  if (error || !dashboard) {
    return (
      <div className="space-y-4 text-center">
        <p className="text-muted-foreground">Ma’lumotlarni yuklab bo‘lmadi.</p>
        <Button variant="outline" onClick={() => void refetch()}>Qayta urinib ko‘rish</Button>
      </div>
    );
  }

  const { balances, recentTransactions, pendingCount, dueSoonCount } = dashboard;
  
  const totalYouOwe = balances
    .filter(b => b.userOwesOther)
    .reduce((sum, b) => sum + b.amount, 0);
    
  const totalOwedToYou = balances
    .filter(b => !b.userOwesOther)
    .reduce((sum, b) => sum + b.amount, 0);

  return (
    <div className="space-y-8 animate-in fade-in-50 duration-500">
      <header>
        <h1 className="text-3xl font-serif font-bold text-foreground">Bosh sahifa</h1>
        <p className="text-muted-foreground mt-1">Barcha va'dalaringizning umumiy holati.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="bg-primary text-primary-foreground border-transparent">
          <CardHeader className="pb-2">
            <CardTitle className="text-primary-foreground/90 text-sm uppercase tracking-wider font-sans">Sizga qarz</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-4xl font-serif">{totalOwedToYou > 0 ? totalOwedToYou.toLocaleString() : '0'}</div>
            <p className="text-primary-foreground/70 text-sm mt-1">Barcha valyutalarda</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-muted-foreground text-sm uppercase tracking-wider font-sans">Siz qarzdorsiz</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-4xl font-serif text-destructive">{totalYouOwe > 0 ? totalYouOwe.toLocaleString() : '0'}</div>
            <p className="text-muted-foreground text-sm mt-1">Barcha valyutalarda</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {pendingCount > 0 && (
          <Link
            href="/transactions"
            className="flex items-center gap-3 bg-secondary/50 p-4 rounded-lg border border-secondary transition-colors hover:bg-secondary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            <Clock className="text-secondary-foreground" size={20} />
            <div>
               <h4 className="font-medium text-secondary-foreground">Tasdiqlashingiz kutilmoqda</h4>
               <p className="text-sm text-secondary-foreground/80">{pendingCount} ta qarz so‘rovini ko‘rib chiqing</p>
              <span className="mt-1 inline-block text-sm font-semibold text-secondary-foreground underline underline-offset-2">
                 Tasdiqlashga o‘tish
              </span>
            </div>
          </Link>
        )}
        
        {dueSoonCount > 0 && (
          <div className="flex items-center gap-3 bg-destructive/10 p-4 rounded-lg border border-destructive/20">
            <AlertCircle className="text-destructive" size={20} />
            <div>
              <h4 className="font-medium text-destructive">Muddati yaqin</h4>
              <p className="text-sm text-destructive/80">{dueSoonCount} ta qarz e’tibor talab qiladi</p>
            </div>
          </div>
        )}
      </div>

      <div>
        <h3 className="text-lg font-serif font-medium mb-4">Faol qoldiqlar</h3>
        {balances.length === 0 ? (
          <p className="text-muted-foreground italic text-sm">Faol qoldiqlar yo'q. Barcha qarzlar uzilgan.</p>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {balances.map((b, idx) => (
              <div key={idx} className="p-4 bg-card border rounded-lg flex flex-col justify-between shadow-sm">
                <span className="font-medium">{b.contact.displayName}</span>
                <div className="mt-2 flex items-baseline justify-between">
                  <span className={`text-xl font-serif ${b.userOwesOther ? 'text-destructive' : 'text-primary'}`}>
                    {b.amount} {b.currency}
                  </span>
                  <span className="text-xs text-muted-foreground">
                    {b.userOwesOther ? 'Siz qarzdorsiz' : 'Sizga qarz'}
                  </span>
                </div>
                <div className="mt-4 grid grid-cols-2 gap-x-4 gap-y-2 border-t border-border pt-3 text-xs">
                  <div className="flex justify-between gap-2 text-muted-foreground">
                    <span>Berdingiz</span>
                    <span className="font-medium text-foreground">{b.lentTotal.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between gap-2 text-muted-foreground">
                    <span>Oldingiz</span>
                    <span className="font-medium text-foreground">{b.borrowedTotal.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between gap-2 text-muted-foreground">
                    <span>Qaytardingiz</span>
                    <span className="font-medium text-foreground">{b.repaidByUser.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between gap-2 text-muted-foreground">
                    <span>Sizga qaytarildi</span>
                    <span className="font-medium text-foreground">{b.repaidToUser.toLocaleString()}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div>
        <h3 className="text-lg font-serif font-medium mb-4">So'nggi faollik</h3>
        <Card>
          <div className="divide-y border-t-0">
            {recentTransactions.length === 0 ? (
              <div className="p-6 text-center text-muted-foreground text-sm">So'nggi faollik yo'q.</div>
            ) : (
              recentTransactions.map((tx) => (
                <div key={tx.id} className="p-4 flex items-center justify-between hover:bg-secondary/20 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${tx.status === 'pending' || tx.status === 'repayment_pending' ? 'bg-secondary text-secondary-foreground' : 'bg-primary/10 text-primary'}`}>
                      {tx.status === 'pending' || tx.status === 'repayment_pending' ? <Clock size={16} /> : <ArrowUpRight size={16} />}
                    </div>
                    <div>
                      <p className="font-medium text-sm">
                        {tx.counterparty?.displayName || 'Noma\'lum'}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {format(new Date(tx.createdAt), 'MMM d, yyyy')} &middot; {statusMap[tx.status] || tx.status}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">
                      {tx.amount} {tx.currency}
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>
        </Card>
      </div>
    </div>
  );
}
