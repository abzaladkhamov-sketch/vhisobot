import { useListContacts, getListContactsQueryKey } from '@workspace/api-client-react';
import { Card } from '@/components/ui/card';
import { ArrowRight } from 'lucide-react';
import { Link } from 'wouter';

export default function ContactsPage() {
  const { data: contacts, isLoading } = useListContacts({
    query: { queryKey: getListContactsQueryKey() }
  });

  if (isLoading) return <div className="p-8 text-center text-muted-foreground">Kontaktlar yuklanmoqda...</div>;

  return (
    <div className="space-y-6 animate-in fade-in-50 duration-500">
      <div>
        <h1 className="text-3xl font-serif font-bold text-foreground">Ulangan kontaktlar</h1>
        <p className="text-muted-foreground mt-1">Telegram orqali muloqot qiladigan kontaktlaringiz.</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {!contacts?.length ? (
          <p className="text-muted-foreground italic text-sm">Hali kontaktlar ulanmagan. Hisoblarni ulash uchun botdan foydalaning.</p>
        ) : (
          contacts.map((c) => (
            <Link key={c.id} href={`/transactions?contactId=${c.id}`} className="block rounded-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
              <Card className="p-5 flex items-center justify-between gap-4 transition-colors hover:border-primary/50 hover:bg-secondary/20">
                <div className="flex flex-col gap-1">
                  <span className="font-serif font-medium text-lg">{c.displayName}</span>
                  {c.username && (
                    <span className="text-sm text-muted-foreground">@{c.username}</span>
                  )}
                  <span className="text-xs text-primary font-medium mt-1">Tarixni ko‘rish</span>
                </div>
                <ArrowRight size={18} className="text-muted-foreground shrink-0" />
              </Card>
            </Link>
          ))
        )}
      </div>
    </div>
  );
}
