import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { useLocation } from 'wouter';
import { setAuthTokenGetter, useGetCurrentUser, UserProfile } from '@workspace/api-client-react';

interface AuthContextType {
  token: string | null;
  user: UserProfile | null;
  setToken: (token: string) => void;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

setAuthTokenGetter(() => localStorage.getItem('qarz_token') || '');

export function AuthProvider({ children }: { children: ReactNode }) {
  const [token, setTokenState] = useState<string | null>(localStorage.getItem('qarz_token'));
  const [, setLocation] = useLocation();

  const setToken = (newToken: string) => {
    localStorage.setItem('qarz_token', newToken);
    setAuthTokenGetter(() => newToken);
    setTokenState(newToken);
  };

  const logout = () => {
    localStorage.removeItem('qarz_token');
    setAuthTokenGetter(() => '');
    setTokenState(null);
    setLocation('/');
  };

  useEffect(() => {
    setAuthTokenGetter(() => localStorage.getItem('qarz_token') || '');
  }, []);

  const { data: user, isError } = useGetCurrentUser({
    query: {
      enabled: !!token,
      queryKey: ['/api/me'], // Fallback query key to avoid missing getGetCurrentUserQueryKey locally if needed, though it's better to use it directly
      retry: false,
    }
  });

  useEffect(() => {
    if (isError) {
      // If we get an error (e.g. 401), we clear the token.
      logout();
    }
  }, [isError]);

  // Global event listener for token expiration
  useEffect(() => {
    const handleLoginRequired = () => logout();
    window.addEventListener('require-login', handleLoginRequired);
    return () => window.removeEventListener('require-login', handleLoginRequired);
  }, []);

  return (
    <AuthContext.Provider value={{ token, user: user || null, setToken, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
