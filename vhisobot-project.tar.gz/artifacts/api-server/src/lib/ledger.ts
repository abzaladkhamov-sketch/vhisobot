export class LedgerError extends Error {}

type SqlClient = {
  query: (...args: any[]) => Promise<any>;
};

export async function acquireDebtPairLock(
  client: SqlClient,
  firstUserId: number,
  secondUserId: number,
  currency: string,
): Promise<{ lowId: number; highId: number }> {
  const lowId = Math.min(firstUserId, secondUserId);
  const highId = Math.max(firstUserId, secondUserId);
  const lockKey = `debt:${lowId}:${highId}:${currency}:0`;
  await client.query(
    "SELECT pg_advisory_xact_lock(hashtextextended($1, 0))",
    [lockKey],
  );
  return { lowId, highId };
}

export async function recalculateDebt(
  client: SqlClient,
  firstUserId: number,
  secondUserId: number,
  currency: string,
): Promise<void> {
  // Keep the bot's locking order: pair advisory lock, then the materialized
  // Debt row. That serializes cross-client ledger writes safely.
  const { lowId, highId } = await acquireDebtPairLock(
    client,
    firstUserId,
    secondUserId,
    currency,
  );
  const existing = (await client.query(
    `SELECT id FROM debts
     WHERE user_low_id = $1 AND user_high_id = $2 AND currency = $3 AND scope_chat_id = 0
     FOR UPDATE`,
    [lowId, highId, currency],
  )) as { rows: Array<{ id: number }> };

  const directionTotalsForStatuses = async (
    statuses: string[],
  ): Promise<{ lowToHigh: number; highToLow: number }> => {
    const result = (await client.query(
      `SELECT
         COALESCE(SUM(CASE WHEN debtor_id = $1 AND creditor_id = $2 THEN amount ELSE 0 END), 0)::text AS low_to_high,
         COALESCE(SUM(CASE WHEN debtor_id = $2 AND creditor_id = $1 THEN amount ELSE 0 END), 0)::text AS high_to_low
       FROM transactions
       WHERE ((debtor_id = $1 AND creditor_id = $2) OR (debtor_id = $2 AND creditor_id = $1))
         AND currency = $3
         AND scope_chat_id = 0
         AND status = ANY($4::text[])`,
      [lowId, highId, currency, statuses],
    )) as { rows: Array<{ low_to_high: string; high_to_low: string }> };
    const lowToHigh = Number(result.rows[0]?.low_to_high ?? 0);
    const highToLow = Number(result.rows[0]?.high_to_low ?? 0);
    if (!Number.isSafeInteger(lowToHigh) || !Number.isSafeInteger(highToLow)) {
      throw new LedgerError("Noto'g'ri balans qiymati.");
    }
    return { lowToHigh, highToLow };
  };

  const confirmed = await directionTotalsForStatuses(["confirmed"]);
  const repayments = await directionTotalsForStatuses(["repayment"]);
  if (
    repayments.lowToHigh > confirmed.highToLow ||
    repayments.highToLow > confirmed.lowToHigh
  ) {
    throw new LedgerError(
      "Bu qaytarish mavjud qarz miqdoriga zid. Balansni yangilab, qayta urinib ko'ring.",
    );
  }
  const balance =
    confirmed.lowToHigh -
    confirmed.highToLow +
    repayments.lowToHigh -
    repayments.highToLow;
  if (existing.rows[0]) {
    await client.query(
      "UPDATE debts SET balance_low_to_high = $2, updated_at = NOW() WHERE id = $1",
      [existing.rows[0].id, balance],
    );
  } else {
    await client.query(
      `INSERT INTO debts
        (user_low_id, user_high_id, currency, scope_chat_id, balance_low_to_high, updated_at)
       VALUES ($1, $2, $3, 0, $4, NOW())`,
      [lowId, highId, currency, balance],
    );
  }
}