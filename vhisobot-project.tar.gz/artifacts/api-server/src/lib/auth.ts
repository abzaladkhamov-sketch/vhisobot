import crypto from "node:crypto";
import type { Request, Response } from "express";
import { pool } from "@workspace/db";

const SESSION_SECONDS = 60 * 60 * 24 * 30;
const PIN_UNLOCK_SECONDS = 60 * 5;
const PIN_MAX_ATTEMPTS = 3;
const PIN_LOCK_SECONDS = 60;

type DbUser = {
  id: number | string;
  username: string | null;
  first_name: string;
  last_name: string | null;
  pin_hash: string | null;
  pin_failed_attempts: number | string | null;
  pin_locked_until: Date | string | null;
};

type Claims = {
  sub: number;
  exp: number;
  pinUntil: number | null;
  sid?: string;
};

export type AuthContext = {
  claims: Claims;
  user: DbUser;
};

export type UserProfile = {
  id: number;
  displayName: string;
  username: string | null;
  pinEnabled: boolean;
};

type SqlClient = {
  query: (...args: any[]) => Promise<any>;
};

function getSecret(): string {
  const secret = process.env.SESSION_SECRET;
  if (!secret) {
    throw new Error("SESSION_SECRET must be configured.");
  }
  return secret;
}

function signature(value: string): string {
  return crypto.createHmac("sha256", getSecret()).update(value).digest("base64url");
}

function asNumber(value: number | string): number {
  const parsed = typeof value === "number" ? value : Number(value);
  if (!Number.isSafeInteger(parsed)) {
    throw new Error("Invalid numeric database value.");
  }
  return parsed;
}

function asDate(value: Date | string | null): Date | null {
  if (value == null) return null;
  const date = value instanceof Date ? value : new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
}

export function profileFor(user: DbUser): UserProfile {
  const displayName = user.username
    ? `@${user.username}`
    : [user.first_name, user.last_name].filter(Boolean).join(" ") || "Foydalanuvchi";
  return {
    id: asNumber(user.id),
    displayName,
    username: user.username,
    pinEnabled: Boolean(user.pin_hash),
  };
}

export function issueSession(user: DbUser, unlockPin: boolean, sessionId?: string) {
  const now = Math.floor(Date.now() / 1000);
  const pinUntil = user.pin_hash && unlockPin ? now + PIN_UNLOCK_SECONDS : null;
  const claims: Claims = {
    sub: asNumber(user.id),
    exp: now + SESSION_SECONDS,
    pinUntil,
    ...(sessionId ? { sid: sessionId } : {}),
  };
  const encoded = Buffer.from(JSON.stringify(claims)).toString("base64url");
  return {
    accessToken: `${encoded}.${signature(encoded)}`,
    expiresAt: new Date(claims.exp * 1000).toISOString(),
    pinUnlockedUntil: pinUntil ? new Date(pinUntil * 1000).toISOString() : null,
    user: profileFor(user),
  };
}

function readClaims(req: Request): Claims | null {
  const header = req.header("authorization");
  if (!header?.startsWith("Bearer ")) return null;
  const [encoded, provided] = header.slice("Bearer ".length).split(".");
  if (!encoded || !provided) return null;
  const expected = signature(encoded);
  const actualBuffer = Buffer.from(provided);
  const expectedBuffer = Buffer.from(expected);
  if (
    actualBuffer.length !== expectedBuffer.length ||
    !crypto.timingSafeEqual(actualBuffer, expectedBuffer)
  ) {
    return null;
  }
  try {
    const claims = JSON.parse(Buffer.from(encoded, "base64url").toString("utf8")) as Claims;
    if (
      !Number.isSafeInteger(claims.sub) ||
      !Number.isSafeInteger(claims.exp) ||
      claims.exp <= Math.floor(Date.now() / 1000)
    ) {
      return null;
    }
    return claims;
  } catch {
    return null;
  }
}

export async function requireAuth(
  req: Request,
  res: Response,
): Promise<AuthContext | null> {
  const claims = readClaims(req);
  if (!claims) {
    res.status(401).json({ error: "Kirish sessiyasi tugagan. Botdan yangi kod oling." });
    return null;
  }
  const result = await pool.query<DbUser>(
    `SELECT id, username, first_name, last_name, pin_hash, pin_failed_attempts, pin_locked_until
     FROM users WHERE id = $1`,
    [claims.sub],
  );
  const user = result.rows[0];
  if (!user) {
    res.status(401).json({ error: "Foydalanuvchi topilmadi." });
    return null;
  }
  return { claims, user };
}

export function requirePrivacy(context: AuthContext, res: Response): boolean {
  if (
    context.user.pin_hash &&
    (!context.claims.pinUntil || context.claims.pinUntil <= Math.floor(Date.now() / 1000))
  ) {
    res.status(423).json({ error: "Davom etish uchun PIN kiriting.", code: "PIN_REQUIRED" });
    return false;
  }
  return true;
}

export function verifyPin(pin: string, stored: string): boolean {
  try {
    const [algorithm, iterationsText, salt, expected] = stored.split("$");
    const iterations = Number(iterationsText);
    if (
      algorithm !== "pbkdf2_sha256" ||
      !Number.isInteger(iterations) ||
      iterations < 10_000 ||
      iterations > 1_000_000
    ) {
      return false;
    }
    const digest = crypto.pbkdf2Sync(pin, Buffer.from(salt, "hex"), iterations, 32, "sha256");
    const expectedBuffer = Buffer.from(expected, "hex");
    return expectedBuffer.length === digest.length && crypto.timingSafeEqual(digest, expectedBuffer);
  } catch {
    return false;
  }
}

export async function checkPinLockedOrRecordFailure(
  client: SqlClient,
  user: DbUser,
  pin: string,
): Promise<{ ok: boolean; locked: boolean; remaining: number }> {
  const now = new Date();
  const lockedUntil = asDate(user.pin_locked_until);
  if (lockedUntil && lockedUntil.getTime() > now.getTime()) {
    return { ok: false, locked: true, remaining: 0 };
  }
  if (user.pin_hash && verifyPin(pin, user.pin_hash)) {
    await client.query(
      "UPDATE users SET pin_failed_attempts = 0, pin_locked_until = NULL WHERE id = $1",
      [asNumber(user.id)],
    );
    return { ok: true, locked: false, remaining: PIN_MAX_ATTEMPTS };
  }

  const next = Number(user.pin_failed_attempts ?? 0) + 1;
  if (next >= PIN_MAX_ATTEMPTS) {
    await client.query(
      "UPDATE users SET pin_failed_attempts = 0, pin_locked_until = $2 WHERE id = $1",
      [asNumber(user.id), new Date(now.getTime() + PIN_LOCK_SECONDS * 1000)],
    );
    return { ok: false, locked: true, remaining: 0 };
  }
  await client.query(
    "UPDATE users SET pin_failed_attempts = $2 WHERE id = $1",
    [asNumber(user.id), next],
  );
  return { ok: false, locked: false, remaining: PIN_MAX_ATTEMPTS - next };
}