import { pool } from "@workspace/db";

type PendingDebtNotification = {
  recipientTelegramId: number | string;
  transactionId: number | string;
  senderName: string;
  direction: "received" | "given";
  kind: "debt" | "repayment";
  amount: number;
  currency: string;
  note: string | null;
  dueDate: string | null;
};

export const PENDING_NOTIFICATION_MAX_ATTEMPTS = 5;
export const PENDING_NOTIFICATION_RESEND_COOLDOWN_SECONDS = 60;
const PENDING_NOTIFICATION_RETRY_DELAYS_MS = [250, 1_000] as const;
const PENDING_NOTIFICATION_RETRY_DELAYS_SECONDS = [60, 300, 1_800, 7_200] as const;
const TELEGRAM_API_BASE_URL =
  process.env.TELEGRAM_API_BASE_URL ?? "https://api.telegram.org";

type Queryable = {
  query: (text: string, values?: unknown[]) => Promise<{ rows: any[] }>;
};

type NotificationDelivery = {
  status: "sent" | "unavailable" | "deferred";
  diagnostic?: string;
};

export async function ensurePendingNotificationTable(): Promise<void> {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS pending_notifications (
      id SERIAL PRIMARY KEY,
      transaction_id INTEGER NOT NULL REFERENCES transactions(id) ON DELETE CASCADE,
      recipient_telegram_id BIGINT NOT NULL,
      kind VARCHAR(16) NOT NULL,
      attempt_count INTEGER NOT NULL DEFAULT 0,
      next_attempt_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
      status VARCHAR(24) NOT NULL DEFAULT 'pending',
      last_error TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
      CONSTRAINT uq_pending_notification_transaction UNIQUE (transaction_id)
    )
  `);
  await pool.query(
    "CREATE INDEX IF NOT EXISTS ix_pending_notifications_due " +
    "ON pending_notifications (status, next_attempt_at)",
  );
  await pool.query(
    "ALTER TABLE pending_notifications " +
    "ADD COLUMN IF NOT EXISTS resend_available_at TIMESTAMPTZ",
  );
}

export async function enqueuePendingNotification(
  client: Queryable,
  notification: Pick<PendingDebtNotification, "recipientTelegramId" | "transactionId" | "kind">,
): Promise<void> {
  await client.query(
    `INSERT INTO pending_notifications
       (transaction_id, recipient_telegram_id, kind, next_attempt_at, status)
     VALUES ($1, $2, $3, CURRENT_TIMESTAMP, 'pending')
     ON CONFLICT (transaction_id) DO NOTHING`,
    [
      notification.transactionId,
      notification.recipientTelegramId,
      notification.kind,
    ],
  );
}

async function claimPendingNotification(
  transactionId: number | string,
): Promise<number | null> {
  const delaySeconds = PENDING_NOTIFICATION_RETRY_DELAYS_SECONDS[0];
  const result = await pool.query<{ attempt_count: number | string }>(
    `UPDATE pending_notifications AS notification
     SET attempt_count = notification.attempt_count + 1,
         next_attempt_at = CURRENT_TIMESTAMP + ($2 * INTERVAL '1 second')
     WHERE notification.transaction_id = $1
       AND notification.status = 'pending'
       AND notification.next_attempt_at <= CURRENT_TIMESTAMP
       AND notification.attempt_count < $3
       AND EXISTS (
         SELECT 1 FROM transactions AS tx
         WHERE tx.id = notification.transaction_id
           AND tx.status IN ('pending', 'repayment_pending')
       )
     RETURNING attempt_count`,
    [transactionId, delaySeconds, PENDING_NOTIFICATION_MAX_ATTEMPTS],
  );
  return result.rows[0] ? Number(result.rows[0].attempt_count) : null;
}

async function finishPendingNotification(
  transactionId: number | string,
  delivery: "sent" | "unavailable" | "deferred",
  attemptCount: number,
  diagnostic?: string,
): Promise<void> {
  const permanent =
    delivery === "unavailable" ||
    attemptCount >= PENDING_NOTIFICATION_MAX_ATTEMPTS;
  const delayIndex = Math.min(
    Math.max(attemptCount - 1, 0),
    PENDING_NOTIFICATION_RETRY_DELAYS_SECONDS.length - 1,
  );
  await pool.query(
    `UPDATE pending_notifications
     SET status = $2::varchar,
         next_attempt_at = CASE WHEN $2::varchar = 'pending'
           THEN CURRENT_TIMESTAMP + ($3 * INTERVAL '1 second')
           ELSE next_attempt_at END,
         last_error = $4
     WHERE transaction_id = $1`,
    [
      transactionId,
      delivery === "sent"
        ? "sent"
        : permanent
          ? "permanent_failure"
          : "pending",
      PENDING_NOTIFICATION_RETRY_DELAYS_SECONDS[delayIndex],
      delivery === "sent" ? null : diagnostic ?? delivery,
    ],
  );
}

async function responseDiagnostic(response: Response): Promise<string> {
  const body = await response.text();
  try {
    const parsed = JSON.parse(body) as { description?: unknown };
    if (typeof parsed.description === "string" && parsed.description.length > 0) {
      return parsed.description;
    }
  } catch {
    // Keep the raw response body as a server-side diagnostic when it is not JSON.
  }
  return body || `Telegram request failed with status ${response.status}`;
}

function escapeHtml(value: string): string {
  return value.replace(/[&<>"']/g, (character) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;",
  })[character] ?? character);
}

/**
 * Delivery is best-effort. Transient Telegram failures receive bounded
 * retries, while the bot's /pending command remains the durable review path
 * when delivery is unavailable.
 */
export async function notifyPendingDebt(
  notification: PendingDebtNotification,
): Promise<NotificationDelivery> {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) return { status: "deferred" };

  const money = `${new Intl.NumberFormat("uz-UZ").format(notification.amount)} ${notification.currency}`;
  const sender = escapeHtml(notification.senderName);
  const counterpartyView =
    notification.kind === "repayment"
      ? `Siz <b>${sender}</b> dan <b>${money}</b> qaytaruv oldingiz.`
      : notification.direction === "received"
        ? `Siz <b>${sender}</b> ga <b>${money}</b> berdingiz.`
        : `Siz <b>${sender}</b> dan <b>${money}</b> oldingiz.`;
  const note = notification.note ? `\nIzoh: ${escapeHtml(notification.note)}` : "";
  const due = notification.dueDate ? `\nMuddat: ${notification.dueDate}` : "";

  const request = {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      chat_id: notification.recipientTelegramId,
      parse_mode: "HTML",
      text:
        `🔔 <b>Yangi ${notification.kind === "repayment" ? "qaytaruv" : "tranzaksiya"} — tasdiqlash kerak</b>\n\n` +
        `${counterpartyView}${note}${due}\n\n` +
        "To'g'ri bo'lsa tasdiqlang, xato bo'lsa rad eting:",
      reply_markup: {
        inline_keyboard: [[
          { text: "✅ Tasdiqlash", callback_data: `txconfirm:${notification.transactionId}` },
          { text: "❌ Rad etish", callback_data: `txreject:${notification.transactionId}` },
        ]],
      },
    }),
  };

  let diagnostic = "Telegram request failed";
  for (let attempt = 0; attempt <= PENDING_NOTIFICATION_RETRY_DELAYS_MS.length; attempt += 1) {
    try {
      const response = await fetch(
        `${TELEGRAM_API_BASE_URL.replace(/\/$/, "")}/bot${token}/sendMessage`,
        request,
      );
      if (response.ok) return { status: "sent" };
      diagnostic = await responseDiagnostic(response);
      if (response.status === 400 || response.status === 403) {
        return { status: "unavailable", diagnostic };
      }
    } catch (error) {
      diagnostic = error instanceof Error ? error.message : "Telegram request failed";
    }

    if (attempt < PENDING_NOTIFICATION_RETRY_DELAYS_MS.length) {
      await new Promise((resolve) => setTimeout(resolve, PENDING_NOTIFICATION_RETRY_DELAYS_MS[attempt]));
    }
  }
  return { status: "deferred", diagnostic };
}

/**
 * Claim and deliver a queued request. The claim is shared with the Telegram
 * bot through the database, so concurrent services do not send duplicates.
 */
export async function deliverPendingDebtNotification(
  notification: PendingDebtNotification,
): Promise<"sent" | "unavailable" | "deferred" | "not_due"> {
  const attemptCount = await claimPendingNotification(notification.transactionId);
  if (attemptCount === null) return "not_due";
  const delivery = await notifyPendingDebt(notification);
  await finishPendingNotification(
    notification.transactionId,
    delivery.status,
    attemptCount,
    delivery.diagnostic,
  );
  return delivery.status;
}
