export type StoredDeliveryStatus = "pending" | "sent" | "permanent_failure" | null | undefined;
export type PublicDeliveryStatus = "pending" | "sent" | "manual_review";

export function publicDeliveryStatus(
  status: StoredDeliveryStatus,
): PublicDeliveryStatus | null {
  switch (status) {
    case "pending":
      return "pending";
    case "sent":
      return "sent";
    case "permanent_failure":
      return "manual_review";
    default:
      return null;
  }
}