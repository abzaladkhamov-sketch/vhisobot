import { randomUUID } from "node:crypto";
import { Router, type IRouter, type NextFunction, type Request, type Response } from "express";
import { issueSession, type UserProfile } from "../lib/auth";
import {
  publicDeliveryStatus,
  type StoredDeliveryStatus,
} from "../lib/telegram-delivery";

/**
 * The browser fixture is deliberately not backed by PostgreSQL. It is only
 * available outside production and requires a test-only header to mint a
 * session. Every minted token gets its own in-memory ledger.
 */
const FIXTURE_HEADER = "x-qarz-test-fixture";
const FIXTURE_HEADER_VALUE = "1";
const FIXTURE_USER_ID = 900_000_001;
const SHARED_FIXTURE_USER_ID = 900_000_004;
const OUTSIDER_FIXTURE_USER_ID = 900_000_005;

type FixtureUser = {
  id: number;
  username: string;
  first_name: string;
  last_name: null;
  pin_hash: null;
  pin_failed_attempts: number;
  pin_locked_until: null;
};

type FixtureTransaction = {
  id: number;
  debtorId: number;
  creditorId: number;
  enteredById: number;
  counterparty: { id: number; displayName: string; username: string | null };
  amount: number;
  currency: string;
  status: "pending" | "repayment_pending" | "confirmed" | "rejected" | "repayment";
  deliveryStatus: StoredDeliveryStatus;
  last_error?: string | null;
  note: string | null;
  dueDate: string | null;
  createdAt: string;
  canHide?: boolean;
};

type FixtureState = {
  user: UserProfile;
  transactions: FixtureTransaction[];
  hiddenTransactionIds: Set<number>;
};

const sessions = new Map<string, FixtureState>();

const fixtureUser: FixtureUser = {
  id: FIXTURE_USER_ID,
  username: "qa_fixture",
  first_name: "Test",
  last_name: null,
  pin_hash: null,
  pin_failed_attempts: 0,
  pin_locked_until: null,
};

const contacts = [
  { id: 900_000_002, displayName: "Aziza Karimova", username: "aziza_qa" },
  { id: 900_000_003, displayName: "Bekzod Aliyev", username: "bekzod_qa" },
];

function seedTransactions(): FixtureTransaction[] {
  const createdAt = "2026-08-20T10:00:00.000Z";
  const counterparty = contacts[0];
  return [
    {
      id: 910_000_001,
      debtorId: FIXTURE_USER_ID,
      creditorId: counterparty.id,
      enteredById: counterparty.id,
      counterparty,
      amount: 125_000,
      currency: "UZS",
      status: "pending",
      deliveryStatus: "permanent_failure",
      last_error: "Telegram bot was blocked by the recipient",
      note: "Tasdiqlanishi kerak bo‘lgan qarz",
      dueDate: "2026-09-01",
      createdAt,
    },
    {
      id: 910_000_002,
      debtorId: FIXTURE_USER_ID,
      creditorId: counterparty.id,
      enteredById: FIXTURE_USER_ID,
      counterparty,
      amount: 80,
      currency: "USD",
      status: "pending",
      deliveryStatus: "sent",
      note: "Men yuborgan so‘rov",
      dueDate: null,
      createdAt,
    },
    {
      id: 910_000_003,
      debtorId: FIXTURE_USER_ID,
      creditorId: counterparty.id,
      enteredById: FIXTURE_USER_ID,
      counterparty,
      amount: 300_000,
      currency: "UZS",
      status: "confirmed",
      deliveryStatus: null,
      note: "Tasdiqlangan qarz",
      dueDate: null,
      createdAt,
    },
    {
      id: 910_000_004,
      debtorId: counterparty.id,
      creditorId: FIXTURE_USER_ID,
      enteredById: counterparty.id,
      counterparty,
      amount: 50,
      currency: "USD",
      status: "rejected",
      deliveryStatus: null,
      note: "Rad etilgan so‘rov",
      dueDate: null,
      createdAt,
    },
    {
      id: 910_000_005,
      debtorId: counterparty.id,
      creditorId: FIXTURE_USER_ID,
      enteredById: FIXTURE_USER_ID,
      counterparty,
      amount: 40,
      currency: "USD",
      status: "repayment",
      deliveryStatus: null,
      note: "Qarz qaytarildi",
      dueDate: null,
      createdAt,
    },
    {
      id: 910_000_006,
      debtorId: FIXTURE_USER_ID,
      creditorId: counterparty.id,
      enteredById: counterparty.id,
      counterparty,
      amount: 25,
      currency: "USD",
      status: "repayment_pending",
      deliveryStatus: "sent",
      note: "Tasdiqlanishi kerak bo‘lgan qaytaruv",
      dueDate: null,
      createdAt,
    },
    {
      id: 910_000_007,
      debtorId: FIXTURE_USER_ID,
      creditorId: counterparty.id,
      enteredById: counterparty.id,
      counterparty,
      amount: 15,
      currency: "USD",
      status: "repayment_pending",
      deliveryStatus: "permanent_failure",
      last_error: "Telegram bot was blocked by the recipient",
      note: "Yetkazilmagan qaytaruv so‘rovi",
      dueDate: null,
      createdAt,
    },
  ];
}

function seedSharedTransactions(currentUserId: number): FixtureTransaction[] {
  const other =
    currentUserId === FIXTURE_USER_ID
      ? { id: SHARED_FIXTURE_USER_ID, displayName: "@qa_shared_bob", username: "qa_shared_bob" }
      : { id: FIXTURE_USER_ID, displayName: "@qa_fixture", username: "qa_fixture" };
  return [
    {
      id: 930_000_001,
      debtorId: FIXTURE_USER_ID,
      creditorId: SHARED_FIXTURE_USER_ID,
      enteredById: FIXTURE_USER_ID,
      counterparty: other,
      amount: 50,
      currency: "USD",
      status: "rejected",
      deliveryStatus: null,
      note: "Ikki foydalanuvchili rad etilgan yozuv",
      dueDate: null,
      createdAt: "2026-08-21T10:00:00.000Z",
    },
    {
      id: 930_000_002,
      debtorId: FIXTURE_USER_ID,
      creditorId: SHARED_FIXTURE_USER_ID,
      enteredById: FIXTURE_USER_ID,
      counterparty: other,
      amount: 300_000,
      currency: "UZS",
      status: "confirmed",
      deliveryStatus: null,
      note: "Faol yozuv yashirilmasin",
      dueDate: null,
      createdAt: "2026-08-22T10:00:00.000Z",
    },
  ];
}

function fixtureUserForVariant(variant: string): FixtureUser {
  if (variant === "shared-bob") {
    return {
      ...fixtureUser,
      id: SHARED_FIXTURE_USER_ID,
      username: "qa_shared_bob",
      first_name: "Shared Bob",
    };
  }
  if (variant === "outsider") {
    return {
      ...fixtureUser,
      id: OUTSIDER_FIXTURE_USER_ID,
      username: "qa_outsider",
      first_name: "Outsider",
    };
  }
  return fixtureUser;
}

function stateFor(req: Request): FixtureState | null {
  if (process.env.NODE_ENV === "production") return null;
  const authorization = req.header("authorization");
  if (!authorization?.startsWith("Bearer ")) return null;
  return sessions.get(authorization.slice("Bearer ".length)) ?? null;
}

function newState(fixture: FixtureUser, variant: string): FixtureState {
  const shared =
    variant === "shared-alice" || variant === "shared-bob" || variant === "outsider";
  return {
    user: {
      id: fixture.id,
      displayName: `@${fixture.username}`,
      username: fixture.username,
      pinEnabled: false,
    },
    transactions: shared ? seedSharedTransactions(fixture.id) : seedTransactions(),
    hiddenTransactionIds: new Set(),
  };
}

function sendTransactionError(res: Response, message: string, status = 400): void {
  res.status(status).json({ error: message });
}

function transactionForInput(
  state: FixtureState,
  input: {
    contactId: number;
    direction: "received" | "given";
    amount: number;
    currency: string;
    note?: string | null;
    dueDate?: string | null;
  },
): FixtureTransaction {
  const counterparty = contacts.find((contact) => contact.id === input.contactId) ?? contacts[0];
  const enteredById = state.user.id;
  return {
    id: 920_000_000 + state.transactions.length + 1,
    debtorId: input.direction === "received" ? state.user.id : counterparty.id,
    creditorId: input.direction === "received" ? counterparty.id : state.user.id,
    enteredById,
    counterparty,
    amount: input.amount,
    currency: input.currency,
    status: "pending",
    deliveryStatus: "pending",
    note: input.note ?? null,
    dueDate: input.dueDate ?? null,
    createdAt: new Date().toISOString(),
  };
}

function publicTransactionFor(transaction: FixtureTransaction) {
  const { deliveryStatus, last_error: _lastError, ...safeTransaction } = transaction;
  return {
    ...safeTransaction,
    deliveryStatus: publicDeliveryStatus(deliveryStatus),
  };
}

function canHideTransaction(state: FixtureState, transaction: FixtureTransaction): boolean {
  if (transaction.status === "rejected") return true;
  if (transaction.status !== "confirmed" && transaction.status !== "repayment") return false;
  const pairTransactions = state.transactions
    .filter(
      (candidate) =>
        candidate.counterparty.id === transaction.counterparty.id &&
        candidate.currency === transaction.currency &&
        (candidate.status === "confirmed" || candidate.status === "repayment"),
    );
  const confirmedUserOwes = pairTransactions
    .filter((candidate) => candidate.status === "confirmed")
    .reduce(
      (total, candidate) =>
        total + (candidate.debtorId === state.user.id ? candidate.amount : 0),
      0,
    );
  const confirmedOtherOwes = pairTransactions
    .filter((candidate) => candidate.status === "confirmed")
    .reduce(
      (total, candidate) =>
        total + (candidate.creditorId === state.user.id ? candidate.amount : 0),
      0,
    );
  const repaymentsToOther = pairTransactions
    .filter((candidate) => candidate.status === "repayment")
    .reduce(
      (total, candidate) =>
        total + (candidate.debtorId === state.user.id ? candidate.amount : 0),
      0,
    );
  const repaymentsToUser = pairTransactions
    .filter((candidate) => candidate.status === "repayment")
    .reduce(
      (total, candidate) =>
        total + (candidate.creditorId === state.user.id ? candidate.amount : 0),
      0,
    );
  return (
    repaymentsToOther === confirmedOtherOwes &&
    repaymentsToUser === confirmedUserOwes
  );
}

const router: IRouter = Router();

router.post("/auth/test-session", (req, res): void => {
  if (
    process.env.NODE_ENV === "production" ||
    req.header(FIXTURE_HEADER) !== FIXTURE_HEADER_VALUE
  ) {
    res.status(404).json({ error: "Test fixture mavjud emas." });
    return;
  }

  const variant = req.header("x-qarz-test-user") ?? "default";
  const user = fixtureUserForVariant(variant);
  const session = issueSession(user, false, randomUUID());
  sessions.set(session.accessToken, newState(user, variant));
  while (sessions.size > 50) {
    const oldest = sessions.keys().next().value;
    if (oldest) sessions.delete(oldest);
    else break;
  }
  res.json(session);
});

router.get("/me", (req, res, next: NextFunction): void => {
  const state = stateFor(req);
  if (!state) return next();
  res.json(state.user);
});

router.get("/contacts", (req, res, next: NextFunction): void => {
  const state = stateFor(req);
  if (!state) return next();
  res.json(contacts);
});

router.get("/transactions", (req, res, next: NextFunction): void => {
  const state = stateFor(req);
  if (!state) return next();
  const contactId = Number(req.query.contactId);
  const transactions =
    Number.isSafeInteger(contactId) && contactId > 0
      ? state.transactions.filter(
          (transaction) =>
            (transaction.debtorId === state.user.id || transaction.creditorId === state.user.id) &&
            transaction.counterparty.id === contactId,
        )
      : state.transactions.filter(
          (transaction) =>
            transaction.debtorId === state.user.id || transaction.creditorId === state.user.id,
        );
  res.json(
    transactions
      .filter((transaction) => !state.hiddenTransactionIds.has(transaction.id))
      .map((transaction) => ({
        ...publicTransactionFor(transaction),
        canHide: canHideTransaction(state, transaction),
      })),
  );
});

router.get("/dashboard", (req, res, next: NextFunction): void => {
  const state = stateFor(req);
  if (!state) return next();
  const confirmed = state.transactions.filter((transaction) => transaction.status === "confirmed");
  const repayments = state.transactions.filter((transaction) => transaction.status === "repayment");
  const pendingCount = state.transactions.filter(
    (transaction) =>
      transaction.status === "pending" || transaction.status === "repayment_pending",
  ).length;
  res.json({
    balances: [
      {
        contact: contacts[0],
        amount: Math.max(
          0,
          confirmed
            .filter((transaction) => transaction.debtorId === state.user.id)
            .reduce((total, transaction) => total + transaction.amount, 0) -
            repayments
              .filter((transaction) => transaction.enteredById === state.user.id)
              .reduce((total, transaction) => total + transaction.amount, 0),
        ),
        currency: "UZS",
        userOwesOther: true,
        lentTotal: 0,
        borrowedTotal: confirmed
          .filter((transaction) => transaction.debtorId === state.user.id)
          .reduce((total, transaction) => total + transaction.amount, 0),
        repaidByUser: repayments
          .filter((transaction) => transaction.enteredById === state.user.id)
          .reduce((total, transaction) => total + transaction.amount, 0),
        repaidToUser: 0,
      },
    ],
    recentTransactions: state.transactions
      .filter((transaction) => !state.hiddenTransactionIds.has(transaction.id))
      .slice(-5)
      .reverse()
      .map(publicTransactionFor),
    pendingCount,
    dueSoonCount: 0,
  });
});

router.post("/transactions/:transactionId/hide", (req, res, next: NextFunction): void => {
  const state = stateFor(req);
  if (!state) return next();
  const transaction = state.transactions.find(
    (candidate) => candidate.id === Number(req.params.transactionId),
  );
  if (!transaction) {
    sendTransactionError(res, "Tranzaksiya topilmadi.", 404);
    return;
  }
  if (transaction.debtorId !== state.user.id && transaction.creditorId !== state.user.id) {
    sendTransactionError(res, "Bu yozuvni yashirishga ruxsat yo'q.", 403);
    return;
  }
  if (!canHideTransaction(state, transaction)) {
    sendTransactionError(
      res,
      "Faqat rad etilgan yoki to'liq yopilgan qarzni yashirish mumkin.",
      409,
    );
    return;
  }
  state.hiddenTransactionIds.add(transaction.id);
  res.json({ hidden: true });
});

router.post("/transactions", (req, res, next: NextFunction): void => {
  const state = stateFor(req);
  if (!state) return next();
  const { contactId, direction, amount, currency, note, dueDate } = req.body ?? {};
  if (
    !Number.isSafeInteger(contactId) ||
    !["received", "given"].includes(direction) ||
    !Number.isSafeInteger(amount) ||
    amount <= 0 ||
    typeof currency !== "string" ||
    !/^[A-Z]{3}$/.test(currency)
  ) {
    sendTransactionError(res, "Test fixture ma'lumotlari noto'g'ri.");
    return;
  }
  const transaction = transactionForInput(state, {
    contactId,
    direction,
    amount,
    currency,
    note,
    dueDate,
  });
  state.transactions.push(transaction);
  res.status(201).json(publicTransactionFor(transaction));
});

router.post("/transactions/:transactionId/decision", (req, res, next: NextFunction): void => {
  const state = stateFor(req);
  if (!state) return next();
  const transaction = state.transactions.find(
    (candidate) => candidate.id === Number(req.params.transactionId),
  );
  if (
    !transaction ||
    (transaction.status !== "pending" && transaction.status !== "repayment_pending")
  ) {
    sendTransactionError(res, "Tasdiqlash kutilayotgan tranzaksiya topilmadi.", 404);
    return;
  }
  if (req.body?.decision !== "confirmed" && req.body?.decision !== "rejected") {
    sendTransactionError(res, "Qaror noto'g'ri.");
    return;
  }
  transaction.status =
    req.body.decision === "rejected"
      ? "rejected"
      : transaction.status === "repayment_pending"
        ? "repayment"
        : "confirmed";
  transaction.deliveryStatus = null;
  transaction.canHide = transaction.status === "rejected";
  res.json(publicTransactionFor(transaction));
});

router.post("/repayments", (req, res, next: NextFunction): void => {
  const state = stateFor(req);
  if (!state) return next();
  const { contactId, amount, currency, note } = req.body ?? {};
  const counterparty = contacts.find((contact) => contact.id === contactId) ?? contacts[0];
  if (
    !Number.isSafeInteger(contactId) ||
    !Number.isSafeInteger(amount) ||
    amount <= 0 ||
    typeof currency !== "string" ||
    !/^[A-Z]{3}$/.test(currency)
  ) {
    sendTransactionError(res, "Test fixture qaytaruv ma'lumotlari noto'g'ri.");
    return;
  }
  const transaction: FixtureTransaction = {
    id: 920_000_000 + state.transactions.length + 1,
    debtorId: counterparty.id,
    creditorId: state.user.id,
    enteredById: state.user.id,
    counterparty,
    amount,
    currency,
    status: "repayment_pending",
    deliveryStatus: "pending",
    note: note ?? "Qarz qaytarildi",
    dueDate: null,
    createdAt: new Date().toISOString(),
  };
  state.transactions.push(transaction);
  res.status(201).json(publicTransactionFor(transaction));
});

export default router;