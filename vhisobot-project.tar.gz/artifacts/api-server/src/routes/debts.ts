import { Router, type IRouter } from "express";
import { pool } from "@workspace/db";
import {
  CreateRepaymentBody,
  CreateRepaymentResponse,
  CreateTransactionBody,
  CreateTransactionResponse,
  DecideTransactionBody,
  DecideTransactionParams,
  DecideTransactionResponse,
  GetDashboardResponse,
  HideTransactionParams,
  HideTransactionResponse,
  ListContactsResponse,
  ListTransactionsQueryParams,
  ListTransactionsResponse,
} from "@workspace/api-zod";
import { profileFor, requireAuth, requirePrivacy } from "../lib/auth";
import { LedgerError, acquireDebtPairLock, recalculateDebt } from "../lib/ledger";
import {
  deliverPendingDebtNotification,
  enqueuePendingNotification,
  PENDING_NOTIFICATION_RESEND_COOLDOWN_SECONDS,
} from "../lib/telegram";
import {
  publicDeliveryStatus,
  type PublicDeliveryStatus,
} from "../lib/telegram-delivery";

type ContactRow = {
  id: number | string;
  telegram_id?: number | string;
  username: string | null;
  first_name: string;
  last_name: string | null;
};

type TransactionRow = {
  id: number | string;
  debtor_id: number | string;
  creditor_id: number | string;
  entered_by_id: number | string;
  amount: number | string;
  currency: string;
  status: "pending" | "repayment_pending" | "confirmed" | "rejected" | "repayment";
  delivery_status?: "pending" | "sent" | "permanent_failure" | null;
  note: string | null;
  due_date: Date | string | null;
  created_at: Date | string;
  counterparty_id: number | string;
  counterparty_username: string | null;
  counterparty_first_name: string;
  counterparty_last_name: string | null;
  can_hide?: boolean;
};

const router: IRouter = Router();

function toSafeNumber(value: number | string): number {
  const parsed = typeof value === "number" ? value : Number(value);
  if (!Number.isSafeInteger(parsed)) throw new Error("Noto'g'ri summa yoki identifikator.");
  return parsed;
}

function contactFor(row: ContactRow) {
  return {
    id: toSafeNumber(row.id),
    displayName: row.username
      ? `@${row.username}`
      : [row.first_name, row.last_name].filter(Boolean).join(" ") || "Foydalanuvchi",
    username: row.username,
  };
}

function isoDate(value: Date | string | null): string | null {
  if (value == null) return null;
  if (value instanceof Date) return value.toISOString().slice(0, 10);
  return String(value).slice(0, 10);
}

function isoDateTime(value: Date | string): string {
  return value instanceof Date ? value.toISOString() : new Date(value).toISOString();
}

function transactionFor(row: TransactionRow, deliveryStatus?: PublicDeliveryStatus | null) {
  const safeDeliveryStatus =
    deliveryStatus === undefined ? publicDeliveryStatus(row.delivery_status) : deliveryStatus;
  return {
    id: toSafeNumber(row.id),
    debtorId: toSafeNumber(row.debtor_id),
    creditorId: toSafeNumber(row.creditor_id),
    enteredById: toSafeNumber(row.entered_by_id),
    counterparty: contactFor({
      id: row.counterparty_id,
      username: row.counterparty_username,
      first_name: row.counterparty_first_name,
      last_name: row.counterparty_last_name,
    }),
    amount: toSafeNumber(row.amount),
    currency: row.currency,
    status: row.status,
    deliveryStatus: safeDeliveryStatus,
    note: row.note,
    dueDate: isoDate(row.due_date),
    createdAt: isoDateTime(row.created_at),
    canHide: row.can_hide ?? false,
  };
}

const canHideSql = `
  (
    t.status = 'rejected'
    OR (
      t.status IN ('confirmed', 'repayment')
      AND COALESCE((
        SELECT SUM(
          CASE WHEN repayment_low.debtor_id = LEAST(t.debtor_id, t.creditor_id)
            THEN repayment_low.amount ELSE 0 END
        )
        FROM transactions repayment_low
        WHERE repayment_low.debtor_id IN (LEAST(t.debtor_id, t.creditor_id), GREATEST(t.debtor_id, t.creditor_id))
          AND repayment_low.creditor_id IN (LEAST(t.debtor_id, t.creditor_id), GREATEST(t.debtor_id, t.creditor_id))
          AND repayment_low.debtor_id <> repayment_low.creditor_id
          AND repayment_low.currency = t.currency
          AND repayment_low.scope_chat_id = t.scope_chat_id
          AND repayment_low.status = 'repayment'
      ), 0) = COALESCE((
        SELECT SUM(
          CASE WHEN confirmed_high.debtor_id = GREATEST(t.debtor_id, t.creditor_id)
            THEN confirmed_high.amount ELSE 0 END
        )
        FROM transactions confirmed_high
        WHERE confirmed_high.debtor_id IN (LEAST(t.debtor_id, t.creditor_id), GREATEST(t.debtor_id, t.creditor_id))
          AND confirmed_high.creditor_id IN (LEAST(t.debtor_id, t.creditor_id), GREATEST(t.debtor_id, t.creditor_id))
          AND confirmed_high.debtor_id <> confirmed_high.creditor_id
          AND confirmed_high.currency = t.currency
          AND confirmed_high.scope_chat_id = t.scope_chat_id
          AND confirmed_high.status = 'confirmed'
      ), 0)
      AND COALESCE((
        SELECT SUM(
          CASE WHEN repayment_high.debtor_id = GREATEST(t.debtor_id, t.creditor_id)
            THEN repayment_high.amount ELSE 0 END
        )
        FROM transactions repayment_high
        WHERE repayment_high.debtor_id IN (LEAST(t.debtor_id, t.creditor_id), GREATEST(t.debtor_id, t.creditor_id))
          AND repayment_high.creditor_id IN (LEAST(t.debtor_id, t.creditor_id), GREATEST(t.debtor_id, t.creditor_id))
          AND repayment_high.debtor_id <> repayment_high.creditor_id
          AND repayment_high.currency = t.currency
          AND repayment_high.scope_chat_id = t.scope_chat_id
          AND repayment_high.status = 'repayment'
      ), 0) = COALESCE((
        SELECT SUM(
          CASE WHEN confirmed_low.debtor_id = LEAST(t.debtor_id, t.creditor_id)
            THEN confirmed_low.amount ELSE 0 END
        )
        FROM transactions confirmed_low
        WHERE confirmed_low.debtor_id IN (LEAST(t.debtor_id, t.creditor_id), GREATEST(t.debtor_id, t.creditor_id))
          AND confirmed_low.creditor_id IN (LEAST(t.debtor_id, t.creditor_id), GREATEST(t.debtor_id, t.creditor_id))
          AND confirmed_low.debtor_id <> confirmed_low.creditor_id
          AND confirmed_low.currency = t.currency
          AND confirmed_low.scope_chat_id = t.scope_chat_id
          AND confirmed_low.status = 'confirmed'
      ), 0)
    )
  )
`;

async function verifyContact(userId: number, contactId: number): Promise<ContactRow | null> {
  const result = await pool.query<ContactRow>(
    `SELECT u.id, u.telegram_id, u.username, u.first_name, u.last_name
     FROM user_links l
     JOIN users u ON u.id = l.contact_id
     WHERE l.user_id = $1 AND l.contact_id = $2`,
    [userId, contactId],
  );
  return result.rows[0] ?? null;
}

async function getTransaction(
  transactionId: number,
  userId: number,
): Promise<TransactionRow | null> {
  const result = await pool.query<TransactionRow>(
    `SELECT t.*,
            c.id AS counterparty_id, c.username AS counterparty_username,
            c.first_name AS counterparty_first_name, c.last_name AS counterparty_last_name
     FROM transactions t
     JOIN users c ON c.id = CASE WHEN t.debtor_id = $1 THEN t.creditor_id ELSE t.debtor_id END
     WHERE t.id = $2
       AND t.scope_chat_id = 0
       AND (t.debtor_id = $1 OR t.creditor_id = $1)`,
    [userId, transactionId],
  );
  return result.rows[0] ?? null;
}

router.get("/dashboard", async (req, res): Promise<void> => {
  const context = await requireAuth(req, res);
  if (!context || !requirePrivacy(context, res)) return;
  const userId = Number(context.user.id);
  const [balancesResult, recentResult, pendingResult, dueResult] = await Promise.all([
    pool.query<{
      balance_low_to_high: number | string;
      user_low_id: number | string;
      user_high_id: number | string;
      id: number | string;
      username: string | null;
      first_name: string;
      last_name: string | null;
      currency: string;
      lent_total: number | string;
      borrowed_total: number | string;
      repaid_by_user: number | string;
      repaid_to_user: number | string;
    }>(
      `SELECT d.balance_low_to_high, d.user_low_id, d.user_high_id, d.currency,
              u.id, u.username, u.first_name, u.last_name,
              COALESCE(SUM(CASE WHEN t.status = 'confirmed' AND t.creditor_id = $1 THEN t.amount ELSE 0 END), 0)::text AS lent_total,
              COALESCE(SUM(CASE WHEN t.status = 'confirmed' AND t.debtor_id = $1 THEN t.amount ELSE 0 END), 0)::text AS borrowed_total,
              COALESCE(SUM(CASE WHEN t.status = 'repayment' AND t.entered_by_id = $1 THEN t.amount ELSE 0 END), 0)::text AS repaid_by_user,
              COALESCE(SUM(CASE WHEN t.status = 'repayment' AND t.entered_by_id <> $1 THEN t.amount ELSE 0 END), 0)::text AS repaid_to_user
       FROM debts d
       JOIN users u ON u.id = CASE WHEN d.user_low_id = $1 THEN d.user_high_id ELSE d.user_low_id END
       LEFT JOIN transactions t
         ON t.scope_chat_id = 0
        AND t.currency = d.currency
        AND (
          (t.debtor_id = $1 AND t.creditor_id = u.id)
          OR (t.debtor_id = u.id AND t.creditor_id = $1)
        )
       WHERE d.scope_chat_id = 0
         AND (d.user_low_id = $1 OR d.user_high_id = $1)
         AND d.balance_low_to_high <> 0
       GROUP BY d.id, d.balance_low_to_high, d.user_low_id, d.user_high_id, d.currency,
                u.id, u.username, u.first_name, u.last_name
       ORDER BY ABS(d.balance_low_to_high) DESC`,
      [userId],
    ),
    pool.query<TransactionRow>(
      `SELECT t.*,
              c.id AS counterparty_id, c.username AS counterparty_username,
              c.first_name AS counterparty_first_name, c.last_name AS counterparty_last_name,
              CASE WHEN t.status IN ('pending', 'repayment_pending') THEN pn.status ELSE NULL END AS delivery_status
       FROM transactions t
       JOIN users c ON c.id = CASE WHEN t.debtor_id = $1 THEN t.creditor_id ELSE t.debtor_id END
       LEFT JOIN pending_notifications pn ON pn.transaction_id = t.id
       WHERE t.scope_chat_id = 0 AND (t.debtor_id = $1 OR t.creditor_id = $1)
         AND NOT EXISTS (
           SELECT 1 FROM transaction_history_hides hidden
           WHERE hidden.transaction_id = t.id AND hidden.user_id = $1
         )
       ORDER BY t.created_at DESC LIMIT 8`,
      [userId],
    ),
    pool.query<{ count: string }>(
       `SELECT COUNT(*)::text AS count FROM transactions
        WHERE scope_chat_id = 0 AND status IN ('pending', 'repayment_pending')
         AND entered_by_id <> $1 AND (debtor_id = $1 OR creditor_id = $1)`,
      [userId],
    ),
    pool.query<{ count: string }>(
      `SELECT COUNT(*)::text AS count FROM transactions
       WHERE scope_chat_id = 0 AND status IN ('pending', 'confirmed')
         AND due_date IS NOT NULL AND due_date <= CURRENT_DATE + INTERVAL '7 days'
         AND (debtor_id = $1 OR creditor_id = $1)`,
      [userId],
    ),
  ]);

  const balances = balancesResult.rows.map((row) => {
    const balance = toSafeNumber(row.balance_low_to_high);
    const isLow = toSafeNumber(row.user_low_id) === userId;
    return {
      contact: contactFor(row),
      amount: Math.abs(balance),
      currency: row.currency,
      userOwesOther: isLow ? balance > 0 : balance < 0,
      lentTotal: toSafeNumber(row.lent_total),
      borrowedTotal: toSafeNumber(row.borrowed_total),
      repaidByUser: toSafeNumber(row.repaid_by_user),
      repaidToUser: toSafeNumber(row.repaid_to_user),
    };
  });
  res.json(
    GetDashboardResponse.parse({
      balances,
       recentTransactions: recentResult.rows.map((row) => transactionFor(row)),
      pendingCount: Number(pendingResult.rows[0]?.count ?? 0),
      dueSoonCount: Number(dueResult.rows[0]?.count ?? 0),
    }),
  );
});

router.get("/contacts", async (req, res): Promise<void> => {
  const context = await requireAuth(req, res);
  if (!context || !requirePrivacy(context, res)) return;
  const result = await pool.query<ContactRow>(
    `SELECT u.id, u.username, u.first_name, u.last_name
     FROM user_links l JOIN users u ON u.id = l.contact_id
     WHERE l.user_id = $1 ORDER BY u.first_name, u.last_name`,
    [context.user.id],
  );
  res.json(ListContactsResponse.parse(result.rows.map(contactFor)));
});

router.get("/transactions", async (req, res): Promise<void> => {
  const context = await requireAuth(req, res);
  if (!context || !requirePrivacy(context, res)) return;
  const parsed = ListTransactionsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: "Kontakt filtri noto'g'ri." });
    return;
  }
  const contactId = parsed.data.contactId;
  if (contactId !== undefined && (!Number.isInteger(contactId) || contactId <= 0)) {
    res.status(400).json({ error: "Kontakt identifikatori noto'g'ri." });
    return;
  }
  const result = await pool.query<TransactionRow>(
    `SELECT t.*,
            c.id AS counterparty_id, c.username AS counterparty_username,
            c.first_name AS counterparty_first_name, c.last_name AS counterparty_last_name,
            CASE WHEN t.status IN ('pending', 'repayment_pending') THEN pn.status ELSE NULL END AS delivery_status
              ,${canHideSql} AS can_hide
     FROM transactions t
     JOIN users c ON c.id = CASE WHEN t.debtor_id = $1 THEN t.creditor_id ELSE t.debtor_id END
     LEFT JOIN pending_notifications pn ON pn.transaction_id = t.id
     WHERE t.scope_chat_id = 0 AND (t.debtor_id = $1 OR t.creditor_id = $1)
        AND NOT EXISTS (
          SELECT 1 FROM transaction_history_hides hidden
          WHERE hidden.transaction_id = t.id AND hidden.user_id = $1
        )
       AND ($2::integer IS NULL OR c.id = $2)
     ORDER BY t.created_at DESC LIMIT 200`,
    [context.user.id, contactId ?? null],
  );
   res.json(ListTransactionsResponse.parse(result.rows.map((row) => transactionFor(row))));
});

router.post("/transactions", async (req, res): Promise<void> => {
  const context = await requireAuth(req, res);
  if (!context || !requirePrivacy(context, res)) return;
  const parsed = CreateTransactionBody.safeParse(req.body);
  if (!parsed.success || !Number.isSafeInteger(parsed.data?.amount) || parsed.data.amount <= 0) {
    res.status(400).json({ error: "Tranzaksiya ma'lumotlari noto'g'ri." });
    return;
  }
  const userId = Number(context.user.id);
  const contactId = parsed.data.contactId;
  if (!Number.isInteger(contactId) || contactId <= 0 || contactId === userId) {
    res.status(400).json({ error: "Kontakt tanlovi noto'g'ri." });
    return;
  }
  const contact = await verifyContact(userId, contactId);
  if (!contact) {
    res.status(403).json({ error: "Bu foydalanuvchi kontaktlaringizda yo'q." });
    return;
  }
  const debtorId = parsed.data.direction === "received" ? userId : contactId;
  const creditorId = parsed.data.direction === "received" ? contactId : userId;
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const result = await client.query<TransactionRow>(
      `INSERT INTO transactions
         (debtor_id, creditor_id, entered_by_id, scope_chat_id, amount, currency, direction, status, note, due_date, created_at)
       VALUES ($1, $2, $3, 0, $4, $5, $6, 'pending', $7, $8, NOW())
       RETURNING *,
         $9::integer AS counterparty_id,
         $10::text AS counterparty_username,
         $11::text AS counterparty_first_name,
         $12::text AS counterparty_last_name`,
      [
        debtorId,
        creditorId,
        userId,
        parsed.data.amount,
        parsed.data.currency,
        parsed.data.direction,
        parsed.data.note ?? null,
        parsed.data.dueDate ?? null,
        contact.id,
        contact.username,
        contact.first_name,
        contact.last_name,
      ],
    );
    const transaction = result.rows[0];
    const notification = {
      recipientTelegramId: contact.telegram_id ?? "",
      transactionId: transaction.id,
      senderName: profileFor(context.user).displayName,
      direction: parsed.data.direction,
      kind: "debt" as const,
      amount: parsed.data.amount,
      currency: parsed.data.currency,
      note: parsed.data.note ?? null,
      dueDate: parsed.data.dueDate
        ? parsed.data.dueDate.toISOString().slice(0, 10)
        : null,
    };
    await enqueuePendingNotification(client, notification);
    await client.query("COMMIT");
    const delivery = await deliverPendingDebtNotification(notification);
    if (delivery !== "sent") {
      req.log.warn(
        { delivery, transactionId: transaction.id },
        "Pending debt notification not delivered; /pending remains available",
      );
    }
    res.status(201).json(
      CreateTransactionResponse.parse(
        transactionFor(
          transaction,
          delivery === "unavailable"
            ? "manual_review"
            : delivery === "sent"
              ? "sent"
              : "pending",
        ),
      ),
    );
  } catch (error) {
    await client.query("ROLLBACK");
    req.log.error({ error }, "Transaction creation failed");
    res.status(500).json({ error: "Tranzaksiya saqlanmadi." });
  } finally {
    client.release();
  }
});

router.post("/transactions/:transactionId/hide", async (req, res): Promise<void> => {
  const context = await requireAuth(req, res);
  if (!context || !requirePrivacy(context, res)) return;
  const params = HideTransactionParams.safeParse(req.params);
  if (!params.success || !Number.isInteger(params.data.transactionId)) {
    res.status(400).json({ error: "Tranzaksiya identifikatori noto'g'ri." });
    return;
  }

  const userId = Number(context.user.id);
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const identity = await client.query<{
      debtor_id: number | string;
      creditor_id: number | string;
      currency: string;
    }>(
      `SELECT debtor_id, creditor_id, currency
       FROM transactions
       WHERE id = $1 AND scope_chat_id = 0
         AND (debtor_id = $2 OR creditor_id = $2)`,
      [params.data.transactionId, userId],
    );
    const transactionIdentity = identity.rows[0];
    if (!transactionIdentity) {
      await client.query("ROLLBACK");
      res.status(404).json({ error: "Tranzaksiya topilmadi." });
      return;
    }
    await acquireDebtPairLock(
      client,
      Number(transactionIdentity.debtor_id),
      Number(transactionIdentity.creditor_id),
      transactionIdentity.currency,
    );
    const transaction = await client.query<{ can_hide: boolean }>(
      `SELECT ${canHideSql} AS can_hide
       FROM transactions t
       WHERE t.id = $1 AND t.scope_chat_id = 0
         AND (t.debtor_id = $2 OR t.creditor_id = $2)
       FOR UPDATE`,
      [params.data.transactionId, userId],
    );
    if (!transaction.rows[0]?.can_hide) {
      await client.query("ROLLBACK");
      res.status(409).json({
        error: "Faqat rad etilgan yoki to'liq yopilgan qarzni yashirish mumkin.",
      });
      return;
    }
    await client.query(
      `INSERT INTO transaction_history_hides (user_id, transaction_id)
       VALUES ($1, $2)
       ON CONFLICT (user_id, transaction_id) DO NOTHING`,
      [userId, params.data.transactionId],
    );
    await client.query("COMMIT");
    res.json(HideTransactionResponse.parse({ hidden: true }));
  } catch (error) {
    await client.query("ROLLBACK");
    req.log.error({ error }, "Transaction history hiding failed");
    res.status(500).json({ error: "Tarixdan yashirish amalga oshmadi." });
  } finally {
    client.release();
  }
});

router.post("/transactions/:transactionId/decision", async (req, res): Promise<void> => {
  const context = await requireAuth(req, res);
  if (!context || !requirePrivacy(context, res)) return;
  const params = DecideTransactionParams.safeParse(req.params);
  const body = DecideTransactionBody.safeParse(req.body);
  if (!params.success || !body.success || !Number.isInteger(params.data.transactionId)) {
    res.status(400).json({ error: "Tasdiqlash ma'lumotlari noto'g'ri." });
    return;
  }
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    // Read the debt pair first without a row lock. The pair advisory lock must
    // always precede the transaction/debt row locks so confirmations and
    // repayments cannot deadlock each other.
    const identity = (await client.query(
      `SELECT debtor_id, creditor_id, currency
       FROM transactions
       WHERE id = $1 AND scope_chat_id = 0
         AND (debtor_id = $2 OR creditor_id = $2)`,
      [params.data.transactionId, context.user.id],
    )) as { rows: Array<Pick<TransactionRow, "debtor_id" | "creditor_id" | "currency">> };
    const pair = identity.rows[0];
    if (!pair) {
      await client.query("ROLLBACK");
      res.status(404).json({ error: "Tasdiqlash kutilayotgan tranzaksiya topilmadi." });
      return;
    }
    await acquireDebtPairLock(
      client,
      Number(pair.debtor_id),
      Number(pair.creditor_id),
      pair.currency,
    );
    const result = await client.query<TransactionRow>(
      `SELECT t.*,
              c.id AS counterparty_id, c.username AS counterparty_username,
              c.first_name AS counterparty_first_name, c.last_name AS counterparty_last_name
       FROM transactions t
       JOIN users c ON c.id = CASE WHEN t.debtor_id = $1 THEN t.creditor_id ELSE t.debtor_id END
       WHERE t.id = $2 AND t.scope_chat_id = 0
         AND (t.debtor_id = $1 OR t.creditor_id = $1)
       FOR UPDATE`,
      [context.user.id, params.data.transactionId],
    );
    const transaction = result.rows[0];
     if (
       !transaction ||
       !["pending", "repayment_pending"].includes(transaction.status) ||
       Number(transaction.entered_by_id) === Number(context.user.id)
     ) {
      await client.query("ROLLBACK");
      res.status(404).json({ error: "Tasdiqlash kutilayotgan tranzaksiya topilmadi." });
      return;
    }
     const nextStatus = body.data.decision === "rejected"
       ? "rejected"
       : transaction.status === "repayment_pending"
         ? "repayment"
         : "confirmed";
     await client.query("UPDATE transactions SET status = $2 WHERE id = $1", [
      transaction.id,
       nextStatus,
    ]);
    if (body.data.decision === "confirmed") {
      await recalculateDebt(
        client,
        Number(transaction.debtor_id),
        Number(transaction.creditor_id),
        transaction.currency,
      );
    }
    await client.query(
      `DELETE FROM pending_notifications WHERE transaction_id = $1`,
      [transaction.id],
    );
    await client.query("COMMIT");
     transaction.status = nextStatus;
    res.json(DecideTransactionResponse.parse(transactionFor(transaction)));
  } catch (error) {
    await client.query("ROLLBACK");
    if (error instanceof LedgerError) {
      res.status(400).json({ error: error.message });
      return;
    }
    req.log.error({ error }, "Transaction decision failed");
    res.status(500).json({ error: "Tranzaksiya yangilanmadi." });
  } finally {
    client.release();
  }
});

router.post("/transactions/:transactionId/resend-notification", async (req, res): Promise<void> => {
  const context = await requireAuth(req, res);
  if (!context || !requirePrivacy(context, res)) return;
  const params = DecideTransactionParams.safeParse(req.params);
  if (!params.success || !Number.isInteger(params.data.transactionId) || params.data.transactionId <= 0) {
    res.status(400).json({ error: "Tranzaksiya identifikatori noto'g'ri." });
    return;
  }

  const userId = Number(context.user.id);
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const transactionResult = await client.query<TransactionRow & {
      sender_username: string | null;
      sender_first_name: string;
      sender_last_name: string | null;
    }>(
      `SELECT t.*,
              c.id AS counterparty_id, c.username AS counterparty_username,
              c.first_name AS counterparty_first_name, c.last_name AS counterparty_last_name,
              sender.username AS sender_username,
              sender.first_name AS sender_first_name,
              sender.last_name AS sender_last_name
       FROM transactions t
       JOIN users c ON c.id = CASE WHEN t.debtor_id = $2 THEN t.creditor_id ELSE t.debtor_id END
       JOIN users sender ON sender.id = t.entered_by_id
       WHERE t.id = $1
         AND t.scope_chat_id = 0
         AND t.debtor_id = $2
         AND t.entered_by_id <> $2
         AND t.status = 'repayment_pending'
       FOR UPDATE`,
      [params.data.transactionId, userId],
    );
    const transaction = transactionResult.rows[0];
    if (!transaction) {
      await client.query("ROLLBACK");
      res.status(404).json({ error: "Tasdiqlash kutilayotgan qaytaruv topilmadi." });
      return;
    }

    const notificationResult = await client.query<{
      id: number | string;
      recipient_telegram_id: number | string;
      kind: string;
      status: "pending" | "sent" | "permanent_failure";
      attempt_count: number | string;
      next_attempt_at: Date | string;
      resend_available_at: Date | string | null;
    }>(
      `SELECT id, recipient_telegram_id, kind, status, attempt_count,
              next_attempt_at, resend_available_at
       FROM pending_notifications
       WHERE transaction_id = $1
       FOR UPDATE`,
      [transaction.id],
    );
    const notificationRow = notificationResult.rows[0];
    if (!notificationRow) {
      await client.query("ROLLBACK");
      res.status(404).json({ error: "Qaytaruv xabari topilmadi." });
      return;
    }

    const now = Date.now();
    const nextAttemptAt = new Date(notificationRow.next_attempt_at).getTime();
    const resendAvailableAt = notificationRow.resend_available_at
      ? new Date(notificationRow.resend_available_at).getTime()
      : null;
    if (
      (notificationRow.status === "pending" && nextAttemptAt > now) ||
      (resendAvailableAt !== null && resendAvailableAt > now)
    ) {
      await client.query("ROLLBACK");
      res.status(429).json({
        error: "Qayta yuborish uchun biroz kuting.",
        code: "RESEND_RATE_LIMITED",
      });
      return;
    }
    if (notificationRow.status === "sent") {
      await client.query("ROLLBACK");
      res.status(409).json({ error: "Qaytaruv xabari allaqachon yuborilgan." });
      return;
    }

    await client.query(
      `UPDATE pending_notifications
       SET status = 'pending',
           attempt_count = CASE WHEN status = 'permanent_failure' THEN 0 ELSE attempt_count END,
           next_attempt_at = CURRENT_TIMESTAMP,
           resend_available_at = CURRENT_TIMESTAMP +
             ($2 * INTERVAL '1 second'),
           last_error = CASE WHEN status = 'permanent_failure' THEN NULL ELSE last_error END
       WHERE id = $1`,
      [notificationRow.id, PENDING_NOTIFICATION_RESEND_COOLDOWN_SECONDS],
    );
    await client.query("COMMIT");

    const notification = {
      recipientTelegramId: notificationRow.recipient_telegram_id,
      transactionId: transaction.id,
      senderName: transaction.sender_username
        ? `@${transaction.sender_username}`
        : [transaction.sender_first_name, transaction.sender_last_name]
          .filter(Boolean)
          .join(" ") || "Foydalanuvchi",
      direction: "given" as const,
      kind: "repayment" as const,
      amount: toSafeNumber(transaction.amount),
      currency: transaction.currency,
      note: transaction.note,
      dueDate: null,
    };
    const delivery = await deliverPendingDebtNotification(notification);
    if (delivery !== "sent") {
      req.log.warn(
        { delivery, transactionId: transaction.id },
        "Pending repayment notification resend was not delivered",
      );
    }
    res.json(
      CreateRepaymentResponse.parse(
        transactionFor(
          transaction,
          delivery === "unavailable"
            ? "manual_review"
            : delivery === "sent"
              ? "sent"
              : "pending",
        ),
      ),
    );
  } catch (error) {
    await client.query("ROLLBACK");
    req.log.error({ error }, "Pending repayment notification resend failed");
    res.status(500).json({ error: "Qayta yuborish amalga oshmadi." });
  } finally {
    client.release();
  }
});

router.post("/repayments", async (req, res): Promise<void> => {
  const context = await requireAuth(req, res);
  if (!context || !requirePrivacy(context, res)) return;
  const parsed = CreateRepaymentBody.safeParse(req.body);
  if (!parsed.success || !Number.isSafeInteger(parsed.data?.amount) || parsed.data.amount <= 0) {
    res.status(400).json({ error: "Qaytarish ma'lumotlari noto'g'ri." });
    return;
  }
  const userId = Number(context.user.id);
  const contactId = parsed.data.contactId;
  if (!Number.isInteger(contactId) || contactId <= 0) {
    res.status(400).json({ error: "Kontakt tanlovi noto'g'ri." });
    return;
  }
  const contact = await verifyContact(userId, contactId);
  if (!contact) {
    res.status(403).json({ error: "Bu foydalanuvchi kontaktlaringizda yo'q." });
    return;
  }

  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const { lowId, highId } = await acquireDebtPairLock(
      client,
      userId,
      contactId,
      parsed.data.currency,
    );
    const debt = await client.query<{ balance_low_to_high: string }>(
      `SELECT balance_low_to_high::text
       FROM debts
       WHERE user_low_id = $1 AND user_high_id = $2 AND currency = $3 AND scope_chat_id = 0
       FOR UPDATE`,
      [lowId, highId, parsed.data.currency],
    );
    const baseBalance = Number(debt.rows[0]?.balance_low_to_high ?? 0);
    const userOwes = userId === lowId ? baseBalance : -baseBalance;
    const pendingRepayments = await client.query<{ amount: string }>(
      `SELECT COALESCE(SUM(amount), 0)::text AS amount
       FROM transactions
       WHERE debtor_id = $1 AND creditor_id = $2
         AND scope_chat_id = 0 AND currency = $3
         AND status = 'repayment_pending'`,
      [contactId, userId, parsed.data.currency],
    );
    const reservedByPending = Number(pendingRepayments.rows[0]?.amount ?? 0);
    const availableToRepay = userOwes - reservedByPending;
    if (
      !Number.isSafeInteger(availableToRepay) ||
      availableToRepay <= 0 ||
      parsed.data.amount > availableToRepay
    ) {
      await client.query("ROLLBACK");
      res.status(400).json({
        error: "Qaytarish summasi faol yoki tasdiqlanishi kutilayotgan qaytaruvlardan katta bo'lishi mumkin emas.",
      });
      return;
    }
    const inserted = await client.query<TransactionRow>(
      `INSERT INTO transactions
       (debtor_id, creditor_id, entered_by_id, scope_chat_id, amount, currency, direction, status, note, created_at)
        VALUES ($1, $2, $3, 0, $4, $5, 'given', 'repayment_pending', $6, NOW())
       RETURNING *,
         $7::integer AS counterparty_id,
         $8::text AS counterparty_username,
         $9::text AS counterparty_first_name,
         $10::text AS counterparty_last_name`,
      [
        contactId,
        userId,
        userId,
        parsed.data.amount,
        parsed.data.currency,
        parsed.data.note ?? "Qarz qaytarildi",
        contact.id,
        contact.username,
        contact.first_name,
        contact.last_name,
      ],
    );
    const notification = {
      recipientTelegramId: contact.telegram_id ?? "",
      transactionId: inserted.rows[0].id,
      senderName: profileFor(context.user).displayName,
      direction: "given" as const,
      kind: "repayment" as const,
      amount: parsed.data.amount,
      currency: parsed.data.currency,
      note: parsed.data.note ?? "Qarz qaytarildi",
      dueDate: null,
    };
    await enqueuePendingNotification(client, notification);
    await client.query("COMMIT");
    const delivery = await deliverPendingDebtNotification(notification);
    if (delivery !== "sent") {
      req.log.warn(
        { delivery, transactionId: inserted.rows[0].id },
        "Pending repayment notification not delivered; /pending remains available",
      );
    }
    res.status(201).json(
      CreateRepaymentResponse.parse(
        transactionFor(
          inserted.rows[0],
          delivery === "unavailable"
            ? "manual_review"
            : delivery === "sent"
              ? "sent"
              : "pending",
        ),
      ),
    );
  } catch (error) {
    await client.query("ROLLBACK");
    if (error instanceof LedgerError) {
      res.status(400).json({ error: error.message });
      return;
    }
    req.log.error({ error }, "Repayment creation failed");
    res.status(500).json({ error: "Qaytarish saqlanmadi." });
  } finally {
    client.release();
  }
});

export default router;