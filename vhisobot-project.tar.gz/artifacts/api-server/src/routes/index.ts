import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import debtsRouter from "./debts";
import testFixtureRouter from "./test-fixture";

const router: IRouter = Router();

router.use(healthRouter);
router.use(testFixtureRouter);
router.use(authRouter);
router.use(debtsRouter);

export default router;
