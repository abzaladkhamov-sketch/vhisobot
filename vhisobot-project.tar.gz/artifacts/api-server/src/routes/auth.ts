import crypto from "node:crypto";
import { Router, type IRouter } from "express";
import { pool } from "@workspace/db";
import {
  ExchangeAccessCodeBody,
  ExchangeAccessCodeResponse,
  GetCurrentUserResponse,
  GetSettingsResponse,
  UnlockPrivacyBody,
  UnlockPrivacyResponse,
  UpdateSettingsBody,
  UpdateSettingsResponse,
} from "@workspace/api-zod";
import {
  checkPinLockedOrRecordFailure,
  issueSession,
  profileFor,
  requireAuth,
  type UserProfile,
} from "../lib/auth";

type DbUser = {
  id: number | string;
  username: string | null;
  first_name: string;
  last_name: string | null;
  pin_hash: string | null;
  pin_failed_attempts: number | string | null;
  pin_locked_until: Date | string | null;
};

const router: IRouter = Router();

function codeHash(code: string): string {
  return crypto.createHash("sha256").update(code.trim().toUpperCase()).digest("hex");
}

router.post("/auth/exchange", async (req, res): Promise<void> => {
  const parsed = ExchangeAccessCodeBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Kirish kodi noto'g'ri." });
    return;
  }

  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const result = await client.query<DbUser & { code_id: number }>(
      `SELECT c.id AS code_id, u.id, u.username, u.first_name, u.last_name,
              u.pin_hash, u.pin_failed_attempts, u.pin_locked_until
       FROM web_access_codes c
       JOIN users u ON u.id = c.user_id
       WHERE c.code_hash = $1 AND c.used_at IS NULL AND c.expires_at > NOW()
       FOR UPDATE`,
      [codeHash(parsed.data.code)],
    );
    const user = result.rows[0];
    if (!user) {
      await client.query("ROLLBACK");
      res.status(401).json({ error: "Kirish kodi noto'g'ri yoki muddati tugagan." });
      return;
    }

    if (user.pin_hash) {
      if (!parsed.data.pin) {
        await client.query("ROLLBACK");
        res.status(423).json({ error: "Davom etish uchun PIN kiriting.", code: "PIN_REQUIRED" });
        return;
      }
      const pinCheck = await checkPinLockedOrRecordFailure(client, user, parsed.data.pin);
      if (!pinCheck.ok) {
        await client.query("COMMIT");
        const message = pinCheck.locked
          ? "PIN uch marta noto'g'ri kiritildi. Bir daqiqadan keyin urinib ko'ring."
          : `PIN noto'g'ri. Yana ${pinCheck.remaining} urinish qoldi.`;
        res.status(pinCheck.locked ? 423 : 401).json({ error: message });
        return;
      }
    }

    await client.query("UPDATE web_access_codes SET used_at = NOW() WHERE id = $1", [
      user.code_id,
    ]);
    await client.query("COMMIT");
    res.json(ExchangeAccessCodeResponse.parse(issueSession(user, Boolean(user.pin_hash))));
  } catch (error) {
    await client.query("ROLLBACK");
    req.log.error({ error }, "Access code exchange failed");
    res.status(500).json({ error: "Kirishni yakunlab bo'lmadi." });
  } finally {
    client.release();
  }
});

router.post("/auth/unlock", async (req, res): Promise<void> => {
  const parsed = UnlockPrivacyBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "PIN 4 ta raqamdan iborat bo'lishi kerak." });
    return;
  }
  const context = await requireAuth(req, res);
  if (!context) return;

  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const result = await client.query<DbUser>(
      `SELECT id, username, first_name, last_name, pin_hash, pin_failed_attempts, pin_locked_until
       FROM users WHERE id = $1 FOR UPDATE`,
      [context.user.id],
    );
    const user = result.rows[0];
    if (!user) {
      await client.query("ROLLBACK");
      res.status(401).json({ error: "Foydalanuvchi topilmadi." });
      return;
    }
    if (!user.pin_hash) {
      await client.query("COMMIT");
      res.json(UnlockPrivacyResponse.parse(issueSession(user, false)));
      return;
    }
    const pinCheck = await checkPinLockedOrRecordFailure(client, user, parsed.data.pin);
    await client.query("COMMIT");
    if (!pinCheck.ok) {
      const message = pinCheck.locked
        ? "PIN vaqtincha bloklangan. Bir daqiqadan keyin urinib ko'ring."
        : `PIN noto'g'ri. Yana ${pinCheck.remaining} urinish qoldi.`;
      res.status(pinCheck.locked ? 423 : 401).json({ error: message });
      return;
    }
    res.json(UnlockPrivacyResponse.parse(issueSession(user, true)));
  } catch (error) {
    await client.query("ROLLBACK");
    req.log.error({ error }, "PIN unlock failed");
    res.status(500).json({ error: "PIN tekshirilmadi." });
  } finally {
    client.release();
  }
});

router.get("/me", async (req, res): Promise<void> => {
  const context = await requireAuth(req, res);
  if (!context) return;
  res.json(GetCurrentUserResponse.parse(profileFor(context.user)));
});

router.get("/settings", async (req, res): Promise<void> => {
  const context = await requireAuth(req, res);
  if (!context) return;
  const result = await pool.query<{
    report_frequency: "off" | "weekly" | "monthly";
    pin_hash: string | null;
  }>("SELECT report_frequency, pin_hash FROM users WHERE id = $1", [context.user.id]);
  const settings = result.rows[0];
  if (!settings) {
    res.status(404).json({ error: "Foydalanuvchi topilmadi." });
    return;
  }
  res.json(
    GetSettingsResponse.parse({
      reportFrequency: settings.report_frequency,
      pinEnabled: Boolean(settings.pin_hash),
    }),
  );
});

router.put("/settings", async (req, res): Promise<void> => {
  const context = await requireAuth(req, res);
  if (!context) return;
  const parsed = UpdateSettingsBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Hisobot sozlamasi noto'g'ri." });
    return;
  }
  const result = await pool.query<{ report_frequency: "off" | "weekly" | "monthly"; pin_hash: string | null }>(
    `UPDATE users SET report_frequency = $2 WHERE id = $1
     RETURNING report_frequency, pin_hash`,
    [context.user.id, parsed.data.reportFrequency],
  );
  const settings = result.rows[0];
  if (!settings) {
    res.status(404).json({ error: "Foydalanuvchi topilmadi." });
    return;
  }
  res.json(
    UpdateSettingsResponse.parse({
      reportFrequency: settings.report_frequency,
      pinEnabled: Boolean(settings.pin_hash),
    }),
  );
});

export default router;