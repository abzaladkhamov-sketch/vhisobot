/**
 * Semantic design tokens for the mobile app.
 */

const colors = {
  light: {
    text: '#1A2421',
    tint: '#1E5647',

    background: '#F6F3EE',
    foreground: '#1A2421',

    card: '#FCFBF9',
    cardForeground: '#1A2421',

    primary: '#1E5647',
    primaryForeground: '#FFFFFF',

    secondary: '#EAE5DB',
    secondaryForeground: '#2D3E38',

    muted: '#E5E1D8',
    mutedForeground: '#6F7B76',

    accent: '#DCE7E2',
    accentForeground: '#153D32',

    destructive: '#C9443B',
    destructiveForeground: '#FFFFFF',

    border: '#E1DBD1',
    input: '#E1DBD1',
  },
  dark: {
    text: '#F2EFE9',
    tint: '#5D9988',
    
    background: '#151C1A',
    foreground: '#F2EFE9',
    
    card: '#1A2321',
    cardForeground: '#F2EFE9',
    
    primary: '#5D9988',
    primaryForeground: '#0D1412',
    
    secondary: '#25332F',
    secondaryForeground: '#EAE6DF',
    
    muted: '#202D2A',
    mutedForeground: '#8D9B96',
    
    accent: '#26423A',
    accentForeground: '#F2EFE9',
    
    destructive: '#E56259',
    destructiveForeground: '#FFFFFF',
    
    border: '#2C3B37',
    input: '#2C3B37',
  },

  radius: 16,
};

export default colors;