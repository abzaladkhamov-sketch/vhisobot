import { Feather } from '@expo/vector-icons';
import { useListContacts } from '@workspace/api-client-react';
import { Redirect, router } from 'expo-router';
import { ActivityIndicator, Pressable, RefreshControl, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Card, EmptyState, PageHeader } from '@/components/finance-ui';
import { useAuth } from '@/contexts/AuthContext';
import { useColors } from '@/hooks/useColors';

export default function ContactsScreen() {
  const colors = useColors();
  const { ready, token } = useAuth();
  const contacts = useListContacts();
  
  if (ready && !token) return <Redirect href="/signin" />;
  
  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <PageHeader title="Kontaktlar" eyebrow="Telegram bog‘lanishlari" />
      {contacts.isLoading ? (
        <View style={styles.center}><ActivityIndicator size="large" color={colors.primary} /></View>
      ) : (
        <ScrollView 
          refreshControl={<RefreshControl refreshing={contacts.isRefetching} onRefresh={contacts.refetch} tintColor={colors.primary} />} 
          contentContainerStyle={styles.content}>
          
          {!contacts.data?.length ? (
            <EmptyState icon="users" title="Kontaktlar yo‘q" detail="Telegram botda kontakt qo‘shganingizdan keyin ular shu yerda ko‘rinadi." />
          ) : null}
          
          {contacts.data?.map((contact) => (
            <Pressable
              key={contact.id}
              onPress={() => router.push(`/transactions?contactId=${contact.id}`)}
              accessibilityRole="button"
              accessibilityLabel={`${contact.displayName} tarixini ko‘rish`}>
              <Card>
                <View style={styles.row}>
                  <View style={[styles.avatar, { backgroundColor: colors.muted }]}>
                    <Text style={{ color: colors.mutedForeground, fontWeight: '700', fontSize: 18 }}>
                      {contact.displayName.slice(0, 1).toUpperCase()}
                    </Text>
                  </View>
                  <View style={{ flex: 1, gap: 2 }}>
                    <Text style={[styles.name, { color: colors.foreground }]}>{contact.displayName}</Text>
                    {contact.username ? (
                      <Text style={[styles.username, { color: colors.mutedForeground }]}>@{contact.username}</Text>
                    ) : null}
                    <Text style={[styles.historyLink, { color: colors.primary }]}>Tarixni ko‘rish</Text>
                  </View>
                  <Feather name="chevron-right" size={20} color={colors.mutedForeground} />
                </View>
              </Card>
            </Pressable>
          ))}
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  content: { padding: 24, paddingBottom: 140, gap: 12 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 16 },
  avatar: { width: 48, height: 48, borderRadius: 24, alignItems: 'center', justifyContent: 'center' },
  name: { fontSize: 17, fontWeight: '600' },
  username: { fontSize: 14 },
  historyLink: { fontSize: 13, fontWeight: '600', marginTop: 6 },
});