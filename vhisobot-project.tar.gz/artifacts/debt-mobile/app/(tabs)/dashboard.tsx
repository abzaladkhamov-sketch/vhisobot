import { Feather } from '@expo/vector-icons';
import { useGetDashboard } from '@workspace/api-client-react';
import { Redirect, router } from 'expo-router';
import { ActivityIndicator, Pressable, RefreshControl, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Card, EmptyState, IconButton, PageHeader, PrimaryButton, StatusPill, formatMoney } from '@/components/finance-ui';
import { useAuth } from '@/contexts/AuthContext';
import { useColors } from '@/hooks/useColors';

export default function DashboardScreen() {
  const colors = useColors();
  const { ready, token } = useAuth();
  const dashboard = useGetDashboard();
  if (ready && !token) return <Redirect href="/signin" />;

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <PageHeader
        eyebrow="Qarz daftaringiz"
        title="Bosh sahifa"
        action={<IconButton icon="plus" label="Qarz kiritish" onPress={() => router.push('/entry?kind=debt')} testID="dashboard-add" />}
      />
      {dashboard.isLoading ? (
        <View style={styles.center}><ActivityIndicator size="large" color={colors.primary} /></View>
      ) : dashboard.isError ? (
        <View style={styles.center}>
          <EmptyState icon="wifi-off" title="Ma’lumotlarni yuklab bo‘lmadi" detail="Internetni tekshirib, qayta urinib ko‘ring." />
          <View style={styles.retry}>
            <PrimaryButton label="Qayta urinib ko‘rish" onPress={() => void dashboard.refetch()} />
          </View>
        </View>
      ) : (
        <ScrollView
          refreshControl={<RefreshControl refreshing={dashboard.isRefetching} onRefresh={dashboard.refetch} tintColor={colors.primary} />}
          contentContainerStyle={styles.content}
          contentInsetAdjustmentBehavior="automatic">
          
          <View style={styles.counterRow}>
            <Pressable
              onPress={() => router.push('/transactions')}
              style={({ pressed }) => ({ flex: 1, opacity: pressed ? 0.78 : 1 })}
              testID="dashboard-pending-confirmations">
              <Card tone="accent">
                <Text style={[styles.counter, { color: colors.accentForeground }]}>{dashboard.data?.pendingCount ?? 0}</Text>
                <Text style={[styles.counterLabel, { color: colors.accentForeground, opacity: 0.8 }]}>Tasdiqlashingiz kutilmoqda</Text>
              </Card>
            </Pressable>
            <View style={{ flex: 1 }}>
              <Card>
                <Text style={[styles.counter, { color: colors.foreground }]}>{dashboard.data?.dueSoonCount ?? 0}</Text>
                <Text style={[styles.counterLabel, { color: colors.mutedForeground }]}>Muddati yaqin</Text>
              </Card>
            </View>
          </View>

          <View style={styles.sectionHeading}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Balanslar</Text>
            <Pressable onPress={() => router.push('/transactions')} hitSlop={12}>
              <Text style={[styles.link, { color: colors.primary }]}>Barchasi</Text>
            </Pressable>
          </View>
          
          {dashboard.data?.balances.length ? (
            <View style={styles.list}>
              {dashboard.data.balances.map((balance) => (
                <Card key={`${balance.contact.id}-${balance.currency}`}>
                  <View style={styles.balanceRow}>
                    <View style={[styles.avatar, { backgroundColor: colors.muted }]}>
                      <Text style={{ color: colors.mutedForeground, fontWeight: '700', fontSize: 16 }}>
                        {balance.contact.displayName.slice(0, 1).toUpperCase()}
                      </Text>
                    </View>
                    <View style={{ flex: 1, gap: 4 }}>
                      <Text style={[styles.contactName, { color: colors.foreground }]}>{balance.contact.displayName}</Text>
                      <Text style={[styles.balanceNarrative, { color: colors.mutedForeground }]}>
                        {balance.userOwesOther ? 'Siz qarzdorsiz' : 'Sizga qarz'}
                      </Text>
                    </View>
                    <Text style={[styles.money, { color: balance.userOwesOther ? colors.destructive : colors.primary }]}>
                      {formatMoney(balance.amount, balance.currency)}
                    </Text>
                  </View>
                  <View style={[styles.breakdown, { borderTopColor: colors.border }]}>
                    <View style={styles.breakdownRow}>
                      <Text style={[styles.breakdownLabel, { color: colors.mutedForeground }]}>Berdingiz</Text>
                      <Text style={[styles.breakdownValue, { color: colors.foreground }]}>{formatMoney(balance.lentTotal, balance.currency)}</Text>
                    </View>
                    <View style={styles.breakdownRow}>
                      <Text style={[styles.breakdownLabel, { color: colors.mutedForeground }]}>Oldingiz</Text>
                      <Text style={[styles.breakdownValue, { color: colors.foreground }]}>{formatMoney(balance.borrowedTotal, balance.currency)}</Text>
                    </View>
                    <View style={styles.breakdownRow}>
                      <Text style={[styles.breakdownLabel, { color: colors.mutedForeground }]}>Qaytardingiz</Text>
                      <Text style={[styles.breakdownValue, { color: colors.foreground }]}>{formatMoney(balance.repaidByUser, balance.currency)}</Text>
                    </View>
                    <View style={styles.breakdownRow}>
                      <Text style={[styles.breakdownLabel, { color: colors.mutedForeground }]}>Sizga qaytarildi</Text>
                      <Text style={[styles.breakdownValue, { color: colors.foreground }]}>{formatMoney(balance.repaidToUser, balance.currency)}</Text>
                    </View>
                  </View>
                </Card>
              ))}
            </View>
          ) : <EmptyState icon="book-open" title="Balanslar yo‘q" detail="Qarz kiritishdan boshlang." />}

          <View style={styles.sectionHeading}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>So‘nggi harakatlar</Text>
          </View>
          
          {dashboard.data?.recentTransactions.length ? (
            <View style={styles.recentList}>
              {dashboard.data.recentTransactions.slice(0, 4).map((transaction) => (
                <View key={transaction.id} style={[styles.recentRow, { borderBottomColor: colors.border }]}>
                  <View style={[styles.recentIcon, { backgroundColor: colors.muted }]}>
                    <Feather name={transaction.status === 'repayment' || transaction.status === 'repayment_pending' ? 'corner-up-left' : 'file-text'} size={18} color={colors.foreground} />
                  </View>
                  <View style={{ flex: 1, gap: 4 }}>
                    <Text style={[styles.recentName, { color: colors.foreground }]}>{transaction.counterparty?.displayName ?? 'Kontakt'}</Text>
                    <Text style={[styles.recentMeta, { color: colors.mutedForeground }]}>{transaction.status === 'repayment' || transaction.status === 'repayment_pending' ? 'Qaytaruv' : 'Qarz so‘rovi'}</Text>
                  </View>
                  <StatusPill status={transaction.status} />
                  <Text style={[styles.recentAmount, { color: colors.foreground }]}>{formatMoney(transaction.amount, transaction.currency)}</Text>
                </View>
              ))}
            </View>
          ) : null}
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24 },
  retry: { alignSelf: 'stretch', width: '100%' },
  content: { paddingHorizontal: 24, paddingBottom: 140, gap: 32 },
  counterRow: { flexDirection: 'row', gap: 12 },
  counter: { fontSize: 32, fontWeight: '700', letterSpacing: -1 },
  counterLabel: { fontSize: 13, fontWeight: '500', marginTop: 4 },
  sectionHeading: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: -16 },
  sectionTitle: { fontSize: 20, fontWeight: '700', letterSpacing: -0.5 },
  link: { fontSize: 14, fontWeight: '600' },
  list: { gap: 12 },
  balanceRow: { flexDirection: 'row', alignItems: 'center', gap: 14 },
  avatar: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
  contactName: { fontSize: 16, fontWeight: '600' },
  balanceNarrative: { fontSize: 13 },
  money: { fontSize: 16, fontWeight: '700' },
  breakdown: { borderTopWidth: 1, marginTop: 16, paddingTop: 12, gap: 8 },
  breakdownRow: { flexDirection: 'row', justifyContent: 'space-between', gap: 12 },
  breakdownLabel: { fontSize: 13, fontWeight: '500' },
  breakdownValue: { fontSize: 13, fontWeight: '700' },
  recentList: { backgroundColor: 'transparent', gap: 0 },
  recentRow: { flexDirection: 'row', alignItems: 'center', gap: 14, paddingVertical: 16, borderBottomWidth: 1 },
  recentIcon: { width: 40, height: 40, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  recentName: { fontSize: 15, fontWeight: '600' },
  recentMeta: { fontSize: 13 },
  recentAmount: { fontSize: 15, fontWeight: '600' },
});