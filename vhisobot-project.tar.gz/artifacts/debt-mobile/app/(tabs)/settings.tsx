import { Feather } from '@expo/vector-icons';
import { useQueryClient } from '@tanstack/react-query';
import { useGetSettings, useUpdateSettings, type SettingsInputReportFrequency } from '@workspace/api-client-react';
import { Redirect } from 'expo-router';
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import * as Haptics from 'expo-haptics';
import { Card, PageHeader } from '@/components/finance-ui';
import { useAuth } from '@/contexts/AuthContext';
import { useColors } from '@/hooks/useColors';

const options: Array<{ value: SettingsInputReportFrequency; label: string; detail: string }> = [
  { value: 'off', label: 'O‘chirilgan', detail: 'Hisobot yuborilmaydi' },
  { value: 'weekly', label: 'Haftalik', detail: 'Har hafta qisqa xulosa' },
  { value: 'monthly', label: 'Oylik', detail: 'Har oy umumiy hisobot' },
];

export default function SettingsScreen() {
  const colors = useColors();
  const { ready, token, logout } = useAuth();
  const queryClient = useQueryClient();
  const settings = useGetSettings();
  const update = useUpdateSettings();
  
  if (ready && !token) return <Redirect href="/signin" />;
  
  const choose = (reportFrequency: SettingsInputReportFrequency) => {
    void Haptics.selectionAsync();
    update.mutate({ data: { reportFrequency } }, { onSuccess: () => void queryClient.invalidateQueries() });
  };
  
  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <PageHeader title="Sozlamalar" eyebrow="Hisobotingiz" />
      
      {settings.isLoading ? (
        <View style={styles.center}><ActivityIndicator size="large" color={colors.primary} /></View>
      ) : (
        <ScrollView contentContainerStyle={styles.content}>
          
          <Text style={[styles.label, { color: colors.mutedForeground }]}>DAVRIY HISOBOT</Text>
          <Card>
            {options.map((option, index) => {
              const active = settings.data?.reportFrequency === option.value;
              return (
                <Pressable 
                  key={option.value} 
                  onPress={() => choose(option.value)} 
                  style={({ pressed }) => [
                    styles.option, 
                    index ? { borderTopColor: colors.border, borderTopWidth: 1 } : null,
                    { opacity: pressed ? 0.7 : 1 }
                  ]}>
                  <View style={{ flex: 1, gap: 2 }}>
                    <Text style={[styles.optionLabel, { color: colors.foreground }]}>{option.label}</Text>
                    <Text style={[styles.optionDetail, { color: colors.mutedForeground }]}>{option.detail}</Text>
                  </View>
                  {active ? <Feather name="check-circle" size={24} color={colors.primary} /> : <View style={styles.emptyCheck} />}
                </Pressable>
              );
            })}
          </Card>
          
          <Text style={[styles.label, { color: colors.mutedForeground }]}>MAXFIYLIK</Text>
          <Card tone="accent">
            <View style={styles.privacy}>
              <View style={[styles.privacyIcon, { backgroundColor: colors.background }]}>
                <Feather name={settings.data?.pinEnabled ? 'lock' : 'unlock'} size={20} color={colors.primary} />
              </View>
              <View style={{ flex: 1, gap: 4 }}>
                <Text style={[styles.optionLabel, { color: colors.foreground }]}>
                  {settings.data?.pinEnabled ? 'PIN himoyasi yoqilgan' : 'PIN himoyasi o‘chirilgan'}
                </Text>
                <Text style={[styles.optionDetail, { color: colors.mutedForeground }]}>
                  PIN’ni Telegram botdagi /settings orqali boshqaring.
                </Text>
              </View>
            </View>
          </Card>
          
          <Pressable 
            onPress={() => void logout()} 
            testID="logout-button" 
            style={({ pressed }) => [
              styles.logout, 
              { borderColor: colors.border, backgroundColor: colors.card, borderRadius: colors.radius, opacity: pressed ? 0.8 : 1 }
            ]}>
            <Feather name="log-out" size={18} color={colors.destructive} />
            <Text style={{ color: colors.destructive, fontWeight: '600', fontSize: 16 }}>Chiqish</Text>
          </Pressable>
          
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  content: { padding: 24, paddingBottom: 140, gap: 16 },
  label: { fontSize: 12, fontWeight: '700', letterSpacing: 1, marginTop: 12, marginLeft: 4 },
  option: { minHeight: 76, flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 14 },
  optionLabel: { fontSize: 16, fontWeight: '600' },
  optionDetail: { fontSize: 14, lineHeight: 20 },
  emptyCheck: { width: 24, height: 24 },
  privacy: { flexDirection: 'row', gap: 16, alignItems: 'flex-start' },
  privacyIcon: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  logout: { height: 56, borderWidth: 1, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 10, marginTop: 24 },
});