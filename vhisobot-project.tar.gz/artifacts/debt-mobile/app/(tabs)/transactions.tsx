import { Feather } from '@expo/vector-icons';
import { useQueryClient } from '@tanstack/react-query';
import {
  getListContactsQueryKey,
  getListTransactionsQueryKey,
  useDecideTransaction,
  useHideTransaction,
  useListContacts,
  useListTransactions,
  useResendTransactionNotification,
} from '@workspace/api-client-react';
import { Redirect, router, useLocalSearchParams } from 'expo-router';
import { useState } from 'react';
import { ActivityIndicator, Alert, Pressable, RefreshControl, ScrollView, StyleSheet, Text, View } from 'react-native';
import * as Haptics from 'expo-haptics';
import { Card, EmptyState, IconButton, PageHeader, PrimaryButton, StatusPill, formatMoney } from '@/components/finance-ui';
import { useAuth } from '@/contexts/AuthContext';
import { useColors } from '@/hooks/useColors';

export default function TransactionsScreen() {
  const colors = useColors();
  const { ready, token, user } = useAuth();
  const queryClient = useQueryClient();
  const { contactId: contactIdParam, result } = useLocalSearchParams<{ contactId?: string; result?: string }>();
  const parsedContactId = Number(contactIdParam);
  const contactId = Number.isInteger(parsedContactId) && parsedContactId > 0 ? parsedContactId : undefined;
  const contacts = useListContacts({
    query: { enabled: ready && Boolean(token), queryKey: getListContactsQueryKey() },
  });
  const selectedContact = contacts.data?.find((contact) => contact.id === contactId);
  const transactions = useListTransactions(contactId ? { contactId } : undefined, {
    query: {
      enabled: ready && Boolean(token),
      queryKey: getListTransactionsQueryKey(contactId ? { contactId } : undefined),
    },
  });
  const decide = useDecideTransaction();
  const hide = useHideTransaction();
  const resend = useResendTransactionNotification();
  const [decisionError, setDecisionError] = useState('');
  const [decisionSuccess, setDecisionSuccess] = useState('');
  const routeSuccess =
    result === 'debt-sent'
      ? 'Qarz so‘rovi yuborildi. Tasdiqlangach balans yangilanadi.'
      : result === 'repayment-saved'
        ? 'Qaytaruv so‘rovi yuborildi. Tasdiqlangach balans yangilanadi.'
        : '';
  
  if (ready && !token) return <Redirect href="/signin" />;

  const decideTransaction = (transactionId: number, decision: 'confirmed' | 'rejected') => {
    setDecisionError('');
    setDecisionSuccess('');
    const isRepayment = transactions.data?.find((transaction) => transaction.id === transactionId)?.status === 'repayment_pending';
    void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    decide.mutate(
      { transactionId, data: { decision } },
      {
        onSuccess: () => {
          void queryClient.invalidateQueries();
          setDecisionSuccess(
            decision === 'confirmed'
              ? isRepayment ? 'Qaytaruv tasdiqlandi. Balans yangilandi.' : 'Qarz tasdiqlandi. Balans yangilandi.'
              : isRepayment ? 'Qaytaruv rad etildi. Balans o‘zgarmadi.' : 'Qarz rad etildi. U balansga qo‘shilmadi.',
          );
        },
        onError: (error: any) =>
          setDecisionError(
            error?.message ??
              "Tasdiqlash amalga oshmadi. Balansni yangilab, qayta urinib ko‘ring.",
          ),
      },
    );
  };

  const hideTransaction = (transactionId: number) => {
    if (hide.isPending) return;
    Alert.alert(
      'Tarixdan yashirilsinmi?',
      'Bu yozuv faqat sizning tarixingizdan yashiriladi. Balans va audit o‘zgarmaydi.',
      [
        { text: 'Bekor qilish', style: 'cancel' },
        {
          text: 'Yashirish',
          style: 'destructive',
          onPress: () => {
            void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
            hide.mutate(
              { transactionId },
              {
                onSuccess: () => {
                  void queryClient.invalidateQueries();
                  setDecisionSuccess('Yozuv tarixingizdan yashirildi. Balans va audit o‘zgarmadi.');
                },
                onError: (error: any) =>
                  setDecisionError(error?.message ?? 'Yozuvni tarixdan yashirib bo‘lmadi.'),
              },
            );
          },
        },
      ],
    );
  };

  const resendNotification = (transactionId: number) => {
    if (resend.isPending) return;
    setDecisionError('');
    setDecisionSuccess('');
    resend.mutate(
      { transactionId },
      {
        onSuccess: (transaction) => {
          void queryClient.invalidateQueries();
          setDecisionSuccess(
            transaction.deliveryStatus === 'sent'
              ? 'Telegram xabari qayta yuborildi.'
              : 'Qayta yuborish boshlandi. So‘rov hali ham ko‘rib chiqish uchun mavjud.',
          );
        },
        onError: (error: any) =>
          setDecisionError(error?.message ?? 'Qayta yuborib bo‘lmadi. Birozdan keyin urinib ko‘ring.'),
      },
    );
  };
  
  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <PageHeader 
        title={selectedContact ? `${selectedContact.displayName} tarixi` : 'O‘tkazmalar'}
        eyebrow="Shaxsiy tarix" 
        action={<IconButton icon="plus" label="Qarz kiritish" onPress={() => router.push('/entry?kind=debt')} testID="transactions-add" />}
      />
      {selectedContact ? (
        <Pressable onPress={() => router.replace('/transactions')} style={styles.clearFilter}>
          <Text style={[styles.clearFilterText, { color: colors.primary }]}>Barcha tarixni ko‘rish</Text>
        </Pressable>
      ) : null}
      
      <View style={styles.actions}>
        <Pressable 
          onPress={() => router.push('/entry?kind=debt')} 
          style={({ pressed }) => [
            styles.action, 
            { backgroundColor: colors.primary, borderRadius: colors.radius, opacity: pressed ? 0.8 : 1 }
          ]}>
          <Feather name="edit-3" size={18} color={colors.primaryForeground} />
          <Text style={[styles.actionLabel, { color: colors.primaryForeground }]}>Qarz kiritish</Text>
        </Pressable>
        <Pressable 
          onPress={() => router.push('/entry?kind=repayment')} 
          style={({ pressed }) => [
            styles.action, 
            { backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border, borderRadius: colors.radius, opacity: pressed ? 0.8 : 1 }
          ]}>
          <Feather name="corner-up-left" size={18} color={colors.foreground} />
          <Text style={[styles.actionLabel, { color: colors.foreground }]}>Qaytaruv kiritish</Text>
        </Pressable>
      </View>
      {decisionError ? (
        <View
          style={[
            styles.decisionError,
            {
              backgroundColor: colors.card,
              borderColor: colors.destructive,
              borderRadius: colors.radius,
            },
          ]}>
          <Feather name="alert-circle" size={18} color={colors.destructive} />
          <Text style={[styles.decisionErrorText, { color: colors.destructive }]}>
            {decisionError}
          </Text>
        </View>
      ) : null}

      {decisionSuccess || routeSuccess ? (
        <Pressable
          onPress={() => {
            setDecisionSuccess('');
            if (routeSuccess) router.replace('/transactions');
          }}
          style={[
            styles.success,
            { backgroundColor: colors.accent, borderRadius: colors.radius },
          ]}>
          <Feather name="check-circle" size={18} color={colors.accentForeground} />
          <Text style={[styles.successText, { color: colors.accentForeground }]}>
            {decisionSuccess || routeSuccess}
          </Text>
          <Feather name="x" size={16} color={colors.accentForeground} />
        </Pressable>
      ) : null}
      
      {transactions.isLoading ? (
        <View style={styles.center}>
          <ActivityIndicator size="large" color={colors.primary} />
          <Text style={{ color: colors.mutedForeground }}>Ma’lumotlar yuklanmoqda…</Text>
        </View>
      ) : transactions.isError ? (
        <View style={styles.center}>
          <EmptyState icon="wifi-off" title="Ma’lumotlarni yuklab bo‘lmadi" detail="Internetni tekshirib, qayta urinib ko‘ring." />
          <View style={styles.retry}>
            <PrimaryButton label="Qayta urinib ko‘rish" onPress={() => void transactions.refetch()} />
          </View>
        </View>
      ) : (
        <ScrollView
          refreshControl={<RefreshControl refreshing={transactions.isRefetching} onRefresh={transactions.refetch} tintColor={colors.primary} />}
          contentContainerStyle={styles.content}>
          
          {!transactions.data?.length ? (
            <EmptyState icon="inbox" title="Hali yozuv yo‘q" detail="Qarz kiritishdan boshlang." />
          ) : null}
          
          {transactions.data?.map((transaction) => {
            const canDecide = ['pending', 'repayment_pending'].includes(transaction.status) && transaction.enteredById !== user?.id;
            const isMine = transaction.enteredById === user?.id;
            const debtDirection = transaction.creditorId === user?.id ? 'Sizga qarz' : 'Siz qarzdorsiz';
            const directionLabel =
              transaction.status === 'repayment'
                ? isMine
                  ? 'Qarzingiz kamaydi'
                  : 'Sizga qarz kamaydi'
                : transaction.status === 'repayment_pending'
                  ? 'Qaytaruv — balans hali o‘zgarmagan'
                  : transaction.status === 'pending'
                  ? `${debtDirection} — balans hali o‘zgarmagan`
                  : transaction.status === 'rejected'
                    ? `${debtDirection} — balansga qo‘shilmagan`
                    : debtDirection;
            return (
              <Card key={transaction.id}>
                <View style={styles.row}>
                  <View style={{ flex: 1, gap: 6 }}>
                    <Text style={[styles.name, { color: colors.foreground }]}>{transaction.counterparty?.displayName ?? 'Kontakt'}</Text>
                    <Text style={[styles.direction, { color: colors.foreground }]}>
                      {transaction.status === 'repayment'
                        ? `Qaytaruv — ${directionLabel}`
                        : directionLabel}
                    </Text>
                    <Text style={[styles.note, { color: colors.mutedForeground }]}>{transaction.note || (transaction.status === 'repayment' ? 'Qarz qaytarildi' : 'Izoh yo‘q')}</Text>
                  </View>
                  <View style={{ alignItems: 'flex-end', gap: 8 }}>
                    <Text style={[styles.amount, { color: colors.foreground }]}>{formatMoney(transaction.amount, transaction.currency)}</Text>
                    <StatusPill status={transaction.status} />
                  </View>
                </View>
                
                {transaction.dueDate ? (
                  <View style={styles.dueRow}>
                    <Feather name="calendar" size={14} color={colors.mutedForeground} />
                    <Text style={[styles.due, { color: colors.mutedForeground }]}>Muddat: {transaction.dueDate}</Text>
                  </View>
                ) : null}
                 {transaction.deliveryStatus === 'manual_review' ? (
                   <View style={[styles.deliveryWarning, { borderColor: colors.destructive }]}>
                     <Feather name="alert-triangle" size={16} color={colors.destructive} />
                     <View style={{ flex: 1, gap: 10 }}>
                       <Text style={[styles.deliveryWarningText, { color: colors.foreground }]}>
                         Telegram xabari yetkazilmadi. So‘rov hali kutilmoqda — shu yerdan yoki Telegramdagi /pending orqali ko‘rib chiqing.
                       </Text>
                       {transaction.status === 'repayment_pending' && transaction.debtorId === user?.id ? (
                         <PrimaryButton
                           label={resend.isPending ? 'Qayta yuborilmoqda…' : 'Telegramga qayta yuborish'}
                           onPress={() => resendNotification(transaction.id)}
                           disabled={resend.isPending}
                         />
                       ) : null}
                     </View>
                   </View>
                 ) : null}
                
                {canDecide ? (
                  <View style={styles.decision}>
                    <Text style={[styles.decisionHint, { color: colors.mutedForeground }]}>
                      Tasdiqlashingiz kutilmoqda. To‘g‘ri bo‘lsa tasdiqlang, xato bo‘lsa rad eting.
                    </Text>
                    <View style={styles.decisionActions}>
                    <Pressable 
                      onPress={() => decideTransaction(transaction.id, 'rejected')} 
                      disabled={decide.isPending}
                      style={({ pressed }) => [
                        styles.reject, 
                        { borderColor: colors.border, borderRadius: colors.radius, opacity: decide.isPending ? 0.5 : pressed ? 0.7 : 1 }
                      ]}>
                      <Text style={{ color: colors.mutedForeground, fontWeight: '600' }}>
                        {decide.isPending ? 'Tekshirilmoqda…' : 'Rad etish'}
                      </Text>
                    </Pressable>
                    <View style={{ flex: 1 }}>
                      <PrimaryButton label={decide.isPending ? 'Tekshirilmoqda…' : 'Tasdiqlash'} onPress={() => decideTransaction(transaction.id, 'confirmed')} disabled={decide.isPending} />
                    </View>
                    </View>
                  </View>
                ) : null}
                {['pending', 'repayment_pending'].includes(transaction.status) && isMine ? (
                  <Text style={[styles.waitingHint, { color: colors.mutedForeground }]}>
                    {transaction.status === 'repayment_pending'
                      ? 'Ikkinchi tomon qaytaruvni tasdiqlashini kuting.'
                      : 'Ikkinchi tomon tasdiqlashini kuting.'}
                  </Text>
                ) : null}
                {transaction.canHide ? (
                  <Pressable
                    onPress={() => hideTransaction(transaction.id)}
                    disabled={hide.isPending}
                    style={({ pressed }) => ({
                      marginTop: 16,
                      opacity: hide.isPending ? 0.5 : pressed ? 0.6 : 1,
                    })}>
                    <Text style={{ color: colors.mutedForeground, fontSize: 13, fontWeight: '600' }}>
                      {hide.isPending ? 'Yashirilmoqda…' : 'Tarixdan yashirish'}
                    </Text>
                  </Pressable>
                ) : null}
              </Card>
            );
          })}
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  actions: { paddingHorizontal: 24, paddingBottom: 16, flexDirection: 'row', gap: 12 },
  clearFilter: { paddingHorizontal: 24, paddingBottom: 12 },
  clearFilterText: { fontSize: 14, fontWeight: '600' },
  action: { flex: 1, height: 52, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 },
  actionLabel: { fontSize: 14, fontWeight: '600' },
  decisionError: { marginHorizontal: 24, marginBottom: 4, borderWidth: 1, flexDirection: 'row', gap: 10, padding: 14, alignItems: 'flex-start' },
  decisionErrorText: { flex: 1, fontSize: 13, lineHeight: 19, fontWeight: '600' },
  success: { marginHorizontal: 24, marginBottom: 8, padding: 14, flexDirection: 'row', alignItems: 'center', gap: 10 },
  successText: { flex: 1, fontSize: 13, lineHeight: 19, fontWeight: '600' },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12 },
  retry: { alignSelf: 'stretch' },
  content: { padding: 24, paddingBottom: 140, gap: 12 },
  row: { flexDirection: 'row', gap: 12 },
  name: { fontSize: 17, fontWeight: '700' },
  direction: { fontSize: 13, fontWeight: '600' },
  note: { fontSize: 14, lineHeight: 20 },
  amount: { fontSize: 16, fontWeight: '700' },
  dueRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 16 },
  due: { fontSize: 13, fontWeight: '500' },
  decision: { gap: 10, marginTop: 20 },
  decisionHint: { fontSize: 13, fontWeight: '600' },
  waitingHint: { fontSize: 13, lineHeight: 19, fontWeight: '600', marginTop: 16 },
  deliveryWarning: { flexDirection: 'row', alignItems: 'flex-start', gap: 8, borderWidth: 1, padding: 12, marginTop: 16, borderRadius: 10 },
  deliveryWarningText: { flex: 1, fontSize: 13, lineHeight: 19, fontWeight: '600' },
  decisionActions: { flexDirection: 'row', gap: 12 },
  reject: { minWidth: 100, borderWidth: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 12, height: 56 },
});