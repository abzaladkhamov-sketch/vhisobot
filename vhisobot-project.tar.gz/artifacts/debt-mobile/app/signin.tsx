import { Feather } from '@expo/vector-icons';
import { Redirect, router } from 'expo-router';
import { useState } from 'react';
import { StyleSheet, Text, TextInput, View } from 'react-native';
import { useExchangeAccessCode } from '@workspace/api-client-react';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { PrimaryButton } from '@/components/finance-ui';
import { useAuth } from '@/contexts/AuthContext';
import { useColors } from '@/hooks/useColors';

export default function SignInScreen() {
  const [code, setCode] = useState('');
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const colors = useColors();
  const { ready, token, saveSession } = useAuth();
  const exchange = useExchangeAccessCode();

  if (ready && token) return <Redirect href="/dashboard" />;
  
  const submit = () => {
    setError('');
    exchange.mutate(
      { data: { code: code.trim().toUpperCase(), pin: pin || null } },
      {
        onSuccess: async (session) => {
          await saveSession(session);
          router.replace('/dashboard');
        },
        onError: (requestError: any) => setError(requestError?.message ?? 'Kod yoki PIN noto‘g‘ri.'),
      },
    );
  };

  return (
    <KeyboardAwareScrollViewCompat
      style={{ flex: 1, backgroundColor: colors.background }}
      contentContainerStyle={styles.content}
      bottomOffset={60}>
      <View style={styles.header}>
        <View style={[styles.mark, { backgroundColor: colors.primary }]}>
          <Feather name="book-open" size={28} color={colors.primaryForeground} />
        </View>
        <Text style={[styles.title, { color: colors.foreground }]}>Qarz{'\n'}Hisobi</Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>Qarzlar va va’dalarni xotirjam yuriting.</Text>
      </View>

      <View style={[styles.form, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius }]}>
        <View style={styles.formHeader}>
          <Text style={[styles.formTitle, { color: colors.foreground }]}>Telegram orqali kiring</Text>
          <Text style={[styles.help, { color: colors.mutedForeground }]}>Botdagi /web buyrug‘idan kod oling. Kod 10 daqiqa va bir marta ishlaydi.</Text>
        </View>

        <View style={styles.inputGroup}>
          <Text style={[styles.label, { color: colors.foreground }]}>Kirish kodi</Text>
          <TextInput 
            testID="access-code-input" 
            value={code} 
            onChangeText={setCode} 
            autoCapitalize="characters" 
            autoCorrect={false} 
            placeholder="Masalan: 7A2C…"
            placeholderTextColor={colors.mutedForeground} 
            style={[styles.input, { color: colors.foreground, backgroundColor: colors.background, borderColor: colors.input, borderRadius: colors.radius - 4 }]} 
          />
        </View>

        <View style={styles.inputGroup}>
          <Text style={[styles.label, { color: colors.foreground }]}>PIN (yoqilgan bo‘lsa)</Text>
          <TextInput 
            testID="signin-pin-input" 
            value={pin} 
            onChangeText={(value) => setPin(value.replace(/\D/g, '').slice(0, 4))}
            keyboardType="number-pad" 
            secureTextEntry 
            maxLength={4} 
            placeholder="••••" 
            placeholderTextColor={colors.mutedForeground}
            style={[styles.input, { color: colors.foreground, backgroundColor: colors.background, borderColor: colors.input, borderRadius: colors.radius - 4 }]} 
          />
        </View>

        {error ? <Text style={[styles.error, { color: colors.destructive }]}>{error}</Text> : null}
        
        <View style={{ marginTop: 8 }}>
          <PrimaryButton 
            label={exchange.isPending ? 'Tekshirilmoqda…' : 'Kirish'} 
            onPress={submit} 
            disabled={!code.trim() || exchange.isPending} 
            testID="signin-submit" 
          />
        </View>
      </View>
    </KeyboardAwareScrollViewCompat>
  );
}

const styles = StyleSheet.create({
  content: { flexGrow: 1, justifyContent: 'center', paddingHorizontal: 24, paddingVertical: 48 },
  header: { marginBottom: 40, gap: 16 },
  mark: { width: 64, height: 64, borderRadius: 20, alignItems: 'center', justifyContent: 'center', marginBottom: 8 },
  title: { fontSize: 44, lineHeight: 48, fontWeight: '700', letterSpacing: -1.5 },
  subtitle: { fontSize: 18, lineHeight: 26, maxWidth: 300 },
  form: { padding: 24, borderWidth: 1, gap: 20 },
  formHeader: { gap: 8 },
  formTitle: { fontSize: 20, fontWeight: '700' },
  help: { fontSize: 14, lineHeight: 22 },
  inputGroup: { gap: 8 },
  label: { fontSize: 14, fontWeight: '600' },
  input: { borderWidth: 1, height: 56, paddingHorizontal: 16, fontSize: 16 },
  error: { fontSize: 14, fontWeight: '500' },
});