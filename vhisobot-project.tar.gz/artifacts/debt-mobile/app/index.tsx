import { Redirect } from 'expo-router';
import { View } from 'react-native';
import { useAuth } from '@/contexts/AuthContext';
import { useColors } from '@/hooks/useColors';

export default function IndexScreen() {
  const { ready, token } = useAuth();
  const colors = useColors();
  if (!ready) return <View style={{ flex: 1, backgroundColor: colors.background }} />;
  return <Redirect href={token ? '/dashboard' : '/signin'} />;
}