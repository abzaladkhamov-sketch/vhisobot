import { Feather } from '@expo/vector-icons';
import { useQueryClient } from '@tanstack/react-query';
import {
  getListContactsQueryKey,
  useCreateRepayment,
  useCreateTransaction,
  useListContacts,
} from '@workspace/api-client-react';
import { router, useLocalSearchParams } from 'expo-router';
import { useState } from 'react';
import { Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import * as Haptics from 'expo-haptics';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { PrimaryButton } from '@/components/finance-ui';
import { useColors } from '@/hooks/useColors';
import { useAuth } from '@/contexts/AuthContext';

export default function EntryScreen() {
  const { kind } = useLocalSearchParams<{ kind?: 'debt' | 'repayment' }>();
  const repayment = kind === 'repayment';
  const colors = useColors();
  const { ready, token } = useAuth();
  const queryClient = useQueryClient();
  const contacts = useListContacts({
    query: { enabled: ready && Boolean(token), queryKey: getListContactsQueryKey() },
  });
  const createTransaction = useCreateTransaction();
  const createRepayment = useCreateRepayment();
  
  const [contactId, setContactId] = useState<number | null>(null);
  const [direction, setDirection] = useState<'received' | 'given'>('received');
  const [amount, setAmount] = useState('');
  const [currency, setCurrency] = useState('UZS');
  const [note, setNote] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [error, setError] = useState('');
  
  const isSaving = createTransaction.isPending || createRepayment.isPending;
  const selectedContact = contacts.data?.find((contact) => contact.id === contactId);
  const summary = selectedContact && amount
    ? `${selectedContact.displayName}: ${
        repayment
          ? `${amount} ${currency} qaytaruv`
          : `${direction === 'received' ? 'Oldim — men qarzdorman' : 'Berdim — undan olishim kerak'}, ${amount} ${currency}${dueDate ? `, muddat ${dueDate}` : ', muddatsiz'}`
      }`
    : '';

  const handleContactSelect = (id: number) => {
    void Haptics.selectionAsync();
    setContactId(id);
  };

  const handleDirectionSelect = (dir: 'received' | 'given') => {
    void Haptics.selectionAsync();
    setDirection(dir);
  };

  const submit = () => {
    setError('');
    const numericAmount = Number(amount.replace(/\s/g, ''));
    if (!contactId || !Number.isSafeInteger(numericAmount) || numericAmount <= 0 || !/^[A-Z]{3}$/.test(currency)) {
      setError('Kontakt, butun summa va 3 harfli valuta kodini kiriting.');
      return;
    }
    if (dueDate && !/^\d{4}-\d{2}-\d{2}$/.test(dueDate)) {
      setError('Muddat YYYY-MM-DD ko‘rinishida bo‘lishi kerak.');
      return;
    }
    const complete = () => {
      void queryClient.invalidateQueries();
      router.replace(`/transactions?result=${repayment ? 'repayment-saved' : 'debt-sent'}`);
    };
    if (repayment) {
      createRepayment.mutate({ data: { contactId, amount: numericAmount, currency, note: note || null } }, { onSuccess: complete, onError: (e: any) => setError(e?.message ?? 'Saqlab bo‘lmadi. Internetni tekshirib, qayta urinib ko‘ring.') });
      return;
    }
    createTransaction.mutate(
      { data: { contactId, direction, amount: numericAmount, currency, note: note || null, dueDate: dueDate || null } },
      { onSuccess: complete, onError: (e: any) => setError(e?.message ?? 'Saqlab bo‘lmadi. Internetni tekshirib, qayta urinib ko‘ring.') },
    );
  };

  return (
    <KeyboardAwareScrollViewCompat style={{ flex: 1, backgroundColor: colors.background }} contentContainerStyle={styles.content} bottomOffset={60}>
      
      <View style={styles.header}>
        <Text style={[styles.title, { color: colors.foreground }]}>{repayment ? 'Qaytaruv kiritish' : 'Qarz kiritish'}</Text>
        <Text style={[styles.detail, { color: colors.mutedForeground }]}>{repayment ? 'Qaytaruv ikkinchi tomon tasdiqlagach balansdan ayriladi.' : 'Qarz balansga faqat ikkinchi tomon tasdiqlagandan keyin qo‘shiladi.'}</Text>
      </View>

      <View style={styles.formGroup}>
        <Text style={[styles.label, { color: colors.foreground }]}>Kontakt</Text>
        <View style={styles.contactGrid}>
          {contacts.data?.map((contact) => (
            <Pressable 
              key={contact.id} 
              onPress={() => handleContactSelect(contact.id)}
              style={[
                styles.contact, 
                { 
                  borderColor: contactId === contact.id ? colors.primary : colors.border, 
                  backgroundColor: contactId === contact.id ? colors.accent : colors.card, 
                  borderRadius: colors.radius 
                }
              ]}>
              <View style={[styles.contactAvatar, { backgroundColor: contactId === contact.id ? colors.primary : colors.muted }]}>
                <Text style={{ color: contactId === contact.id ? colors.primaryForeground : colors.mutedForeground, fontWeight: '700' }}>
                  {contact.displayName.slice(0, 1).toUpperCase()}
                </Text>
              </View>
              <Text style={[styles.contactName, { color: contactId === contact.id ? colors.accentForeground : colors.foreground }]} numberOfLines={1}>
                {contact.displayName}
              </Text>
            </Pressable>
          ))}
        </View>
      </View>

      {!repayment ? (
        <View style={styles.formGroup}>
          <Text style={[styles.label, { color: colors.foreground }]}>Qarz yo‘nalishi</Text>
          <View style={styles.segment}>
            {([{ value: 'received', label: 'Oldim — men qarzdorman' }, { value: 'given', label: 'Berdim — undan olishim kerak' }] as const).map((option) => (
              <Pressable 
                key={option.value} 
                onPress={() => handleDirectionSelect(option.value)} 
                style={[
                  styles.segmentItem, 
                  { 
                    backgroundColor: direction === option.value ? colors.primary : colors.card, 
                    borderColor: colors.border,
                    borderWidth: direction === option.value ? 0 : 1,
                    borderRadius: colors.radius 
                  }
                ]}>
                <Text style={{ color: direction === option.value ? colors.primaryForeground : colors.foreground, fontWeight: '600', fontSize: 15 }}>
                  {option.label}
                </Text>
              </Pressable>
            ))}
          </View>
        </View>
      ) : null}

      <View style={styles.formGroup}>
        <Text style={[styles.label, { color: colors.foreground }]}>Summa</Text>
        <TextInput 
          testID="entry-amount"
          value={amount} 
          onChangeText={(value) => setAmount(value.replace(/[^\d]/g, ''))} 
          keyboardType="number-pad" 
          placeholder="0" 
          placeholderTextColor={colors.mutedForeground}
          style={[styles.input, { color: colors.foreground, backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius }]} 
        />
      </View>

      <View style={styles.formGroup}>
        <Text style={[styles.label, { color: colors.foreground }]}>Valuta</Text>
        <TextInput 
          value={currency} 
          onChangeText={(value) => setCurrency(value.toUpperCase().slice(0, 3))} 
          autoCapitalize="characters" 
          placeholder="UZS" 
          placeholderTextColor={colors.mutedForeground}
          style={[styles.input, { color: colors.foreground, backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius }]} 
        />
      </View>

      {!repayment ? (
        <View style={styles.formGroup}>
          <Text style={[styles.label, { color: colors.foreground }]}>Muddat (ixtiyoriy)</Text>
          <TextInput 
            value={dueDate} 
            onChangeText={setDueDate} 
            placeholder="YYYY-MM-DD" 
            placeholderTextColor={colors.mutedForeground} 
            style={[styles.input, { color: colors.foreground, backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius }]} 
          />
        </View>
      ) : null}

      <View style={styles.formGroup}>
        <Text style={[styles.label, { color: colors.foreground }]}>Izoh (ixtiyoriy)</Text>
        <TextInput 
          value={note} 
          onChangeText={setNote} 
          placeholder="Qisqa eslatma" 
          placeholderTextColor={colors.mutedForeground} 
          multiline 
          style={[styles.note, { color: colors.foreground, backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius }]} 
        />
      </View>

      {summary ? (
        <View style={[styles.summary, { backgroundColor: colors.accent, borderRadius: colors.radius }]}>
          <Text style={[styles.summaryTitle, { color: colors.accentForeground }]}>
            {repayment ? 'Saqlashdan oldingi xulosa' : 'Yuborishdan oldingi xulosa'}
          </Text>
          <Text style={[styles.summaryText, { color: colors.accentForeground }]}>{summary}</Text>
          <Text style={[styles.summaryHint, { color: colors.accentForeground }]}>
            'Balans kontakt tasdiqlagach yangilanadi.'
          </Text>
        </View>
      ) : null}

      {error ? <Text style={[styles.error, { color: colors.destructive }]}>{error}</Text> : null}
      
      <View style={{ marginTop: 8 }}>
        <PrimaryButton 
          label={isSaving ? 'Saqlanmoqda…' : repayment ? 'Qaytaruvni saqlash' : 'Qarz so‘rovini yuborish'}
          onPress={submit} 
          disabled={isSaving} 
          testID="entry-submit" 
        />
      </View>
    </KeyboardAwareScrollViewCompat>
  );
}

const styles = StyleSheet.create({
  content: { padding: 24, gap: 24, paddingBottom: 64 },
  header: { gap: 6, marginBottom: 8 },
  title: { fontSize: 28, fontWeight: '700', letterSpacing: -0.5 },
  detail: { fontSize: 15, lineHeight: 22 },
  formGroup: { gap: 8 },
  label: { fontSize: 14, fontWeight: '600', marginLeft: 4 },
  contactGrid: { gap: 10 },
  contact: { minHeight: 56, borderWidth: 1, paddingHorizontal: 16, paddingVertical: 12, alignItems: 'center', flexDirection: 'row', gap: 12 },
  contactAvatar: { width: 32, height: 32, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  contactName: { fontSize: 16, fontWeight: '600', flex: 1 },
  segment: { flexDirection: 'row', gap: 10 },
  segmentItem: { flex: 1, minHeight: 52, alignItems: 'center', justifyContent: 'center' },
  input: { borderWidth: 1, minHeight: 56, paddingHorizontal: 16, fontSize: 16 },
  note: { borderWidth: 1, minHeight: 100, padding: 16, textAlignVertical: 'top', fontSize: 16 },
  summary: { padding: 16, gap: 6 },
  summaryTitle: { fontSize: 14, fontWeight: '700' },
  summaryText: { fontSize: 14, lineHeight: 20 },
  summaryHint: { fontSize: 12, lineHeight: 18, opacity: 0.8 },
  error: { fontSize: 14, fontWeight: '500', marginTop: 4, marginLeft: 4 },
});