import AsyncStorage from '@react-native-async-storage/async-storage';
import { useQueryClient } from '@tanstack/react-query';
import { getGetCurrentUserQueryKey, useGetCurrentUser, setAuthTokenGetter, type AuthSession, type UserProfile } from '@workspace/api-client-react';
import React, { createContext, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';

type AuthContextValue = {
  ready: boolean;
  token: string | null;
  user: UserProfile | null;
  saveSession: (session: AuthSession) => Promise<void>;
  logout: () => Promise<void>;
};

const STORAGE_KEY = 'qarz_hisobi_session';
const AuthContext = createContext<AuthContextValue | undefined>(undefined);
let bearerToken: string | null = null;
setAuthTokenGetter(() => bearerToken);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [token, setToken] = useState<string | null>(null);
  const [ready, setReady] = useState(false);
  const queryClient = useQueryClient();
  const tokenRef = useRef<string | null>(null);

  useEffect(() => {
    void (async () => {
      const saved = await AsyncStorage.getItem(STORAGE_KEY);
      tokenRef.current = saved;
      bearerToken = saved;
      setToken(saved);
      setReady(true);
    })();
  }, []);

  const { data: user, isError } = useGetCurrentUser({
    query: { enabled: ready && Boolean(token), retry: false, queryKey: getGetCurrentUserQueryKey() },
  });

  useEffect(() => {
    if (ready && token && isError) {
      void logout();
    }
  }, [isError, ready, token]);

  const saveSession = async (session: AuthSession) => {
    tokenRef.current = session.accessToken;
    bearerToken = session.accessToken;
    setToken(session.accessToken);
    await AsyncStorage.setItem(STORAGE_KEY, session.accessToken);
    queryClient.setQueryData(['getCurrentUser'], session.user);
  };

  const logout = async () => {
    tokenRef.current = null;
    bearerToken = null;
    setToken(null);
    await AsyncStorage.removeItem(STORAGE_KEY);
    queryClient.clear();
  };

  const value = useMemo(
    () => ({ ready, token, user: user ?? null, saveSession, logout }),
    [ready, token, user],
  );
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth AuthProvider ichida ishlatilishi kerak.');
  return context;
}