import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import type { ReactNode } from 'react';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';

export function formatMoney(amount: number, currency: string) {
  return `${new Intl.NumberFormat('uz-UZ').format(amount)} ${currency}`;
}

export function PageHeader({
  title,
  eyebrow,
  action,
}: {
  title: string;
  eyebrow?: string;
  action?: ReactNode;
}) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  return (
    <View style={[styles.header, { paddingTop: insets.top + (Platform.OS === 'web' ? 67 : 20) }]}>
      <View style={styles.headerCopy}>
        {eyebrow ? <Text style={[styles.eyebrow, { color: colors.mutedForeground }]}>{eyebrow}</Text> : null}
        <Text style={[styles.title, { color: colors.foreground }]}>{title}</Text>
      </View>
      {action}
    </View>
  );
}

export function Card({ children, tone = 'card' }: { children: ReactNode; tone?: 'card' | 'accent' }) {
  const colors = useColors();
  return (
    <View
      style={[
        styles.card,
        {
          backgroundColor: tone === 'accent' ? colors.accent : colors.card,
          borderColor: tone === 'accent' ? 'transparent' : colors.border,
          borderWidth: tone === 'accent' ? 0 : 1,
          borderRadius: colors.radius,
        },
      ]}>
      {children}
    </View>
  );
}

export function PrimaryButton({
  label,
  onPress,
  disabled,
  icon,
  testID,
}: {
  label: string;
  onPress: () => void;
  disabled?: boolean;
  icon?: keyof typeof Feather.glyphMap;
  testID?: string;
}) {
  const colors = useColors();
  return (
    <Pressable
      testID={testID}
      disabled={disabled}
      onPress={() => {
        void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
        onPress();
      }}
      style={({ pressed }) => [
        styles.primaryButton,
        {
          backgroundColor: colors.primary,
          borderRadius: colors.radius,
          opacity: disabled ? 0.5 : pressed ? 0.85 : 1,
          transform: [{ scale: pressed && !disabled ? 0.98 : 1 }],
        },
      ]}>
      {icon ? <Feather name={icon} size={18} color={colors.primaryForeground} /> : null}
      <Text style={[styles.primaryLabel, { color: colors.primaryForeground }]}>{label}</Text>
    </Pressable>
  );
}

export function IconButton({
  icon,
  label,
  onPress,
  testID,
}: {
  icon: keyof typeof Feather.glyphMap;
  label: string;
  onPress: () => void;
  testID?: string;
}) {
  const colors = useColors();
  return (
    <Pressable
      testID={testID}
      accessibilityLabel={label}
      onPress={() => {
        void Haptics.selectionAsync();
        onPress();
      }}
      style={({ pressed }) => [
        styles.iconButton,
        {
          backgroundColor: colors.card,
          borderColor: colors.border,
          borderRadius: colors.radius,
          opacity: pressed ? 0.7 : 1,
          transform: [{ scale: pressed ? 0.96 : 1 }],
        },
      ]}>
      <Feather name={icon} size={20} color={colors.foreground} />
    </Pressable>
  );
}

export function StatusPill({ status }: { status: string }) {
  const colors = useColors();
  const statusMap: Record<string, string> = {
    pending: 'Tasdiqlash kutilmoqda',
    repayment_pending: 'Qaytaruv tasdiqlash kutilmoqda',
    confirmed: 'Tasdiqlangan',
    rejected: 'Rad etilgan',
    repayment: 'Qaytaruv',
  };
  
  let bgColor = colors.muted;
  let textColor = colors.mutedForeground;
  
  if (status === 'rejected') {
    bgColor = colors.destructive;
    textColor = colors.destructiveForeground;
  } else if (status === 'pending' || status === 'repayment_pending') {
    bgColor = colors.accent;
    textColor = colors.accentForeground;
  }

  return (
    <View style={[styles.pill, { backgroundColor: bgColor }]}>
      <Text style={{ color: textColor, fontSize: 12, fontWeight: '600' }}>
        {statusMap[status] ?? status}
      </Text>
    </View>
  );
}

export function EmptyState({ icon, title, detail }: { icon: keyof typeof Feather.glyphMap; title: string; detail: string }) {
  const colors = useColors();
  return (
    <View style={styles.empty}>
      <View style={[styles.emptyIconWrap, { backgroundColor: colors.accent }]}>
        <Feather name={icon} size={28} color={colors.accentForeground} />
      </View>
      <Text style={[styles.emptyTitle, { color: colors.foreground }]}>{title}</Text>
      <Text style={[styles.emptyDetail, { color: colors.mutedForeground }]}>{detail}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  header: { paddingHorizontal: 24, paddingBottom: 24, flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between' },
  headerCopy: { gap: 4 },
  eyebrow: { fontSize: 13, fontWeight: '600', letterSpacing: 0.5, textTransform: 'uppercase' },
  title: { fontSize: 32, fontWeight: '700', letterSpacing: -1 },
  card: { padding: 20 },
  primaryButton: { minHeight: 56, paddingHorizontal: 20, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 10 },
  primaryLabel: { fontSize: 16, fontWeight: '600', letterSpacing: 0.3 },
  iconButton: { width: 44, height: 44, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  pill: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 12, alignSelf: 'flex-start' },
  empty: { alignItems: 'center', paddingVertical: 60, paddingHorizontal: 32, gap: 12 },
  emptyIconWrap: { width: 64, height: 64, borderRadius: 32, alignItems: 'center', justifyContent: 'center', marginBottom: 8 },
  emptyTitle: { fontSize: 18, fontWeight: '700' },
  emptyDetail: { fontSize: 15, lineHeight: 22, textAlign: 'center' },
});