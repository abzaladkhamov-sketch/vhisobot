import { Feather } from '@expo/vector-icons';
import { useQueryClient } from '@tanstack/react-query';
import { useUnlockPrivacy } from '@workspace/api-client-react';
import { DeviceEventEmitter, Modal, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useColors } from '@/hooks/useColors';
import { PrimaryButton } from './finance-ui';

export function PinUnlockDialog() {
  const [visible, setVisible] = useState(false);
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const colors = useColors();
  const { saveSession } = useAuth();
  const queryClient = useQueryClient();
  const unlock = useUnlockPrivacy();

  useEffect(() => {
    const subscription = DeviceEventEmitter.addListener('require-pin', () => setVisible(true));
    return () => subscription.remove();
  }, []);

  const submit = () => {
    if (!/^\d{4}$/.test(pin)) {
      setError('PIN 4 ta raqamdan iborat bo‘lishi kerak.');
      return;
    }
    unlock.mutate(
      { data: { pin } },
      {
        onSuccess: async (session) => {
          await saveSession(session);
          setPin('');
          setError('');
          setVisible(false);
          await queryClient.invalidateQueries();
        },
        onError: (requestError: any) => setError(requestError?.message ?? 'PIN tekshirilmadi.'),
      },
    );
  };

  return (
    <Modal transparent visible={visible} animationType="fade" onRequestClose={() => setVisible(false)}>
      <View style={[styles.backdrop, { backgroundColor: 'rgba(21, 28, 26, 0.7)' }]}>
        <View style={[styles.sheet, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius }]}>
          <Pressable onPress={() => setVisible(false)} accessibilityLabel="Yopish" style={styles.close}>
            <Feather name="x" size={24} color={colors.mutedForeground} />
          </Pressable>
          <View style={styles.header}>
            <View style={[styles.lock, { backgroundColor: colors.accent }]}>
              <Feather name="lock" size={28} color={colors.accentForeground} />
            </View>
            <Text style={[styles.title, { color: colors.foreground }]}>Ma’lumotlar qulflangan</Text>
            <Text style={[styles.detail, { color: colors.mutedForeground }]}>Balans va tarixni ko‘rish uchun PIN’ingizni kiriting.</Text>
          </View>
          <View style={styles.form}>
            <TextInput
              testID="pin-unlock-input"
              value={pin}
              onChangeText={(value) => setPin(value.replace(/\D/g, '').slice(0, 4))}
              keyboardType="number-pad"
              secureTextEntry
              maxLength={4}
              placeholder="••••"
              placeholderTextColor={colors.mutedForeground}
              style={[styles.input, { color: colors.foreground, backgroundColor: colors.background, borderColor: colors.input, borderRadius: colors.radius - 4 }]}
            />
            {error ? <Text style={[styles.error, { color: colors.destructive }]}>{error}</Text> : null}
            <PrimaryButton label={unlock.isPending ? 'Tekshirilmoqda…' : 'Ochish'} onPress={submit} disabled={unlock.isPending} testID="pin-unlock-submit" />
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24 },
  sheet: { width: '100%', maxWidth: 400, borderWidth: 1, padding: 32, gap: 32, shadowColor: '#000', shadowOffset: { width: 0, height: 12 }, shadowOpacity: 0.15, shadowRadius: 24, elevation: 20 },
  close: { position: 'absolute', top: 20, right: 20, zIndex: 10, padding: 8 },
  header: { alignItems: 'center', gap: 12 },
  lock: { width: 64, height: 64, borderRadius: 32, alignItems: 'center', justifyContent: 'center', marginBottom: 8 },
  title: { fontSize: 24, fontWeight: '700', textAlign: 'center' },
  detail: { fontSize: 15, lineHeight: 22, textAlign: 'center' },
  form: { gap: 16 },
  input: { borderWidth: 1, paddingHorizontal: 20, height: 64, fontSize: 32, letterSpacing: 16, textAlign: 'center' },
  error: { fontSize: 14, fontWeight: '500', textAlign: 'center' },
});