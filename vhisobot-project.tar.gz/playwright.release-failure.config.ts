import { defineConfig, devices } from "@playwright/test";

const isSetupFailure = process.env.RELEASE_E2E_FAILURE_MODE === "setup";

export default defineConfig({
  testDir: "./tests/release",
  timeout: 30_000,
  forbidOnly: true,
  reporter: "list",
  use: {
    trace: "off",
    screenshot: "off",
  },
  ...(isSetupFailure
    ? {
        webServer: {
          command: `${process.execPath} -e "process.stderr.write('release gate test-server setup fixture failed\\n'); process.exit(1)"`,
          url: "http://127.0.0.1:29999",
          timeout: 5_000,
          reuseExistingServer: false,
        },
      }
    : {}),
  projects: [
    {
      name: isSetupFailure
        ? "release-setup-failure"
        : "release-application-failure",
      use: { ...devices["Desktop Chrome"] },
    },
  ],
});
