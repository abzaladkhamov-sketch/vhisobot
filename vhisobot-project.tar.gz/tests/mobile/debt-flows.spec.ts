import { expect, test } from "@playwright/test";
import { authenticateWithFixture } from "../fixtures/auth";

test.describe("mobile web debt flows", () => {
  test("opens an isolated authenticated session and renders status copy", async ({
    page,
    request,
  }) => {
    await authenticateWithFixture(request, page, "qarz_hisobi_session", "/transactions");

    await expect(page.getByText("O‘tkazmalar")).toBeVisible();
    await expect(page.getByText("Tasdiqlash kutilmoqda", { exact: true })).toHaveCount(2);
    await expect(page.getByText("Tasdiqlangan", { exact: true })).toBeVisible();
    await expect(page.getByText("Rad etilgan", { exact: true })).toBeVisible();
    await expect(page.getByText("Qaytaruv", { exact: true })).toBeVisible();
    await expect(page.getByText("Qaytaruv tasdiqlash kutilmoqda").first()).toBeVisible();
    await expect(page.getByText("Qarz qaytarildi")).toBeVisible();
    await expect(page.getByText(/Telegram xabari yetkazilmadi/).first()).toBeVisible();
  });

  test("shows debt summary and retry state", async ({ page, request }) => {
    await authenticateWithFixture(request, page, "qarz_hisobi_session", "/transactions");

    await page.getByTestId("transactions-add").click();
    await expect(page).toHaveURL(/\/entry\?kind=debt/);
    await expect(page.getByText("Qarz kiritish").last()).toBeVisible();
    await page.getByText("Aziza Karimova").last().click();
    await expect(page.getByText("Summa")).toBeVisible();
    await page.getByTestId("entry-amount").fill("250000");
    await expect(page.getByText("Yuborishdan oldingi xulosa")).toBeVisible();
    await expect(page.getByText(/Oldim — men qarzdorman, 250000 UZS/)).toBeVisible();

    await page.route("**/api/transactions**", (route) =>
      route.fulfill({
        status: 500,
        contentType: "application/json",
        body: JSON.stringify({ error: "fixture query failure" }),
      }),
    );
    await page.goto("/transactions?retry=1");
    await expect(page.getByText("Ma’lumotlarni yuklab bo‘lmadi")).toBeVisible();
    await page.unroute("**/api/transactions**");
    await page.getByText("Qayta urinib ko‘rish").click();
    await expect(page.getByText("Tasdiqlangan", { exact: true })).toBeVisible();
  });
});