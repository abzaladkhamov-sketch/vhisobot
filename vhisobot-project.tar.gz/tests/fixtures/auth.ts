import type { APIRequestContext, Page } from "@playwright/test";

type TestSession = {
  accessToken: string;
  user: { id: number; displayName: string };
};

export async function createFixtureSession(
  request: APIRequestContext,
  fixtureUser?: string,
): Promise<TestSession> {
  const apiOrigin =
    process.env.E2E_API_URL ??
    (process.env.REPLIT_DEV_DOMAIN
      ? `https://${process.env.REPLIT_DEV_DOMAIN}`
      : undefined);
  const fixtureUrl = apiOrigin
    ? new URL("/api/auth/test-session", apiOrigin).toString()
    : "/api/auth/test-session";
  const response = await request.post(fixtureUrl, {
    headers: {
      "x-qarz-test-fixture": "1",
      ...(fixtureUser ? { "x-qarz-test-user": fixtureUser } : {}),
    },
  });
  if (!response.ok()) {
    throw new Error(`Test fixture session could not be created: ${response.status()}`);
  }
  return (await response.json()) as TestSession;
}

export async function authenticateWithFixture(
  request: APIRequestContext,
  page: Page,
  storageKey: string,
  path: string,
  fixtureUser?: string,
): Promise<void> {
  const session = await createFixtureSession(request, fixtureUser);
  await page.addInitScript(
    ({ key, token }) => window.localStorage.setItem(key, token),
    { key: storageKey, token: session.accessToken },
  );
  await page.goto(path);
}