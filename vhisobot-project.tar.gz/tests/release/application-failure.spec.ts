import { expect, test } from "@playwright/test";

test("reports a deterministic application assertion failure", async ({
  page,
}) => {
  await page.setContent("<main><h1>Release failure fixture</h1></main>");
  await expect(
    page.getByRole("heading", { name: "Expected application heading" }),
  ).toBeVisible();
});
