import { expect, test } from "@playwright/test";
import { authenticateWithFixture, createFixtureSession } from "../fixtures/auth";

test.describe("web debt flows", () => {
  test("opens an isolated authenticated ledger and renders every status effect", async ({
    page,
    request,
  }) => {
    await authenticateWithFixture(request, page, "qarz_token", "/transactions");

    await expect(page.getByRole("heading", { name: "O'tkazmalar" })).toBeVisible();
    await expect(page.getByText("Tasdiqlash kutilmoqda", { exact: true })).toHaveCount(2);
    await expect(page.getByText("Tasdiqlangan", { exact: true }).first()).toBeVisible();
    await expect(page.getByText("Rad etilgan", { exact: true })).toBeVisible();
    await expect(page.getByText("Qaytaruv", { exact: true })).toBeVisible();
    await expect(page.getByText("Qaytaruv tasdiqlash kutilmoqda", { exact: true }).first()).toBeVisible();
    await expect(page.getByText(/Telegram xabari yetkazilmadi/).first()).toBeVisible();
    await expect(page.getByText("Siz qarzdorsiz — balans hali o‘zgarmagan").first()).toBeVisible();
    await expect(page.getByText("Siz qarzdorsiz", { exact: true })).toBeVisible();
    await expect(page.getByText("Qarz rad etildi")).toHaveCount(0);
    await expect(page.getByText("balansga qo‘shilmagan")).toBeVisible();
    await expect(page.getByText("Qarzingiz kamaydi")).toBeVisible();
  });

  test("confirms a pending repayment only after the counterparty decision", async ({
    page,
    request,
  }) => {
    await authenticateWithFixture(request, page, "qarz_token", "/transactions");

    await expect(page.getByText("Qaytaruv tasdiqlash kutilmoqda", { exact: true }).first()).toBeVisible();
    await page.getByRole("button", { name: "Tasdiqlash" }).nth(1).click();
    await expect(page.getByText("Qaytaruv tasdiqlandi. Balans yangilandi.")).toBeVisible();
  });

  test("sanitizes Telegram delivery details in direct API responses", async ({ request }) => {
    const session = await createFixtureSession(request);
    const headers = { Authorization: `Bearer ${session.accessToken}` };
    const assertSafeResponse = (body: unknown) => {
      const serialized = JSON.stringify(body);
      expect(serialized).not.toContain("last_error");
      expect(serialized).not.toContain("Telegram bot was blocked by the recipient");
      expect(serialized).not.toContain("permanent_failure");
    };

    const transactionsResponse = await request.get("/api/transactions", { headers });
    expect(transactionsResponse.ok()).toBeTruthy();
    const transactions = await transactionsResponse.json();
    assertSafeResponse(transactions);

    expect(
      transactions.find((transaction: { id: number }) => transaction.id === 910_000_001),
    ).toMatchObject({
      status: "pending",
      deliveryStatus: "manual_review",
    });
    expect(
      transactions.find((transaction: { id: number }) => transaction.id === 910_000_002),
    ).toMatchObject({
      status: "pending",
      deliveryStatus: "sent",
    });
    expect(
      transactions.find((transaction: { id: number }) => transaction.id === 910_000_007),
    ).toMatchObject({
      status: "repayment_pending",
      deliveryStatus: "manual_review",
    });

    const createdResponse = await request.post("/api/transactions", {
      headers,
      data: {
        contactId: 900_000_002,
        direction: "given",
        amount: 10_000,
        currency: "UZS",
      },
    });
    expect(createdResponse.status()).toBe(201);
    const created = await createdResponse.json();
    assertSafeResponse(created);
    expect(created).toMatchObject({
      status: "pending",
      deliveryStatus: "pending",
    });

    const dashboardResponse = await request.get("/api/dashboard", { headers });
    expect(dashboardResponse.ok()).toBeTruthy();
    const dashboard = await dashboardResponse.json();
    assertSafeResponse(dashboard);
    expect(
      dashboard.recentTransactions.find(
        (transaction: { id: number }) => transaction.id === 910_000_007,
      ),
    ).toMatchObject({
      status: "repayment_pending",
      deliveryStatus: "manual_review",
    });

    const confirmedResponse = await request.post(
      "/api/transactions/910000001/decision",
      { headers, data: { decision: "confirmed" } },
    );
    expect(confirmedResponse.ok()).toBeTruthy();
    const confirmed = await confirmedResponse.json();
    assertSafeResponse(confirmed);
    expect(confirmed).toMatchObject({
      status: "confirmed",
      deliveryStatus: null,
    });

    const rejectionSession = await createFixtureSession(request);
    const rejectedResponse = await request.post(
      "/api/transactions/910000001/decision",
      {
        headers: { Authorization: `Bearer ${rejectionSession.accessToken}` },
        data: { decision: "rejected" },
      },
    );
    expect(rejectedResponse.ok()).toBeTruthy();
    const rejected = await rejectedResponse.json();
    assertSafeResponse(rejected);
    expect(rejected).toMatchObject({
      status: "rejected",
      deliveryStatus: null,
    });
  });

  test("confirms and rejects a repayment after Telegram delivery permanently fails", async ({
    request,
  }) => {
    const assertSafeResponse = (body: unknown) => {
      const serialized = JSON.stringify(body);
      expect(serialized).not.toContain("last_error");
      expect(serialized).not.toContain("Telegram bot was blocked by the recipient");
      expect(serialized).not.toContain("permanent_failure");
    };

    const exerciseDecision = async (decision: "confirmed" | "rejected") => {
      const session = await createFixtureSession(request);
      const headers = { Authorization: `Bearer ${session.accessToken}` };

      const beforeResponse = await request.get("/api/transactions", { headers });
      expect(beforeResponse.ok()).toBeTruthy();
      const beforeTransactions = await beforeResponse.json();
      assertSafeResponse(beforeTransactions);
      expect(
        beforeTransactions.find((transaction: { id: number }) => transaction.id === 910_000_007),
      ).toMatchObject({
        status: "repayment_pending",
        deliveryStatus: "manual_review",
      });

      const beforeDashboardResponse = await request.get("/api/dashboard", { headers });
      expect(beforeDashboardResponse.ok()).toBeTruthy();
      const beforeDashboard = await beforeDashboardResponse.json();
      assertSafeResponse(beforeDashboard);

      const decisionResponse = await request.post(
        "/api/transactions/910000007/decision",
        { headers, data: { decision } },
      );
      expect(decisionResponse.ok()).toBeTruthy();
      const decided = await decisionResponse.json();
      assertSafeResponse(decided);
      expect(decided).toMatchObject({
        status: decision === "confirmed" ? "repayment" : "rejected",
        deliveryStatus: null,
      });

      const afterResponse = await request.get("/api/transactions", { headers });
      expect(afterResponse.ok()).toBeTruthy();
      const afterTransactions = await afterResponse.json();
      assertSafeResponse(afterTransactions);
      expect(
        afterTransactions.find((transaction: { id: number }) => transaction.id === 910_000_007),
      ).toMatchObject({
        status: decision === "confirmed" ? "repayment" : "rejected",
        deliveryStatus: null,
      });

      const afterDashboardResponse = await request.get("/api/dashboard", { headers });
      expect(afterDashboardResponse.ok()).toBeTruthy();
      const afterDashboard = await afterDashboardResponse.json();
      assertSafeResponse(afterDashboard);
      expect(afterDashboard.pendingCount).toBe(beforeDashboard.pendingCount - 1);
    };

    await exerciseDecision("confirmed");
    await exerciseDecision("rejected");
  });

  test("shows canonical debt and repayment summaries before submitting", async ({
    page,
    request,
  }) => {
    await authenticateWithFixture(request, page, "qarz_token", "/transactions");

    await page.getByRole("button", { name: "Qarz kiritish" }).first().click();
    await expect(page.getByRole("heading", { name: "Qarz kiritish" })).toBeVisible();
    await expect(page.getByText("Ikkinchi tomon", { exact: true })).toBeVisible();
    await expect(page.getByText("Qarz yo‘nalishi", { exact: true })).toBeVisible();
    await page.locator("select").first().selectOption("900000002");
    await page.locator("select").nth(1).selectOption("received");
    await page.locator('input[type="number"]').first().fill("250000");
    await expect(page.getByText("Yuborishdan oldingi xulosa")).toBeVisible();
    await expect(page.getByText(/Oldim — men qarzdorman, 250000 USD/)).toBeVisible();
    await expect(page.getByText("Balans kontakt tasdiqlagach yangilanadi.")).toBeVisible();

    await page.keyboard.press("Escape");
    await expect(page.getByRole("heading", { name: "Qarz kiritish" })).toBeHidden();
    await page.getByRole("button", { name: "Qaytaruv kiritish" }).click();
    await expect(page.getByRole("heading", { name: "Qaytaruv kiritish" })).toBeVisible();
    await expect(page.getByText("Qaytaruv kimga", { exact: true })).toBeVisible();
    await page.locator("select").last().selectOption("900000002");
    await page.locator('input[type="number"]').last().fill("50000");
    await expect(page.getByText("Saqlashdan oldingi xulosa")).toBeVisible();
    await expect(page.getByText(/50000 USD qaytaruv kiritiladi/)).toBeVisible();
    await expect(page.getByText("Balans kontakt tasdiqlagach yangilanadi.", { exact: true })).toBeVisible();
  });

  test("covers confirmation success, mutation error, and query retry", async ({
    page,
    request,
  }) => {
    await authenticateWithFixture(request, page, "qarz_token", "/transactions");

    await page.getByRole("button", { name: "Tasdiqlash" }).first().click();
    await expect(page.getByText("Qarz tasdiqlandi. Balans yangilandi.")).toBeVisible();

    await page.route("**/api/transactions**", async (route) => {
      if (route.request().method() === "POST") {
        await route.fulfill({
          status: 500,
          contentType: "application/json",
          body: JSON.stringify({ error: "fixture mutation failure" }),
        });
      }
      else await route.continue();
    });
    await page.getByRole("button", { name: "Qarz kiritish" }).first().click();
    await page.locator("select").first().selectOption("900000002");
    await page.locator('input[type="number"]').first().fill("100");
    await page.getByRole("button", { name: "Qarz so‘rovini yuborish" }).click();
    await expect(page.getByRole("alert")).toContainText("fixture mutation failure");

    await page.unroute("**/api/transactions**");
    await page.route("**/api/transactions**", (route) =>
      route.fulfill({
        status: 500,
        contentType: "application/json",
        body: JSON.stringify({ error: "fixture query failure" }),
      }),
    );
    await page.goto("/transactions?retry=1");
    await expect(page.getByText("Ma’lumotlarni yuklab bo‘lmadi.", { exact: true })).toBeVisible();
    await page.unroute("**/api/transactions**");
    await page.getByRole("button", { name: "Qayta urinib ko‘rish" }).click();
    await expect(page.getByText("Tasdiqlangan", { exact: true }).first()).toBeVisible();
  });

  test("hides a rejected entry only from the current user's history", async ({
    page,
    request,
  }) => {
    await authenticateWithFixture(request, page, "qarz_token", "/transactions");
    page.on("dialog", (dialog) => dialog.accept());

    await expect(page.getByRole("button", { name: "Tarixdan yashirish" })).toBeVisible();
    await page.getByRole("button", { name: "Tarixdan yashirish" }).click();
    await expect(page.getByText("Yozuv tarixingizdan yashirildi")).toBeVisible();
    await expect(page.getByText("Rad etilgan", { exact: true })).toHaveCount(0);
  });

  test("keeps hidden history private between two accounts", async ({ request }) => {
    const alice = await createFixtureSession(request, "shared-alice");
    const bob = await createFixtureSession(request, "shared-bob");
    const outsider = await createFixtureSession(request, "outsider");
    const auth = (token: string) => ({ Authorization: `Bearer ${token}` });

    const aliceBefore = await request.get("/api/transactions", {
      headers: auth(alice.accessToken),
    });
    const bobBefore = await request.get("/api/transactions", {
      headers: auth(bob.accessToken),
    });
    expect(aliceBefore.ok()).toBeTruthy();
    expect(bobBefore.ok()).toBeTruthy();
    const aliceTransactions = await aliceBefore.json();
    const bobTransactions = await bobBefore.json();
    expect(aliceTransactions.map((tx: { id: number }) => tx.id)).toContain(930_000_001);
    expect(bobTransactions.map((tx: { id: number }) => tx.id)).toContain(930_000_001);
    const aliceDashboardBefore = await (
      await request.get("/api/dashboard", { headers: auth(alice.accessToken) })
    ).json();
    const bobDashboardBefore = await (
      await request.get("/api/dashboard", { headers: auth(bob.accessToken) })
    ).json();

    const hide = await request.post("/api/transactions/930000001/hide", {
      headers: auth(alice.accessToken),
    });
    expect(hide.ok()).toBeTruthy();

    const aliceAfter = await (await request.get("/api/transactions", {
      headers: auth(alice.accessToken),
    })).json();
    const bobAfter = await (await request.get("/api/transactions", {
      headers: auth(bob.accessToken),
    })).json();
    expect(aliceAfter.map((tx: { id: number }) => tx.id)).not.toContain(930_000_001);
    expect(bobAfter.map((tx: { id: number }) => tx.id)).toContain(930_000_001);
    expect(bobAfter.map((tx: { id: number }) => tx.id)).toContain(930_000_002);
    const aliceDashboardAfter = await (
      await request.get("/api/dashboard", { headers: auth(alice.accessToken) })
    ).json();
    const bobDashboardAfter = await (
      await request.get("/api/dashboard", { headers: auth(bob.accessToken) })
    ).json();
    expect(aliceDashboardAfter.balances).toEqual(aliceDashboardBefore.balances);
    expect(aliceDashboardAfter.pendingCount).toBe(aliceDashboardBefore.pendingCount);
    expect(
      aliceDashboardAfter.recentTransactions.map((tx: { id: number }) => tx.id),
    ).not.toContain(930_000_001);
    expect(
      bobDashboardAfter.recentTransactions.map((tx: { id: number }) => tx.id),
    ).toContain(930_000_001);
    expect(bobDashboardAfter.balances).toEqual(bobDashboardBefore.balances);

    const outsiderHide = await request.post("/api/transactions/930000001/hide", {
      headers: auth(outsider.accessToken),
    });
    expect(outsiderHide.status()).toBe(403);
  });
});