---
name: Debt-bot locking order
description: Concurrency and PIN-gating principles for telegram-debt-bot
---

Rule: a single lock order exists — pair advisory lock first, then row lock — and only one recalculation path may mutate balances; informational reads take no locks. Per-user security counters are mutated only under a row lock.

**Why:** mixed lock orders and outside-lock checks caused deadlock risk and lost-update races in earlier designs.
**How to apply:** new mutation paths must reuse the central recalculation; SQLite ignores these locks, so guarantees only hold on PostgreSQL.

Rule: PIN gating must cover stale inline keyboards, not just commands — any callback that reveals private financial data re-checks the unlock session.

**Why:** a keyboard rendered before the 5-minute unlock expires otherwise bypasses the PIN entirely.
**How to apply:** when adding a callback that shows balances/history in private chat, run it through the callback PIN guard.
