---
name: Counterparty confirmation
description: Consent rule for debt entries when notification delivery is unavailable.
---

Every debt entry, including “Men berdim”, remains pending until the counterparty explicitly confirms it. A failed or unavailable Telegram delivery must never turn the entry into an automatic confirmation.

**Why:** The creator and the other party need an independent review step; notification availability must not silently weaken that control.

**How to apply:** Keep the pending record available through Telegram `/pending`, web, and mobile confirmation paths. A delivery failure should explain the alternative review paths, not change the transaction status.