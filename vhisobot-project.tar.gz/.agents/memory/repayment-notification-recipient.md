---
name: Repayment notification recipient
description: Which party receives review notifications for repayment requests
---

For a repayment request, the recipient is the person whose debt is being repaid (the transaction debtor); the person entering the repayment is the creditor and sender.

**Why:** Repayment creation records the contact as debtor and sends the review notification to that contact, so authorization and resend actions must follow the recipient role rather than the creator role.

**How to apply:** Gate repayment review notification actions to the debtor who is not the transaction creator, and use the creator’s profile only as the message sender.