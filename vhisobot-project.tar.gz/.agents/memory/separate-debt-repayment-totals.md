---
name: Separate debt and repayment totals
description: The product shows original debts and repayments as distinct totals alongside the remaining balance.
---

Present “Oldim/Berdim” as gross confirmed debt totals and “Qaytardim/Sizga qaytarildi” as separate repayment totals. The remaining balance is a derived ledger result, not a replacement for either total.

**Why:** The creator confirmed this presentation is clearer: it avoids treating repayments as new debt entries and lets users understand both the lending/borrowing history and what remains.

**How to apply:** Keep the same four totals consistent across Telegram, web, and mobile; pending debt requests do not contribute until confirmed, while repayments remain their own ledger class.