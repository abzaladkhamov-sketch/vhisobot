---
name: Transaction status schema changes
description: Durable checks for adding new transaction states across the bot and database.
---

When adding a transaction status, update the application enum, API contract, generated clients, and the persisted status column for existing databases before exercising the live flow.

**Why:** A status can be valid in application code and tests yet still fail in production when an older database column is narrower than the new value.

**How to apply:** Count the literal's characters, make the model and migration capacity explicit, and include a regression that creates, reviews, and settles the new state.