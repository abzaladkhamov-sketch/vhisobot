---
name: Review delivery coverage
description: Durable regression-testing rule for Telegram failures on pending debt and repayment reviews
---

Public delivery-failure coverage should exercise both pending debt and pending repayment entries, verify they remain available for review, and assert the safe `manual_review` state on every read surface included in the API contract.

**Why:** The two review paths share notification infrastructure but have different transaction statuses, so a mapping or query regression can hide one kind while the other still appears healthy.

**How to apply:** Seed representative permanent-failure entries in the API fixture and avoid UI assertions that assume only one matching review warning when multiple review cases are intentionally present.