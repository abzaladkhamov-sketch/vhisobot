---
name: Expo Router test bundling
description: Environment constraint for running Expo Router web bundles in automated browser tests
---

Expo Router's Babel preset intentionally skips app-root environment transforms when the Metro process runs with `NODE_ENV=test`. Start the Expo web server with a development environment for browser tests, while keeping the fixture API in test mode.

**Why:** With `NODE_ENV=test`, the generated `require.context` call retains `process.env.EXPO_ROUTER_APP_ROOT` and Metro rejects it as a non-literal directory.

**How to apply:** Separate the frontend server environment from the fixture API environment whenever Playwright manages an Expo Router web server.