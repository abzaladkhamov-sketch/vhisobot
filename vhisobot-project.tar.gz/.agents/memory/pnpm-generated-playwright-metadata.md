---
name: pnpm-generated Playwright metadata
description: Captured pnpm lockfile shapes for the supported Playwright releases
---

Generated pnpm lockfiles for supported Playwright releases can include the platform-optional `fsevents` package and optional dependency snapshot entries, even though the release gate only validates the root importer version.

**Why:** A hand-copied lockfile excerpt initially omitted those generated entries, which made it differ from fresh pnpm output.

**How to apply:** When refreshing the captured Playwright lockfile fixtures, compare them with fresh `pnpm install --lockfile-only --ignore-scripts --config.auto-install-peers=false` output rather than copying only the root importer section.