---
name: Playwright compatibility isolation
description: How release diagnostics must load an exact Playwright candidate version
---

The release compatibility probes must run from an isolated temporary package that owns the candidate `@playwright/test` dependency. Running `pnpm dlx` from the workspace can still resolve the workspace's installed Playwright when config and test files import the package.

**Why:** The diagnostic goal is to detect framework behavior changes, not only CLI changes. Workspace module resolution can silently make an apparent upgrade test the currently installed version.

**How to apply:** Copy the isolated release fixture into the candidate directory, install the exact version there, and run both the CLI and imports from that directory. Keep the compatibility set documented at the supported-range boundary and the lockfile-resolved version.
