---
name: Directional repayment validation
description: Repayment safety checks must compare gross debt direction totals, not a pair's net balance.
---

Validate repayments against confirmed debt in the opposite direction, using gross totals per direction. Do not compare all confirmed debt and repayments as one net amount.

**Why:** A fully repaid historical debt plus a later debt in the reverse direction is valid. Net-only validation misclassifies the earlier repayment as an overpayment and blocks the new debt’s confirmation.

**How to apply:** Keep the balance as the signed sum of confirmed and repayment entries, but apply repayment-overflow checks separately for each direction in every ledger implementation.