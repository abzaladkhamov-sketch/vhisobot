---
name: Mobile browser flow assertions
description: Expo React Native Web behavior that affects end-to-end assertions.
---

When asserting a value after an Expo Router navigation on React Native Web, duplicate text nodes can remain in the accessibility tree while one is hidden.

**Why:** A strict locator or the first matching node can target an unmounted route copy and time out even though the visible screen is correct.

**How to apply:** For duplicated post-navigation values, assert with a tolerant matcher and select the last matching locator when that corresponds to the mounted list content.