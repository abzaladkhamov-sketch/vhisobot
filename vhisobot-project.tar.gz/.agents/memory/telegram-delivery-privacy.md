---
name: Telegram delivery privacy
description: The API contract for notification delivery state and internal failure details
---

Client-facing transaction responses must normalize stored Telegram delivery outcomes to `pending`, `sent`, or `manual_review`; raw failure states and notification error text remain server-side.

**Why:** Notification diagnostics can reveal internal operational details and are not part of the transaction contract, while users still need a safe indication that manual review is required.

**How to apply:** Keep the mapper at the API boundary, model raw failure data in server fixtures, and assert that list, dashboard, create, and decision responses omit raw statuses and error fields.