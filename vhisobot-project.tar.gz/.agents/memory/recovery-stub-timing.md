---
name: Recovery stub timing
description: How to model an external service recovering during concurrent delivery tests
---

When a test stub simulates an outage followed by recovery, capture the response mode at request start and use that captured value after any artificial delay.

**Why:** A request that began while the dependency was unavailable must remain a failed request. Choosing the response after the delay lets a recovery toggle turn in-flight outage requests into successes, producing flaky counts and hiding the real retry boundary.

**How to apply:** Keep the outage/recovery transition separate from the next scheduler invocation, and count post-transition successful requests independently from the initial failed race.