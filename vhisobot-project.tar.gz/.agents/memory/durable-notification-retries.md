---
name: Cross-service notification retries
description: Durable Telegram delivery behavior when the bot and API share a database
---

Pending Telegram review requests must be persisted before delivery, claimed atomically, and checked against the current transaction status before every retry. Delivery failures stay attached to the pending transaction until success, terminal decision, or bounded exhaustion.

**Why:** The API and Telegram bot are separate processes, so in-memory backoff loses a request during a restart and independent senders can duplicate work.

**How to apply:** Keep queue claims and attempt deadlines in the shared database; use a bounded retry policy, remove work on confirmation/rejection, and leave the transaction visible to `/pending`, web, and mobile review paths after permanent delivery failure.

When a notification status parameter is used both in a `varchar` assignment and a comparison, cast it explicitly to `varchar` at each use.

**Why:** PostgreSQL can infer the same untyped parameter as `text` in the comparison and `character varying` in the assignment, raising 42P08 only on the real database path.

**How to apply:** Check shared status parameters in notification queue updates whenever a route's real PostgreSQL path returns a generic 500.

Restart recovery tests should use separate operating-system processes for the outage pass and the recovery pass, with the due time advanced explicitly between them.

**Why:** Re-importing or re-calling scheduler code in one process cannot prove that retry metadata is sufficient to recover after the bot disappears.

**How to apply:** Let the first process finish its failed claim, stop it before toggling availability, then launch a fresh process against the same database row and assert one successful send plus no duplicate on a later pass.