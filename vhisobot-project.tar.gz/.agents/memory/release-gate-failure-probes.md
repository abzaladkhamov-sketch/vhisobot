---
name: Release-gate failure probes
description: Constraints for deterministic Playwright failure checks in the release gate
---

Deterministic Playwright failure probes should run from a separate test project and use a self-contained command that installs the required browser.

**Why:** `RELEASE_E2E_COMMAND` replaces the release command wholesale, so an override also bypasses the default browser-install step; putting the probe in the normal test directories can also make it run during the regular browser suite.

**How to apply:** Keep failure-only tests outside the normal project match patterns, invoke them through a dedicated package script, and include browser installation in that script.

Failure attribution probes should emit a project-owned marker, and release diagnostics should classify the failure from that marker rather than framework-generated wording.

**Why:** Playwright can change the text it uses to describe a failed `webServer` startup across upgrades, while the fixture’s own output is stable.

**How to apply:** Match the marker emitted by the deterministic setup fixture; keep third-party error text only as incidental diagnostic output.

Failure diagnostics must be best-effort: capture the command's nonzero status before collecting logs, guard every diagnostic command, and exit with the captured status afterward.

**Why:** A failed diagnostic can otherwise replace the real release-gate failure, obscuring the cause or changing the status reported to CI.

**How to apply:** Use distinct failure variables for each wrapper layer, tolerate diagnostic/log-copy failures, and test with a non-1 fixture status.

Producer-side mobile diagnostics probes should inject failure only through an explicit test environment and require the wrapper's diagnostics directory; ordinary PostgreSQL suites should remain usable without that directory.

**Why:** The real API/Expo probe needs live server processes and captured output, but forcing it into every database test run would add an unnecessary failure mode outside the release gate.

**How to apply:** Run the controlled probe with `MOBILE_TRANSACTION_DIAGNOSTICS_DIR`, assert real server startup markers, and skip it when the release-only capture environment is absent.