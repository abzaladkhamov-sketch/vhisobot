---
name: Telegram test client transport
description: HTTP test stubs used with aiogram delivery clients
---

Aiogram's default HTTP session sends Telegram methods as multipart form data, while the API notification client sends JSON.

**Why:** A stub that assumes every Telegram request is JSON can reject valid bot deliveries and turn a passing claim race into a false retry failure.

**How to apply:** When testing both services against one Telegram endpoint, accept both request content types or use a small JSON bot adapter while keeping the scheduler delivery path real.