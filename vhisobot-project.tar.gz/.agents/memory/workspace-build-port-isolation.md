---
name: Workspace build port isolation
description: Build-time environment defaults and local service port collisions in the multi-artifact workspace.
---

Standalone workspace builds need safe defaults for configuration that managed workflows normally inject, and auxiliary build servers must use a configurable port that cannot collide with another artifact's development server. Release browser checks must also be serialized at their shared package-script entry point.

**Why:** The root build runs while artifact workflows can remain active. A workflow-only Vite environment caused package builds to fail, and a hardcoded Expo Metro port collided with the mockup server.

**How to apply:** Preserve workflow-provided values when present, use artifact-specific defaults for standalone Vite builds, route all internal Metro build requests through a configurable non-shared port, and keep the release lock around both workflow-triggered and build-triggered checks.