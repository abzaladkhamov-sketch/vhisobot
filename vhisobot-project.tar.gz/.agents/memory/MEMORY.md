# Memory index

- [Debt-bot locking order](debt-bot-locking.md) — one lock order (pair advisory → row), one mutation path; PIN gating must also cover stale inline keyboards, not just commands.
- [Counterparty confirmation](counterparty-confirmation.md) — debt entries stay pending until the other party reviews them, even when Telegram delivery fails.
- [Directional repayment validation](directional-repayment-validation.md) — repayment validity uses gross totals by direction, never just the pair’s net balance.
- [Separate debt and repayment totals](separate-debt-repayment-totals.md) — show gross confirmed debt and repayments separately, with the remaining balance as the derived result.
- [Expo Router test bundling](expo-router-test-bundling.md) — Expo Router's app-root Babel transform is skipped under NODE_ENV=test; browser bundles need a development-mode Expo process.
- [Workspace build port isolation](workspace-build-port-isolation.md) — standalone package builds must not assume workflow-only env or hardcode a port shared by another artifact.
- [Release-gate failure probes](release-gate-failure-probes.md) — override commands replace browser installation, so isolated Playwright failure probes must install their own browser.
- [Playwright compatibility isolation](playwright-compatibility.md) — candidate probes need a temporary package so CLI and imported test APIs use the same exact version.
- [Generated Playwright lockfiles](pnpm-generated-playwright-metadata.md) — pnpm captures optional platform dependencies alongside the root Playwright importer.
- [Transaction status schema changes](transaction-status-schema.md) — new ledger statuses require both enum coverage and an existing-database column-width migration.
- [Cross-service notification retries](durable-notification-retries.md) — Telegram delivery retries need DB-backed claims and terminal-state checks shared by bot and API.
- [Telegram test client transport](telegram-test-client.md) — aiogram bot requests use multipart form data, while API notification requests use JSON.
- [Telegram delivery privacy](telegram-delivery-privacy.md) — client responses normalize delivery outcomes and never expose raw failure states or notification diagnostics.
- [Review delivery coverage](review-delivery-coverage.md) — notification failure regressions should cover both debt and repayment review entries across public read surfaces.
- [Repayment notification recipient](repayment-notification-recipient.md) — repayment review notifications go to the debtor being repaid, not the repayment creator.
- [Mobile browser flow assertions](mobile-browser-flow-assertions.md) — Expo Web can leave hidden duplicate text nodes after navigation; target the mounted copy deliberately.
- [Recovery stub timing](recovery-stub-timing.md) — outage stubs must snapshot availability when a request starts, or in-flight failures can become false successes.
