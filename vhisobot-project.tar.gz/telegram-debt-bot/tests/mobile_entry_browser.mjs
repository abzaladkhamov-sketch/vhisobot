import assert from "node:assert/strict";
import { chromium, devices } from "@playwright/test";

const mobileUrl = process.env.MOBILE_URL;
const sessionToken = process.env.SESSION_TOKEN;
const contactDisplayName = process.env.CONTACT_DISPLAY_NAME;
const expectedAmount = Number(process.env.EXPECTED_AMOUNT);
const controlledFailure = process.env.MOBILE_TRANSACTION_TEST_FAILURE;

for (const [name, value] of Object.entries({
  MOBILE_URL: mobileUrl,
  SESSION_TOKEN: sessionToken,
  CONTACT_DISPLAY_NAME: contactDisplayName,
})) {
  if (!value) throw new Error(`${name} must be configured`);
}
assert(Number.isSafeInteger(expectedAmount) && expectedAmount > 0);

const browser = await chromium.launch();
try {
  const context = await browser.newContext(devices["Pixel 7"]);
  await context.addInitScript(
    ({ token }) => window.localStorage.setItem("qarz_hisobi_session", token),
    { token: sessionToken },
  );
  const page = await context.newPage();

  await page.goto(`${mobileUrl}/transactions`);
  await page.getByTestId("transactions-add").click();
  await page.getByText("Qarz kiritish", { exact: true }).last().waitFor();
  await page.getByText(contactDisplayName, { exact: true }).last().click();
  await page.getByTestId("entry-amount").fill(String(expectedAmount));
  await page.getByText("Yuborishdan oldingi xulosa", { exact: true }).waitFor();

  const createdResponsePromise = page.waitForResponse(
    (response) =>
      response.request().method() === "POST" &&
      new URL(response.url()).pathname === "/api/transactions" &&
      response.status() === 201,
  );
  const listedResponsePromise = page.waitForResponse(async (response) => {
    if (
      response.request().method() !== "GET" ||
      new URL(response.url()).pathname !== "/api/transactions" ||
      response.status() !== 200
    ) {
      return false;
    }
    const transactions = await response.json();
    return transactions.some(
      (transaction) =>
        transaction.amount === expectedAmount &&
        transaction.status === "pending" &&
        transaction.deliveryStatus === "pending",
    );
  });

  await page.getByTestId("entry-submit").click();
  const created = await (await createdResponsePromise).json();
  assert.equal(created.status, "pending");
  assert.equal(created.deliveryStatus, "pending");
  assert.equal(created.amount, expectedAmount);
  assert.equal(created.currency, "UZS");
  assert(!JSON.stringify(created).includes("last_error"));
  assert(!JSON.stringify(created).includes("permanent_failure"));

  await page.waitForURL(/\/transactions\?result=debt-sent/);
  await listedResponsePromise;
  await page.getByText("Qarz so‘rovi yuborildi.", { exact: false }).waitFor();
  await page.getByText(contactDisplayName, { exact: true }).last().waitFor();
  const formattedAmount = expectedAmount
    .toLocaleString("uz-UZ")
    .replace(/\D+/g, "\\D+");
  await page.getByText(new RegExp(`^${formattedAmount}\\s+UZS$`)).last().waitFor();
  await page.getByText("Tasdiqlash kutilmoqda", { exact: true }).last().waitFor();
  if (controlledFailure) {
    throw new Error(controlledFailure);
  }
} finally {
  await browser.close();
}