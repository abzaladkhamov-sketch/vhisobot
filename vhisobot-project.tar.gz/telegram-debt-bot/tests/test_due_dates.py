"""Unit tests for due-date parsing, reminder classification, scheduling."""

from datetime import date, datetime

import pytest

from scheduler import classify_due, report_due_today, seconds_until_next_run
from services import parse_due_date
from timezone import UZBEKISTAN_TZ

TODAY = date(2026, 8, 14)


def test_parse_full_date():
    assert parse_due_date("20.08.2026", TODAY) == date(2026, 8, 20)
    assert parse_due_date("2026-08-20", TODAY) == date(2026, 8, 20)
    assert parse_due_date("20/08/2026", TODAY) == date(2026, 8, 20)


def test_parse_short_date_rolls_to_next_year():
    assert parse_due_date("20.08", TODAY) == date(2026, 8, 20)
    # Already past this year -> next year.
    assert parse_due_date("01.01", TODAY) == date(2027, 1, 1)


def test_parse_rejects_past_and_garbage():
    with pytest.raises(ValueError):
        parse_due_date("13.08.2026", TODAY)
    with pytest.raises(ValueError):
        parse_due_date("abc", TODAY)
    with pytest.raises(ValueError):
        parse_due_date("32.13.2026", TODAY)


def test_classify_due():
    assert classify_due(date(2026, 8, 15), TODAY) == "due_soon"
    assert classify_due(date(2026, 8, 14), TODAY) == "due_today"
    assert classify_due(date(2026, 8, 10), TODAY) == "overdue"
    assert classify_due(date(2026, 8, 20), TODAY) is None


def test_report_due_today():
    monday = date(2026, 8, 17)
    first = date(2026, 9, 1)
    assert report_due_today("weekly", monday)
    assert not report_due_today("weekly", TODAY)  # Friday
    assert report_due_today("monthly", first)
    assert not report_due_today("monthly", TODAY)
    assert not report_due_today("off", monday)


def test_seconds_until_next_run():
    before = datetime(2026, 8, 14, 8, 0, tzinfo=UZBEKISTAN_TZ)
    after = datetime(2026, 8, 14, 10, 0, tzinfo=UZBEKISTAN_TZ)
    assert seconds_until_next_run(before) == 3600
    assert seconds_until_next_run(after) == 23 * 3600
