"""Scheduler tests: due-date reminders and periodic balance reports.

Covers with a mock Bot over in-memory SQLite:
- pure helpers (classify_due, report_due_today, seconds_until_next_run)
- reminders go to both the debtor and the creditor with the right text
- per-day dedupe: a second run on the same day sends nothing
- settled (fully repaid) debts produce no reminders
- delivery failures (blocked user) do not crash the run and are retried
  on the next run because the dedupe row is rolled back
- weekly/monthly reports fire only on their day, are claimed once per
  day, and survive delivery failures
"""

import asyncio
from datetime import date, datetime, timedelta

import pytest
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

import scheduler
from models import (
    Base,
    PendingNotification,
    PendingNotificationStatus,
    ReminderLog,
    ReportFrequency,
    TransactionDirection,
    TransactionStatus,
    User,
)
from services import create_transaction, link_users, set_transaction_status


class FakeBot:
    """Records outgoing messages; can simulate per-chat delivery failures."""

    def __init__(self, fail_for=()):
        self.sent = []  # (chat_id, text)
        self.fail_for = set(fail_for)  # telegram ids that raise on send

    async def send_message(self, chat_id, text, **kwargs):
        if chat_id in self.fail_for:
            raise RuntimeError("Forbidden: bot was blocked by the user")
        self.sent.append((chat_id, text))


@pytest.fixture()
def db():
    loop = asyncio.new_event_loop()
    engine = create_async_engine("sqlite+aiosqlite://")

    async def setup():
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
        return async_sessionmaker(engine, expire_on_commit=False)

    factory = loop.run_until_complete(setup())
    yield loop.run_until_complete, factory
    loop.run_until_complete(engine.dispose())
    loop.close()


async def _make_users(session):
    alice = User(telegram_id=111, username="alice", first_name="Alice")
    bob = User(telegram_id=222, username="bob", first_name="Bob")
    session.add_all([alice, bob])
    await session.flush()
    await link_users(session, alice, bob)
    await session.commit()
    return alice, bob


async def _debt(session, debtor, creditor, amount=50000, due_date=None):
    """Confirmed debt: `debtor` owes `creditor` `amount`."""
    tx = await create_transaction(
        session,
        entered_by=debtor,
        other=creditor,
        direction=TransactionDirection.RECEIVED,
        amount=amount,
        status=TransactionStatus.CONFIRMED,
        due_date=due_date,
    )
    await session.commit()
    return tx


# ----------------------------------------------------------- pure helpers


def test_classify_due():
    today = date(2026, 8, 14)
    assert scheduler.classify_due(today + timedelta(days=1), today) == "due_soon"
    assert scheduler.classify_due(today, today) == "due_today"
    assert scheduler.classify_due(today - timedelta(days=1), today) == "overdue"
    assert scheduler.classify_due(today - timedelta(days=30), today) == "overdue"
    assert scheduler.classify_due(today + timedelta(days=2), today) is None


def test_report_due_today():
    monday = date(2026, 8, 10)
    first = date(2026, 8, 1)
    other = date(2026, 8, 14)  # Friday, not the 1st
    assert scheduler.report_due_today(ReportFrequency.WEEKLY, monday)
    assert not scheduler.report_due_today(ReportFrequency.WEEKLY, other)
    assert scheduler.report_due_today(ReportFrequency.MONTHLY, first)
    assert not scheduler.report_due_today(ReportFrequency.MONTHLY, other)
    assert not scheduler.report_due_today(ReportFrequency.OFF, monday)


def test_seconds_until_next_run():
    before = datetime(2026, 8, 14, 8, 0, 0)
    after = datetime(2026, 8, 14, 10, 0, 0)
    assert scheduler.seconds_until_next_run(before) == 3600
    # Past today's RUN_HOUR — next run is tomorrow.
    assert scheduler.seconds_until_next_run(after) == 23 * 3600


# ------------------------------------------------------ due-date reminders


def test_reminders_sent_to_both_sides(db):
    run, factory = db
    today = date(2026, 8, 14)

    async def scenario():
        async with factory() as session:
            alice, bob = await _make_users(session)
            await _debt(session, alice, bob, due_date=today)

        bot = FakeBot()
        await scheduler.process_due_reminders(bot, factory, today)

        assert sorted(chat_id for chat_id, _ in bot.sent) == [111, 222]
        debtor_text = next(t for c, t in bot.sent if c == 111)
        creditor_text = next(t for c, t in bot.sent if c == 222)
        assert "bugun" in debtor_text
        assert "@bob" in debtor_text and "qaytarishingiz kerak" in debtor_text
        assert "@alice" in creditor_text and "qaytarishi kerak" in creditor_text
        assert "50 000" in debtor_text.replace("\xa0", " ") or "50000" in debtor_text or "50" in debtor_text

    run(scenario())


def test_overdue_and_due_soon_texts(db):
    run, factory = db
    today = date(2026, 8, 14)

    async def scenario():
        async with factory() as session:
            alice, bob = await _make_users(session)
            carol = User(telegram_id=333, username="carol", first_name="Carol")
            session.add(carol)
            await session.flush()
            await link_users(session, alice, carol)
            await session.commit()
            await _debt(session, alice, bob, due_date=today - timedelta(days=3))
            await _debt(session, carol, alice, due_date=today + timedelta(days=1))

        bot = FakeBot()
        await scheduler.process_due_reminders(bot, factory, today)

        # 2 transactions x 2 recipients.
        assert len(bot.sent) == 4
        assert any("Muddati o'tgan" in t for _, t in bot.sent)
        assert any("ertaga" in t for _, t in bot.sent)

    run(scenario())


def test_reminder_deduped_within_a_day(db):
    run, factory = db
    today = date(2026, 8, 14)

    async def scenario():
        async with factory() as session:
            alice, bob = await _make_users(session)
            await _debt(session, alice, bob, due_date=today)

        bot = FakeBot()
        await scheduler.process_due_reminders(bot, factory, today)
        assert len(bot.sent) == 2

        # Same day, second run: nothing new.
        await scheduler.process_due_reminders(bot, factory, today)
        assert len(bot.sent) == 2

        # Next day the debt is overdue — a different kind, so it fires again.
        await scheduler.process_due_reminders(
            bot, factory, today + timedelta(days=1)
        )
        assert len(bot.sent) == 4

    run(scenario())


def test_settled_debt_gets_no_reminder(db):
    run, factory = db
    today = date(2026, 8, 14)

    async def scenario():
        async with factory() as session:
            alice, bob = await _make_users(session)
            await _debt(session, alice, bob, amount=50000, due_date=today)
            # Alice repays in full — net debt becomes zero.
            await create_transaction(
                session,
                entered_by=alice,
                other=bob,
                direction=TransactionDirection.GIVEN,
                amount=50000,
                status=TransactionStatus.REPAYMENT,
            )
            await session.commit()

        bot = FakeBot()
        await scheduler.process_due_reminders(bot, factory, today)
        assert bot.sent == []

    run(scenario())


def test_partial_repayment_reminds_outstanding_amount(db):
    run, factory = db
    today = date(2026, 8, 14)

    async def scenario():
        async with factory() as session:
            alice, bob = await _make_users(session)
            await _debt(session, alice, bob, amount=50000, due_date=today)
            await create_transaction(
                session,
                entered_by=alice,
                other=bob,
                direction=TransactionDirection.GIVEN,
                amount=30000,
                status=TransactionStatus.REPAYMENT,
            )
            await session.commit()

        bot = FakeBot()
        await scheduler.process_due_reminders(bot, factory, today)
        assert len(bot.sent) == 2
        # Reminder shows the unpaid 20 000, not the original 50 000.
        for _, text in bot.sent:
            assert "20 000 UZS" in text
            assert "50 000 UZS" not in text

    run(scenario())


def test_blocked_user_does_not_break_run_and_is_retried(db):
    run, factory = db
    today = date(2026, 8, 14)

    async def scenario():
        async with factory() as session:
            alice, bob = await _make_users(session)
            await _debt(session, alice, bob, due_date=today)

        # Debtor (111) blocked the bot; creditor still gets their message.
        bot = FakeBot(fail_for={111})
        await scheduler.process_due_reminders(bot, factory, today)
        assert [c for c, _ in bot.sent] == [222]

        # The failed send must NOT be marked as sent — only the
        # creditor's dedupe row exists.
        async with factory() as session:
            kinds = (
                await session.execute(select(ReminderLog.kind))
            ).scalars().all()
        assert kinds == ["due_today:creditor"]

        # Once the user unblocks the bot, the same-day retry delivers.
        bot.fail_for.clear()
        await scheduler.process_due_reminders(bot, factory, today)
        assert sorted(c for c, _ in bot.sent) == [111, 222]

    run(scenario())


def test_pending_notification_survives_failed_attempt_and_recovers_after_restart(db):
    run, factory = db

    async def scenario():
        async with factory() as session:
            alice, bob = await _make_users(session)
            transaction = await create_transaction(
                session,
                entered_by=alice,
                other=bob,
                direction=TransactionDirection.RECEIVED,
                amount=50000,
                status=TransactionStatus.PENDING,
            )
            await session.commit()
            queued = (
                await session.execute(
                    select(PendingNotification).where(
                        PendingNotification.transaction_id == transaction.id
                    )
                )
            ).scalar_one()
            assert queued.attempt_count == 0
            assert queued.status == PendingNotificationStatus.PENDING

        failed_bot = FakeBot(fail_for={222})
        await scheduler.process_pending_notifications(failed_bot, factory)
        async with factory() as session:
            queued = await session.get(PendingNotification, queued.id)
            assert queued is not None
            assert queued.attempt_count == 1
            assert queued.status == PendingNotificationStatus.PENDING

            # A new process can pick up the same durable row once it is due.
            queued.next_attempt_at = scheduler.now_uzbekistan() - timedelta(seconds=1)
            await session.commit()

        restarted_bot = FakeBot()
        await scheduler.process_pending_notifications(restarted_bot, factory)
        assert [chat_id for chat_id, _ in restarted_bot.sent] == [222]
        async with factory() as session:
            queued = (
                await session.execute(
                    select(PendingNotification).where(
                        PendingNotification.transaction_id == transaction.id
                    )
                )
            ).scalar_one()
            assert queued is not None
            assert queued.status == PendingNotificationStatus.SENT

    run(scenario())


def test_pending_notification_becomes_permanent_after_bounded_attempts(db):
    run, factory = db

    async def scenario():
        async with factory() as session:
            alice, bob = await _make_users(session)
            transaction = await create_transaction(
                session,
                entered_by=alice,
                other=bob,
                direction=TransactionDirection.RECEIVED,
                amount=50000,
                status=TransactionStatus.PENDING,
            )
            await session.commit()
            queued = (
                await session.execute(
                    select(PendingNotification).where(
                        PendingNotification.transaction_id == transaction.id
                    )
                )
            ).scalar_one()
            queued.attempt_count = scheduler.PENDING_NOTIFICATION_MAX_ATTEMPTS
            queued.next_attempt_at = scheduler.now_uzbekistan() - timedelta(seconds=1)
            await session.commit()

        bot = FakeBot()
        await scheduler.process_pending_notifications(bot, factory)
        assert bot.sent == []
        async with factory() as session:
            queued = (
                await session.execute(
                    select(PendingNotification).where(
                        PendingNotification.transaction_id == transaction.id
                    )
                )
            ).scalar_one()
            assert queued.status == PendingNotificationStatus.PERMANENT_FAILURE

    run(scenario())


def test_pending_notification_is_cancelled_when_transaction_is_decided(db):
    run, factory = db

    async def scenario():
        async with factory() as session:
            alice, bob = await _make_users(session)
            transaction = await create_transaction(
                session,
                entered_by=alice,
                other=bob,
                direction=TransactionDirection.RECEIVED,
                amount=50000,
                status=TransactionStatus.PENDING,
            )
            await set_transaction_status(
                session,
                transaction,
                TransactionStatus.REJECTED,
                expected_status=TransactionStatus.PENDING,
            )
            await session.commit()

        bot = FakeBot()
        await scheduler.process_pending_notifications(bot, factory)
        assert bot.sent == []
        async with factory() as session:
            assert await session.get(PendingNotification, transaction.id) is None

    run(scenario())


# ------------------------------------------------------- periodic reports


def test_weekly_report_sent_on_monday_only(db):
    run, factory = db
    monday = date(2026, 8, 10)
    tuesday = date(2026, 8, 11)

    async def scenario():
        async with factory() as session:
            alice, bob = await _make_users(session)
            alice.report_frequency = ReportFrequency.WEEKLY
            await session.commit()
            await _debt(session, alice, bob, amount=70000)

        bot = FakeBot()
        await scheduler.process_periodic_reports(bot, factory, tuesday)
        assert bot.sent == []

        await scheduler.process_periodic_reports(bot, factory, monday)
        assert len(bot.sent) == 1
        chat_id, text = bot.sent[0]
        assert chat_id == 111
        assert "Haftalik hisobot" in text
        assert "@bob" in text and "qarzdorsiz" in text

    run(scenario())


def test_monthly_report_on_first_and_empty_balances_message(db):
    run, factory = db
    first = date(2026, 8, 1)

    async def scenario():
        async with factory() as session:
            alice, _ = await _make_users(session)
            alice.report_frequency = ReportFrequency.MONTHLY
            await session.commit()

        bot = FakeBot()
        await scheduler.process_periodic_reports(bot, factory, first)
        assert len(bot.sent) == 1
        _, text = bot.sent[0]
        assert "Oylik hisobot" in text
        assert "Faol qarzlar yo'q" in text

    run(scenario())


def test_report_claimed_once_per_day(db):
    run, factory = db
    monday = date(2026, 8, 10)

    async def scenario():
        async with factory() as session:
            alice, _ = await _make_users(session)
            alice.report_frequency = ReportFrequency.WEEKLY
            await session.commit()

        bot = FakeBot()
        await scheduler.process_periodic_reports(bot, factory, monday)
        await scheduler.process_periodic_reports(bot, factory, monday)
        assert len(bot.sent) == 1

    run(scenario())


def test_report_delivery_failure_does_not_crash(db):
    run, factory = db
    monday = date(2026, 8, 10)

    async def scenario():
        async with factory() as session:
            alice, bob = await _make_users(session)
            alice.report_frequency = ReportFrequency.WEEKLY
            bob.report_frequency = ReportFrequency.WEEKLY
            await session.commit()

        # Alice blocked the bot; Bob must still get his report.
        bot = FakeBot(fail_for={111})
        await scheduler.process_periodic_reports(bot, factory, monday)
        assert [c for c, _ in bot.sent] == [222]

        # The day's claim was consumed even though delivery failed, so a
        # same-day rerun sends nothing extra (documented current behavior:
        # reports are best-effort, not retried within the day).
        async with factory() as session:
            alice_db = await session.get(User, 1)
            assert alice_db.report_last_sent == monday
        bot.fail_for.clear()
        await scheduler.process_periodic_reports(bot, factory, monday)
        assert [c for c, _ in bot.sent] == [222]

    run(scenario())


def test_off_frequency_users_never_get_reports(db):
    run, factory = db
    monday = date(2026, 8, 10)

    async def scenario():
        async with factory() as session:
            await _make_users(session)  # both default to OFF

        bot = FakeBot()
        await scheduler.process_periodic_reports(bot, factory, monday)
        assert bot.sent == []

    run(scenario())


# ------------------------------------------------------- run_daily_checks


def test_run_daily_checks_survives_processing_errors(db, monkeypatch):
    run, factory = db

    async def boom(*args, **kwargs):
        raise RuntimeError("db exploded")

    monkeypatch.setattr(scheduler, "process_due_reminders", boom)
    monkeypatch.setattr(scheduler, "process_periodic_reports", boom)

    async def scenario():
        # Must not raise despite both sub-processes failing.
        await scheduler.run_daily_checks(FakeBot(), factory)

    run(scenario())
