"""Tests for PIN hashing and the unlock/lockout gate."""

import pin as pin_module
from pin import PinGate, hash_pin, is_valid_pin, verify_pin


def test_pin_validation():
    assert is_valid_pin("1234")
    assert is_valid_pin("0000")
    assert not is_valid_pin("123")
    assert not is_valid_pin("12345")
    assert not is_valid_pin("12a4")
    assert not is_valid_pin("")


def test_hash_and_verify():
    stored = hash_pin("1234")
    assert "1234" not in stored
    assert stored.startswith("pbkdf2_sha256$")
    assert verify_pin("1234", stored)
    assert not verify_pin("1235", stored)
    # Different salts produce different hashes for the same PIN.
    assert hash_pin("1234") != stored


def test_verify_rejects_garbage_stored_values():
    assert not verify_pin("1234", "")
    assert not verify_pin("1234", "plaintext")
    assert not verify_pin("1234", "md5$1$00$abc")


class FakeClock:
    def __init__(self):
        self.now = 1000.0

    def __call__(self):
        return self.now


def test_unlock_expires_after_five_minutes():
    clock = FakeClock()
    gate = PinGate(clock=clock)
    assert not gate.is_unlocked(1)
    gate.unlock(1)
    assert gate.is_unlocked(1)
    clock.now += pin_module.UNLOCK_SECONDS - 1
    assert gate.is_unlocked(1)
    clock.now += 2
    assert not gate.is_unlocked(1)


def test_lock_clears_session_and_users_are_independent():
    gate = PinGate(clock=FakeClock())
    gate.unlock(5)
    assert not gate.is_unlocked(6)
    gate.lock(5)
    assert not gate.is_unlocked(5)


class FakeUser:
    """Stands in for the SQLAlchemy User row in pure-logic tests."""

    def __init__(self):
        self.pin_failed_attempts = 0
        self.pin_locked_until = None


def test_three_failures_lock_for_a_minute():
    from datetime import datetime, timedelta, timezone

    user = FakeUser()
    now = datetime(2026, 8, 14, 9, 0, tzinfo=timezone.utc)
    assert pin_module.register_failure(user, now) == 2
    assert pin_module.register_failure(user, now) == 1
    assert pin_module.lockout_remaining(user.pin_locked_until, now) == 0
    assert pin_module.register_failure(user, now) == 0
    assert (
        pin_module.lockout_remaining(user.pin_locked_until, now)
        == pin_module.LOCKOUT_SECONDS
    )
    # Half a minute later, half the lockout remains.
    later = now + timedelta(seconds=30)
    assert pin_module.lockout_remaining(user.pin_locked_until, later) == 30
    # After the minute the lockout expires and counting starts fresh.
    after = now + timedelta(seconds=61)
    assert pin_module.lockout_remaining(user.pin_locked_until, after) == 0
    assert user.pin_failed_attempts == 0


def test_clear_failures_resets_counter_and_lockout():
    from datetime import datetime, timezone

    user = FakeUser()
    now = datetime(2026, 8, 14, 9, 0, tzinfo=timezone.utc)
    pin_module.register_failure(user, now)
    pin_module.register_failure(user, now)
    pin_module.register_failure(user, now)
    pin_module.clear_failures(user)
    assert user.pin_failed_attempts == 0
    assert user.pin_locked_until is None


def test_lockout_remaining_handles_naive_datetimes():
    """SQLite returns naive datetimes; they must compare against aware now."""
    from datetime import datetime, timedelta, timezone

    tz = timezone(timedelta(hours=5))
    now = datetime(2026, 8, 14, 9, 0, tzinfo=tz)
    naive_deadline = datetime(2026, 8, 14, 9, 0, 45)  # same zone, naive
    assert pin_module.lockout_remaining(naive_deadline, now) == 45
