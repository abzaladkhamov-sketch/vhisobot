"""Regression: stale keyboards must not bypass an expired PIN session.

A user unlocks /history, gets the contact keyboard, waits past the
5-minute unlock, then taps a contact — the callback must demand the PIN
again instead of showing transactions.
"""

import asyncio

import pytest
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

import handlers
import pin as pin_module
from models import Base, User
from pin import hash_pin


class FakeChat:
    type = "private"


class FakeMessage:
    def __init__(self):
        self.chat = FakeChat()
        self.answers = []
        self.edits = []

    async def answer(self, text, **kwargs):
        self.answers.append(text)

    async def edit_text(self, text, **kwargs):
        self.edits.append(text)


class FakeFrom:
    def __init__(self, telegram_id):
        self.id = telegram_id


class FakeCallback:
    def __init__(self, telegram_id, data):
        self.from_user = FakeFrom(telegram_id)
        self.data = data
        self.message = FakeMessage()
        self.answered = []

    async def answer(self, text=None, **kwargs):
        self.answered.append(text)


class FakeState:
    def __init__(self):
        self.state = None
        self.data = {}

    async def set_state(self, state):
        self.state = state

    async def update_data(self, **kwargs):
        self.data.update(kwargs)

    async def get_data(self):
        return dict(self.data)

    async def clear(self):
        self.state = None
        self.data = {}


@pytest.fixture()
def db():
    loop = asyncio.new_event_loop()
    engine = create_async_engine("sqlite+aiosqlite://")

    async def setup():
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
        return async_sessionmaker(engine, expire_on_commit=False)

    factory = loop.run_until_complete(setup())
    yield loop.run_until_complete, factory
    loop.run_until_complete(engine.dispose())
    loop.close()


def test_expired_session_history_callback_denied(db):
    run, factory = db

    async def scenario():
        async with factory() as session:
            alice = User(
                telegram_id=111, first_name="Alice", pin_hash=hash_pin("1234")
            )
            bob = User(telegram_id=222, first_name="Bob")
            session.add_all([alice, bob])
            await session.commit()

            # Unlock session has expired (or never existed).
            pin_module.pin_gate.lock(alice.id)

            callback = FakeCallback(111, f"history_contact:{bob.id}")
            state = FakeState()
            await handlers.history_contact_callback(callback, state, session)

            # No history was rendered; the PIN prompt was issued instead.
            assert callback.message.edits == []
            assert any("PIN" in text for text in callback.message.answers)
            assert state.state is handlers.PinStates.waiting_for_unlock
            assert state.data.get("pin_pending") == "history"

    run(scenario())


def test_unlocked_session_history_callback_allowed(db):
    run, factory = db

    async def scenario():
        async with factory() as session:
            alice = User(
                telegram_id=333, first_name="Alice", pin_hash=hash_pin("1234")
            )
            bob = User(telegram_id=444, first_name="Bob")
            session.add_all([alice, bob])
            await session.commit()

            pin_module.pin_gate.unlock(alice.id)
            try:
                callback = FakeCallback(333, f"history_contact:{bob.id}")
                state = FakeState()
                await handlers.history_contact_callback(callback, state, session)
                # History (empty) was rendered — no PIN prompt.
                assert len(callback.message.edits) == 1
                assert state.state is None
            finally:
                pin_module.pin_gate.lock(alice.id)

    run(scenario())
