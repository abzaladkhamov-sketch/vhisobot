"""Persistence-level tests for status, repayment, and edit/delete invariants."""

import asyncio

import pytest
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

from models import Base, TransactionDirection, TransactionStatus, User
from services import (
    create_transaction,
    can_hide_transaction,
    delete_transaction,
    get_balance_breakdown,
    get_debt_between,
    get_pair_transactions,
    hide_transaction_for_user,
    set_transaction_status,
    update_transaction,
)


@pytest.fixture()
def run():
    loop = asyncio.new_event_loop()

    cleanups = []

    def runner(coro):
        return loop.run_until_complete(coro)

    runner.add_cleanup = cleanups.append
    yield runner
    for cleanup in reversed(cleanups):
        loop.run_until_complete(cleanup())
    loop.close()


async def _make_session(run):
    engine = create_async_engine("sqlite+aiosqlite://")
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    factory = async_sessionmaker(engine, expire_on_commit=False)
    session = factory()

    async def cleanup():
        await session.close()
        await engine.dispose()

    run.add_cleanup(cleanup)
    alice = User(telegram_id=1, first_name="Alice")
    bob = User(telegram_id=2, first_name="Bob")
    session.add_all([alice, bob])
    await session.flush()
    return session, alice, bob


def test_first_transaction_creates_debt_row(run):
    async def scenario():
        session, alice, bob = await _make_session(run)
        await create_transaction(
            session,
            entered_by=alice,
            other=bob,
            direction=TransactionDirection.RECEIVED,
            amount=100_000,
            status=TransactionStatus.CONFIRMED,
        )
        assert await get_debt_between(session, alice.id, bob.id, "UZS") == 100_000
        assert await get_debt_between(session, bob.id, alice.id, "UZS") == -100_000

    run(scenario())


def test_pending_transaction_not_counted_until_confirmed(run):
    async def scenario():
        session, alice, bob = await _make_session(run)
        tx = await create_transaction(
            session,
            entered_by=alice,
            other=bob,
            direction=TransactionDirection.RECEIVED,
            amount=50_000,
            status=TransactionStatus.PENDING,
        )
        assert await get_debt_between(session, alice.id, bob.id, "UZS") == 0

        changed = await set_transaction_status(
            session,
            tx,
            TransactionStatus.CONFIRMED,
            expected_status=TransactionStatus.PENDING,
        )
        assert changed
        assert await get_debt_between(session, alice.id, bob.id, "UZS") == 50_000

        # A second decision on the same transaction must lose.
        changed_again = await set_transaction_status(
            session,
            tx,
            TransactionStatus.REJECTED,
            expected_status=TransactionStatus.PENDING,
        )
        assert not changed_again

    run(scenario())


def test_rejected_transaction_not_counted(run):
    async def scenario():
        session, alice, bob = await _make_session(run)
        tx = await create_transaction(
            session,
            entered_by=alice,
            other=bob,
            direction=TransactionDirection.RECEIVED,
            amount=50_000,
            status=TransactionStatus.PENDING,
        )
        await set_transaction_status(
            session,
            tx,
            TransactionStatus.REJECTED,
            expected_status=TransactionStatus.PENDING,
        )
        assert await get_debt_between(session, alice.id, bob.id, "UZS") == 0

    run(scenario())


def test_repayment_reduces_debt_and_overpayment_is_rejected(run):
    async def scenario():
        session, alice, bob = await _make_session(run)
        await create_transaction(
            session,
            entered_by=alice,
            other=bob,
            direction=TransactionDirection.RECEIVED,
            amount=100_000,
            status=TransactionStatus.CONFIRMED,
        )
        await create_transaction(
            session,
            entered_by=alice,
            other=bob,
            direction=TransactionDirection.GIVEN,
            amount=40_000,
            status=TransactionStatus.REPAYMENT,
        )
        assert await get_debt_between(session, alice.id, bob.id, "UZS") == 60_000

        with pytest.raises(ValueError):
            await create_transaction(
                session,
                entered_by=alice,
                other=bob,
                direction=TransactionDirection.GIVEN,
                amount=70_000,
                status=TransactionStatus.REPAYMENT,
            )

    run(scenario())


def test_pending_repayment_does_not_change_balance_until_confirmed(run):
    async def scenario():
        session, alice, bob = await _make_session(run)
        await create_transaction(
            session,
            entered_by=alice,
            other=bob,
            direction=TransactionDirection.RECEIVED,
            amount=100_000,
            status=TransactionStatus.CONFIRMED,
        )
        pending = await create_transaction(
            session,
            entered_by=alice,
            other=bob,
            direction=TransactionDirection.GIVEN,
            amount=40_000,
            status=TransactionStatus.REPAYMENT_PENDING,
        )

        assert await get_debt_between(session, alice.id, bob.id, "UZS") == 100_000
        breakdown = await get_balance_breakdown(
            session,
            user_id=alice.id,
            other_user_id=bob.id,
            currency="UZS",
        )
        assert breakdown.repaid_by_user == 0

        changed = await set_transaction_status(
            session,
            pending,
            TransactionStatus.REPAYMENT,
            expected_status=TransactionStatus.REPAYMENT_PENDING,
        )
        assert changed
        assert await get_debt_between(session, alice.id, bob.id, "UZS") == 60_000

    run(scenario())


def test_balance_breakdown_keeps_debts_and_repayments_separate(run):
    async def scenario():
        session, alice, bob = await _make_session(run)
        await create_transaction(
            session,
            entered_by=alice,
            other=bob,
            direction=TransactionDirection.RECEIVED,
            amount=100_000,
            status=TransactionStatus.CONFIRMED,
        )
        await create_transaction(
            session,
            entered_by=alice,
            other=bob,
            direction=TransactionDirection.GIVEN,
            amount=30_000,
            status=TransactionStatus.CONFIRMED,
        )
        await create_transaction(
            session,
            entered_by=alice,
            other=bob,
            direction=TransactionDirection.GIVEN,
            amount=40_000,
            status=TransactionStatus.REPAYMENT,
        )
        await create_transaction(
            session,
            entered_by=bob,
            other=alice,
            direction=TransactionDirection.GIVEN,
            amount=10_000,
            status=TransactionStatus.REPAYMENT,
        )

        breakdown = await get_balance_breakdown(
            session,
            user_id=alice.id,
            other_user_id=bob.id,
            currency="UZS",
        )
        assert breakdown.lent_total == 30_000
        assert breakdown.borrowed_total == 100_000
        assert breakdown.repaid_by_user == 40_000
        assert breakdown.repaid_to_user == 10_000
        assert await get_debt_between(session, alice.id, bob.id, "UZS") == 40_000

    run(scenario())


def test_confirmation_after_settled_debt_allows_new_reverse_debt(run):
    """A valid earlier repayment cannot block a later debt in the other direction."""
    async def scenario():
        session, alice, bob = await _make_session(run)
        await create_transaction(
            session,
            entered_by=alice,
            other=bob,
            direction=TransactionDirection.RECEIVED,
            amount=100_000,
            status=TransactionStatus.CONFIRMED,
        )
        await create_transaction(
            session,
            entered_by=alice,
            other=bob,
            direction=TransactionDirection.GIVEN,
            amount=100_000,
            status=TransactionStatus.REPAYMENT,
        )

        # Alice later gives Bob 500k. Bob's confirmation must succeed even
        # though the prior debt was repaid in the opposite direction.
        pending = await create_transaction(
            session,
            entered_by=alice,
            other=bob,
            direction=TransactionDirection.GIVEN,
            amount=500_000,
            status=TransactionStatus.PENDING,
        )
        changed = await set_transaction_status(
            session,
            pending,
            TransactionStatus.CONFIRMED,
            expected_status=TransactionStatus.PENDING,
        )

        assert changed
        assert await get_debt_between(session, bob.id, alice.id, "UZS") == 500_000

    run(scenario())


def test_deleting_repaid_loan_is_rejected(run):
    async def scenario():
        session, alice, bob = await _make_session(run)
        loan = await create_transaction(
            session,
            entered_by=alice,
            other=bob,
            direction=TransactionDirection.RECEIVED,
            amount=100_000,
            status=TransactionStatus.CONFIRMED,
        )
        await create_transaction(
            session,
            entered_by=alice,
            other=bob,
            direction=TransactionDirection.GIVEN,
            amount=100_000,
            status=TransactionStatus.REPAYMENT,
        )
        with pytest.raises(ValueError):
            await delete_transaction(session, loan)

    run(scenario())


def test_reducing_loan_below_repayments_is_rejected(run):
    async def scenario():
        session, alice, bob = await _make_session(run)
        loan = await create_transaction(
            session,
            entered_by=alice,
            other=bob,
            direction=TransactionDirection.RECEIVED,
            amount=100_000,
            status=TransactionStatus.CONFIRMED,
        )
        await create_transaction(
            session,
            entered_by=alice,
            other=bob,
            direction=TransactionDirection.GIVEN,
            amount=60_000,
            status=TransactionStatus.REPAYMENT,
        )
        with pytest.raises(ValueError):
            await update_transaction(session, loan, amount=50_000)

        # Reducing while staying above repayments is fine.
        await update_transaction(session, loan, amount=80_000)
        assert await get_debt_between(session, alice.id, bob.id, "UZS") == 20_000

    run(scenario())


def test_history_hide_is_user_scoped_and_only_allows_inactive_entries(run):
    async def scenario():
        session, alice, bob = await _make_session(run)
        rejected = await create_transaction(
            session,
            entered_by=bob,
            other=alice,
            direction=TransactionDirection.RECEIVED,
            amount=25_000,
            status=TransactionStatus.PENDING,
        )
        await set_transaction_status(
            session,
            rejected,
            TransactionStatus.REJECTED,
            expected_status=TransactionStatus.PENDING,
        )
        assert await can_hide_transaction(session, rejected, alice.id)
        assert await hide_transaction_for_user(session, rejected, alice.id)
        await session.commit()

        alice_history = await get_pair_transactions(
            session, user_id=alice.id, other_user_id=bob.id
        )
        bob_history = await get_pair_transactions(
            session, user_id=bob.id, other_user_id=alice.id
        )
        assert rejected not in alice_history
        assert rejected in bob_history

        active = await create_transaction(
            session,
            entered_by=alice,
            other=bob,
            direction=TransactionDirection.RECEIVED,
            amount=100_000,
            status=TransactionStatus.CONFIRMED,
        )
        await create_transaction(
            session,
            entered_by=alice,
            other=bob,
            direction=TransactionDirection.GIVEN,
            amount=40_000,
            status=TransactionStatus.REPAYMENT,
        )
        assert not await can_hide_transaction(session, active, alice.id)
        assert not await hide_transaction_for_user(session, active, alice.id)

        opposite_active = await create_transaction(
            session,
            entered_by=bob,
            other=alice,
            direction=TransactionDirection.RECEIVED,
            amount=60_000,
            status=TransactionStatus.CONFIRMED,
        )
        assert await get_debt_between(session, alice.id, bob.id, "UZS") == 0
        assert not await can_hide_transaction(session, active, alice.id)
        assert not await can_hide_transaction(session, opposite_active, alice.id)

        await create_transaction(
            session,
            entered_by=alice,
            other=bob,
            direction=TransactionDirection.GIVEN,
            amount=60_000,
            status=TransactionStatus.REPAYMENT,
        )
        await create_transaction(
            session,
            entered_by=bob,
            other=alice,
            direction=TransactionDirection.GIVEN,
            amount=60_000,
            status=TransactionStatus.REPAYMENT,
        )
        assert await can_hide_transaction(session, active, alice.id)
        assert await hide_transaction_for_user(session, active, alice.id)

    run(scenario())
