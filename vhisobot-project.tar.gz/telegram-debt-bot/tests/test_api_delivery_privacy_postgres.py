"""PostgreSQL-backed API coverage for Telegram delivery privacy.

The browser fixture deliberately bypasses the database. This test starts the
real API server, seeds production-shaped rows, and checks the query joins and
decision mutations against PostgreSQL.
"""

import asyncio
from concurrent.futures import ThreadPoolExecutor
import json
import os
import subprocess
import threading
import time
import urllib.error
import urllib.request
from collections.abc import Iterator
from contextlib import contextmanager
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

import asyncpg
import pytest


DATABASE_URL = os.environ.get("DATABASE_URL", "")
pytestmark = pytest.mark.skipif(
    not DATABASE_URL.startswith(("postgres://", "postgresql://", "postgresql+asyncpg://")),
    reason="requires a PostgreSQL DATABASE_URL",
)

ROOT = Path(__file__).resolve().parents[2]
TEST_SESSION_SECRET = "api-delivery-privacy-postgres-test-secret"
FAILURE_MARKER = "Telegram delivery diagnostic must stay private"
TEMPORARY_FAILURE_MARKER = "Temporary Telegram outage diagnostic must stay private"
DIAGNOSTICS_DIR = os.environ.get("MOBILE_TRANSACTION_DIAGNOSTICS_DIR")


def _server_output(name: str) -> tuple[object, object | None]:
    if not DIAGNOSTICS_DIR:
        return subprocess.DEVNULL, None

    try:
        diagnostics_dir = Path(DIAGNOSTICS_DIR)
        diagnostics_dir.mkdir(parents=True, exist_ok=True)
        output = (diagnostics_dir / name).open("w", encoding="utf-8")
    except OSError:
        return subprocess.DEVNULL, None
    return output, output


def _asyncpg_url() -> tuple[str, bool]:
    parts = urlsplit(DATABASE_URL)
    scheme = parts.scheme.replace("+asyncpg", "")
    query = dict(parse_qsl(parts.query, keep_blank_values=True))
    sslmode = query.pop("sslmode", None)
    return (
        urlunsplit((scheme, parts.netloc, parts.path, urlencode(query), parts.fragment)),
        sslmode in {"require", "verify-ca", "verify-full"},
    )


async def _connect() -> asyncpg.Connection:
    url, use_ssl = _asyncpg_url()
    return await asyncpg.connect(url, ssl=use_ssl)


@pytest.fixture()
def seeded_database() -> Iterator[dict[str, int | str]]:
    async def seed() -> dict[str, int | str]:
        connection = await _connect()
        try:
            suffix = time.time_ns() % 10**12
            alice_id = await connection.fetchval(
                """
                INSERT INTO users (telegram_id, username, first_name, last_name)
                VALUES ($1, $2, 'Privacy Test Alice', NULL)
                RETURNING id
                """,
                -suffix,
                f"privacy_test_alice_{suffix}",
            )
            bob_id = await connection.fetchval(
                """
                INSERT INTO users (telegram_id, username, first_name, last_name)
                VALUES ($1, $2, 'Privacy Test Bob', NULL)
                RETURNING id
                """,
                -(suffix + 1),
                f"privacy_test_bob_{suffix}",
            )
            await connection.execute(
                """
                INSERT INTO user_links (user_id, contact_id)
                VALUES ($1, $2), ($2, $1)
                """,
                alice_id,
                bob_id,
            )

            transaction_ids: list[int] = []
            for amount in (100, 200, 300):
                transaction_id = await connection.fetchval(
                    """
                    INSERT INTO transactions
                        (debtor_id, creditor_id, entered_by_id, scope_chat_id,
                         amount, currency, direction, status, note, created_at)
                    VALUES ($1, $2, $2, 0, $3, 'UZS', 'received', 'pending',
                            'PostgreSQL privacy regression', NOW())
                    RETURNING id
                    """,
                    alice_id,
                    bob_id,
                    amount,
                )
                transaction_ids.append(transaction_id)

            confirmed_debt_id = await connection.fetchval(
                """
                INSERT INTO transactions
                    (debtor_id, creditor_id, entered_by_id, scope_chat_id,
                     amount, currency, direction, status, note, created_at)
                VALUES ($1, $2, $1, 0, 100, 'UZS', 'received', 'confirmed',
                        'PostgreSQL repayment decision seed', NOW())
                RETURNING id
                """,
                alice_id,
                bob_id,
            )
            repayment_id = await connection.fetchval(
                """
                INSERT INTO transactions
                    (debtor_id, creditor_id, entered_by_id, scope_chat_id,
                     amount, currency, direction, status, note, created_at)
                VALUES ($1, $2, $2, 0, 30, 'UZS', 'given', 'repayment_pending',
                        'PostgreSQL failed repayment review', NOW())
                RETURNING id
                """,
                bob_id,
                alice_id,
            )

            await connection.executemany(
                """
                INSERT INTO pending_notifications
                    (transaction_id, recipient_telegram_id, kind, status, last_error)
                VALUES ($1, $2, 'debt', $3, $4)
                """,
                [
                    (transaction_ids[0], -suffix, "pending", None),
                    (transaction_ids[1], -suffix, "sent", None),
                    (transaction_ids[2], -suffix, "permanent_failure", FAILURE_MARKER),
                    (repayment_id, -(suffix + 1), "permanent_failure", FAILURE_MARKER),
                ],
            )
            return {
                "alice_id": alice_id,
                "bob_id": bob_id,
                "bob_telegram_id": -(suffix + 1),
                "bob_username": f"privacy_test_bob_{suffix}",
                "pending_id": transaction_ids[0],
                "sent_id": transaction_ids[1],
                "failed_id": transaction_ids[2],
                "confirmed_debt_id": confirmed_debt_id,
                "repayment_id": repayment_id,
            }
        finally:
            await connection.close()

    state = asyncio.run(seed())
    try:
        yield state
    finally:
        async def cleanup() -> None:
            connection = await _connect()
            try:
                async with connection.transaction():
                    transaction_ids = await connection.fetch(
                        """
                        SELECT id
                        FROM transactions
                        WHERE debtor_id = $1 OR creditor_id = $1
                        """,
                        state["alice_id"],
                    )
                    ids = [row["id"] for row in transaction_ids]
                    if ids:
                        await connection.execute(
                            """
                            DELETE FROM transaction_history_hides
                            WHERE transaction_id = ANY($1::integer[])
                            """,
                            ids,
                        )
                        await connection.execute(
                            """
                            DELETE FROM transactions
                            WHERE id = ANY($1::integer[])
                            """,
                            ids,
                        )
                    await connection.execute(
                        """
                        DELETE FROM debts
                        WHERE user_low_id = ANY($1::integer[])
                           OR user_high_id = ANY($1::integer[])
                        """,
                        [state["alice_id"], state["bob_id"]],
                    )
                    await connection.execute(
                        """
                        DELETE FROM user_links
                        WHERE user_id = ANY($1::integer[])
                           OR contact_id = ANY($1::integer[])
                        """,
                        [state["alice_id"], state["bob_id"]],
                    )
                    await connection.execute(
                        "DELETE FROM users WHERE id = ANY($1::integer[])",
                        [state["alice_id"], state["bob_id"]],
                    )
            finally:
                await connection.close()

        asyncio.run(cleanup())


@pytest.fixture()
def api_server(seeded_database: dict[str, int | str]) -> Iterator[str]:
    del seeded_database
    with _running_api_server() as base_url:
        yield base_url


@pytest.fixture()
def api_server_with_telegram(
    seeded_database: dict[str, int | str],
    telegram_api_stub: dict[str, object],
) -> Iterator[str]:
    del seeded_database
    with _running_api_server(str(telegram_api_stub["url"])) as base_url:
        yield base_url


@pytest.fixture()
def mobile_server(api_server: str) -> Iterator[str]:
    probe = __import__("socket").socket()
    probe.bind(("127.0.0.1", 0))
    port = probe.getsockname()[1]
    probe.close()

    environment = os.environ.copy()
    environment.update(
        {
            "NODE_ENV": "development",
            "EXPO_PUBLIC_API_URL": api_server,
            "PORT": str(port),
        }
    )
    server_output, output_file = _server_output("mobile-server.log")
    try:
        process = subprocess.Popen(
            [
                "pnpm",
                "--filter",
                "@workspace/debt-mobile",
                "exec",
                "expo",
                "start",
                "--web",
                "--localhost",
                "--port",
                str(port),
            ],
            cwd=ROOT,
            env=environment,
            stdout=server_output,
            stderr=subprocess.STDOUT,
        )
    except Exception:
        if output_file is not None:
            output_file.close()
        raise
    base_url = f"http://127.0.0.1:{port}"
    deadline = time.monotonic() + 180
    try:
        while time.monotonic() < deadline:
            if process.poll() is not None:
                raise RuntimeError("Mobile web server exited before becoming healthy")
            try:
                with urllib.request.urlopen(base_url, timeout=2) as response:
                    if response.status == 200:
                        break
            except (urllib.error.URLError, TimeoutError):
                time.sleep(0.25)
        else:
            raise RuntimeError("Mobile web server did not become healthy within 180 seconds")
        yield base_url
    finally:
        if process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=10)
        if output_file is not None:
            output_file.close()


def _request(
    base_url: str,
    token: str,
    path: str,
    method: str = "GET",
    body: dict[str, str | int] | None = None,
) -> tuple[int, dict]:
    data = json.dumps(body).encode() if body is not None else None
    request = urllib.request.Request(
        f"{base_url}{path}",
        data=data,
        method=method,
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        },
    )
    try:
        with urllib.request.urlopen(request, timeout=10) as response:
            return response.status, json.loads(response.read())
    except urllib.error.HTTPError as error:
        details = error.read().decode("utf-8", errors="replace")
        raise AssertionError(f"{method} {path} returned HTTP {error.code}: {details}") from error


def _request_status(
    base_url: str,
    token: str,
    path: str,
    method: str = "GET",
    body: dict[str, str | int] | None = None,
) -> tuple[int, dict]:
    data = json.dumps(body).encode() if body is not None else None
    request = urllib.request.Request(
        f"{base_url}{path}",
        data=data,
        method=method,
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        },
    )
    try:
        with urllib.request.urlopen(request, timeout=10) as response:
            return response.status, json.loads(response.read())
    except urllib.error.HTTPError as error:
        return error.code, json.loads(error.read())


def _session_token(user_id: int) -> str:
    import base64
    import hashlib
    import hmac

    claims = {
        "sub": user_id,
        "exp": int(time.time()) + 3600,
        "pinUntil": None,
    }
    encoded = base64.urlsafe_b64encode(json.dumps(claims, separators=(",", ":")).encode()).rstrip(
        b"="
    )
    signature = hmac.new(
        TEST_SESSION_SECRET.encode(),
        encoded,
        hashlib.sha256,
    ).digest()
    encoded_signature = base64.urlsafe_b64encode(signature).rstrip(b"=")
    return f"{encoded.decode()}.{encoded_signature.decode()}"


@contextmanager
def _running_api_server(telegram_api_base_url: str | None = None) -> Iterator[str]:
    probe = __import__("socket").socket()
    probe.bind(("127.0.0.1", 0))
    port = probe.getsockname()[1]
    probe.close()

    environment = os.environ.copy()
    environment.update(
        {
            "NODE_ENV": "development",
            "PORT": str(port),
            "SESSION_SECRET": TEST_SESSION_SECRET,
            "TELEGRAM_BOT_TOKEN": (
                "api-delivery-privacy-test-token"
                if telegram_api_base_url is not None
                else ""
            ),
        }
    )
    if telegram_api_base_url is not None:
        environment["TELEGRAM_API_BASE_URL"] = telegram_api_base_url
    server_output, output_file = _server_output("api-server.log")
    try:
        process = subprocess.Popen(
            ["pnpm", "--filter", "@workspace/api-server", "run", "dev"],
            cwd=ROOT,
            env=environment,
            stdout=server_output,
            stderr=subprocess.STDOUT,
        )
    except Exception:
        if output_file is not None:
            output_file.close()
        raise
    base_url = f"http://127.0.0.1:{port}"
    deadline = time.monotonic() + 120
    try:
        while time.monotonic() < deadline:
            if process.poll() is not None:
                raise RuntimeError("API server exited before becoming healthy")
            try:
                with urllib.request.urlopen(f"{base_url}/api/healthz", timeout=2) as response:
                    if response.status == 200:
                        break
            except (urllib.error.URLError, TimeoutError):
                time.sleep(0.25)
        else:
            raise RuntimeError("API server did not become healthy within 120 seconds")
        yield base_url
    finally:
        if process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=10)
        if output_file is not None:
            output_file.close()


@pytest.fixture(params=[400, 403], ids=["telegram-400", "telegram-403"])
def telegram_api_stub(request) -> Iterator[dict[str, object]]:
    requests: list[dict] = []
    response_status = request.param
    failure_body = json.dumps({"ok": False, "description": FAILURE_MARKER}).encode()

    class TelegramStubHandler(BaseHTTPRequestHandler):
        def do_POST(self) -> None:
            content_length = int(self.headers.get("Content-Length", "0"))
            requests.append(json.loads(self.rfile.read(content_length)))
            self.send_response(response_status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(failure_body)))
            self.end_headers()
            self.wfile.write(failure_body)

        def log_message(self, format: str, *args: object) -> None:
            del format, args

    server = ThreadingHTTPServer(("127.0.0.1", 0), TelegramStubHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield {
            "url": f"http://127.0.0.1:{server.server_port}",
            "requests": requests,
            "status": response_status,
        }
    finally:
        server.shutdown()
        thread.join(timeout=5)
        server.server_close()


@pytest.fixture()
def successful_telegram_api_stub() -> Iterator[dict[str, object]]:
    requests: list[dict] = []
    response_body = json.dumps(
        {"ok": True, "result": {"message_id": 1}}
    ).encode()

    class TelegramStubHandler(BaseHTTPRequestHandler):
        def do_POST(self) -> None:
            content_length = int(self.headers.get("Content-Length", "0"))
            requests.append(json.loads(self.rfile.read(content_length)))
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(response_body)))
            self.end_headers()
            self.wfile.write(response_body)

        def log_message(self, format: str, *args: object) -> None:
            del format, args

    server = ThreadingHTTPServer(("127.0.0.1", 0), TelegramStubHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield {
            "url": f"http://127.0.0.1:{server.server_port}",
            "requests": requests,
        }
    finally:
        server.shutdown()
        thread.join(timeout=5)
        server.server_close()


@pytest.fixture(
    params=["temporary-500", "temporary-network"],
    ids=["telegram-temporary-500", "telegram-temporary-network"],
)
def temporary_telegram_api_stub(request) -> Iterator[dict[str, object]]:
    requests: list[dict] = []
    failure_mode = request.param
    failure_body = json.dumps(
        {"ok": False, "description": TEMPORARY_FAILURE_MARKER}
    ).encode()
    success_body = json.dumps(
        {"ok": True, "result": {"message_id": 1}}
    ).encode()

    class TelegramStubHandler(BaseHTTPRequestHandler):
        def do_POST(self) -> None:
            content_length = int(self.headers.get("Content-Length", "0"))
            requests.append(json.loads(self.rfile.read(content_length)))
            if len(requests) == 1 and failure_mode == "temporary-network":
                self.connection.close()
                return

            if len(requests) == 1:
                self.send_response(500)
                response_body = failure_body
            else:
                self.send_response(200)
                response_body = success_body
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(response_body)))
            self.end_headers()
            self.wfile.write(response_body)

        def log_message(self, format: str, *args: object) -> None:
            del format, args

    server = ThreadingHTTPServer(("127.0.0.1", 0), TelegramStubHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield {
            "url": f"http://127.0.0.1:{server.server_port}",
            "requests": requests,
            "failure_mode": failure_mode,
        }
    finally:
        server.shutdown()
        thread.join(timeout=5)
        server.server_close()


@pytest.fixture(
    params=["exhausted-500", "exhausted-network"],
    ids=["telegram-exhausted-500", "telegram-exhausted-network"],
)
def exhausted_telegram_api_stub(request) -> Iterator[dict[str, object]]:
    requests: list[dict] = []
    failure_mode = request.param
    failure_body = json.dumps(
        {"ok": False, "description": TEMPORARY_FAILURE_MARKER}
    ).encode()

    class TelegramStubHandler(BaseHTTPRequestHandler):
        def do_POST(self) -> None:
            content_length = int(self.headers.get("Content-Length", "0"))
            requests.append(json.loads(self.rfile.read(content_length)))
            if failure_mode == "exhausted-network":
                self.connection.close()
                return

            self.send_response(500)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(failure_body)))
            self.end_headers()
            self.wfile.write(failure_body)

        def log_message(self, format: str, *args: object) -> None:
            del format, args

    server = ThreadingHTTPServer(("127.0.0.1", 0), TelegramStubHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield {
            "url": f"http://127.0.0.1:{server.server_port}",
            "requests": requests,
            "failure_mode": failure_mode,
        }
    finally:
        server.shutdown()
        thread.join(timeout=5)
        server.server_close()


def _assert_safe_delivery_response(body: dict | list) -> None:
    serialized = json.dumps(body)
    assert "last_error" not in serialized
    assert FAILURE_MARKER not in serialized
    assert TEMPORARY_FAILURE_MARKER not in serialized
    assert "permanent_failure" not in serialized

    transactions = body if isinstance(body, list) else body.get("recentTransactions", [])
    for transaction in transactions:
        assert transaction["deliveryStatus"] in {"pending", "sent", "manual_review", None}


def test_real_api_keeps_delivery_diagnostics_private_and_decisions_unchanged(
    seeded_database: dict[str, int],
    api_server: str,
) -> None:
    token = _session_token(seeded_database["alice_id"])

    status, transactions = _request(api_server, token, "/api/transactions")
    assert status == 200
    _assert_safe_delivery_response(transactions)
    by_id = {transaction["id"]: transaction for transaction in transactions}
    assert by_id[seeded_database["pending_id"]]["deliveryStatus"] == "pending"
    assert by_id[seeded_database["sent_id"]]["deliveryStatus"] == "sent"
    assert by_id[seeded_database["failed_id"]]["deliveryStatus"] == "manual_review"

    status, dashboard = _request(api_server, token, "/api/dashboard")
    assert status == 200
    _assert_safe_delivery_response(dashboard)
    dashboard_by_id = {transaction["id"]: transaction for transaction in dashboard["recentTransactions"]}
    assert dashboard_by_id[seeded_database["pending_id"]]["deliveryStatus"] == "pending"
    assert dashboard_by_id[seeded_database["sent_id"]]["deliveryStatus"] == "sent"
    assert dashboard_by_id[seeded_database["failed_id"]]["deliveryStatus"] == "manual_review"

    status, confirmed = _request(
        api_server,
        token,
        f"/api/transactions/{seeded_database['failed_id']}/decision",
        method="POST",
        body={"decision": "confirmed"},
    )
    assert status == 200
    _assert_safe_delivery_response(confirmed)
    assert confirmed["status"] == "confirmed"
    assert confirmed["deliveryStatus"] is None

    status, rejected = _request(
        api_server,
        token,
        f"/api/transactions/{seeded_database['sent_id']}/decision",
        method="POST",
        body={"decision": "rejected"},
    )
    assert status == 200
    _assert_safe_delivery_response(rejected)
    assert rejected["status"] == "rejected"
    assert rejected["deliveryStatus"] is None

    async def read_decision_state() -> tuple[dict[int, str], set[int]]:
        connection = await _connect()
        try:
            statuses = await connection.fetch(
                """
                SELECT id, status
                FROM transactions
                WHERE id = ANY($1::integer[])
                """,
                [seeded_database["failed_id"], seeded_database["sent_id"]],
            )
            remaining_notifications = await connection.fetch(
                """
                SELECT transaction_id
                FROM pending_notifications
                WHERE transaction_id = ANY($1::integer[])
                """,
                [seeded_database["failed_id"], seeded_database["sent_id"]],
            )
            return (
                {row["id"]: row["status"] for row in statuses},
                {row["transaction_id"] for row in remaining_notifications},
            )
        finally:
            await connection.close()

    decision_statuses, remaining_notifications = asyncio.run(read_decision_state())
    assert decision_statuses == {
        seeded_database["failed_id"]: "confirmed",
        seeded_database["sent_id"]: "rejected",
    }
    assert remaining_notifications == set()


def test_recipient_can_resend_failed_repayment_notification_once_per_cooldown(
    seeded_database: dict[str, int | str],
    api_server_with_telegram: str,
    telegram_api_stub: dict[str, object],
) -> None:
    repayment_id = seeded_database["repayment_id"]
    recipient_token = _session_token(seeded_database["bob_id"])
    sender_token = _session_token(seeded_database["alice_id"])

    forbidden_status, forbidden = _request_status(
        api_server_with_telegram,
        sender_token,
        f"/api/transactions/{repayment_id}/resend-notification",
        method="POST",
    )
    assert forbidden_status == 404
    assert "last_error" not in json.dumps(forbidden)
    assert telegram_api_stub["requests"] == []

    status, resent = _request(
        api_server_with_telegram,
        recipient_token,
        f"/api/transactions/{repayment_id}/resend-notification",
        method="POST",
    )
    assert status == 200
    _assert_safe_delivery_response(resent)
    assert resent["status"] == "repayment_pending"
    assert resent["deliveryStatus"] == "manual_review"
    assert len(telegram_api_stub["requests"]) == 1

    async def read_notification_state() -> tuple[int, dict]:
        connection = await _connect()
        try:
            count = await connection.fetchval(
                "SELECT COUNT(*) FROM transactions WHERE id = $1",
                repayment_id,
            )
            notification = await connection.fetchrow(
                """
                SELECT status, attempt_count, last_error, resend_available_at
                FROM pending_notifications
                WHERE transaction_id = $1
                """,
                repayment_id,
            )
            return count, dict(notification)
        finally:
            await connection.close()

    transaction_count, notification = asyncio.run(read_notification_state())
    assert transaction_count == 1
    assert notification["status"] == "permanent_failure"
    assert notification["attempt_count"] == 1
    assert notification["last_error"] == FAILURE_MARKER
    assert notification["resend_available_at"] is not None

    rate_limited_status, rate_limited = _request_status(
        api_server_with_telegram,
        recipient_token,
        f"/api/transactions/{repayment_id}/resend-notification",
        method="POST",
    )
    assert rate_limited_status == 429
    assert rate_limited["code"] == "RESEND_RATE_LIMITED"
    assert "last_error" not in json.dumps(rate_limited)
    assert len(telegram_api_stub["requests"]) == 1


def test_real_api_recovers_failed_repayment_delivery_on_resend(
    seeded_database: dict[str, int | str],
    successful_telegram_api_stub: dict[str, object],
) -> None:
    repayment_id = seeded_database["repayment_id"]

    async def read_state() -> tuple[str, int, str, int, str | None]:
        connection = await _connect()
        try:
            transaction_status = await connection.fetchval(
                "SELECT status FROM transactions WHERE id = $1",
                repayment_id,
            )
            notification = await connection.fetchrow(
                """
                SELECT status, attempt_count, last_error
                FROM pending_notifications
                WHERE transaction_id = $1
                """,
                repayment_id,
            )
            notification_count = await connection.fetchval(
                """
                SELECT COUNT(*)
                FROM pending_notifications
                WHERE transaction_id = $1
                """,
                repayment_id,
            )
            return (
                transaction_status,
                notification_count,
                notification["status"],
                notification["attempt_count"],
                notification["last_error"],
            )
        finally:
            await connection.close()

    before = asyncio.run(read_state())
    assert before == (
        "repayment_pending",
        1,
        "permanent_failure",
        0,
        FAILURE_MARKER,
    )

    with _running_api_server(str(successful_telegram_api_stub["url"])) as api_server:
        status, resent = _request(
            api_server,
            _session_token(seeded_database["bob_id"]),
            f"/api/transactions/{repayment_id}/resend-notification",
            method="POST",
        )
        assert status == 200
        _assert_safe_delivery_response(resent)
        assert resent["status"] == "repayment_pending"
        assert resent["deliveryStatus"] == "sent"
        assert len(successful_telegram_api_stub["requests"]) == 1

        after_resend = asyncio.run(read_state())
        assert after_resend == (
            "repayment_pending",
            1,
            "sent",
            1,
            None,
        )

        rate_limited_status, rate_limited = _request_status(
            api_server,
            _session_token(seeded_database["bob_id"]),
            f"/api/transactions/{repayment_id}/resend-notification",
            method="POST",
        )
        assert rate_limited_status == 429
        assert rate_limited["code"] == "RESEND_RATE_LIMITED"
        assert "last_error" not in json.dumps(rate_limited)
        assert len(successful_telegram_api_stub["requests"]) == 1

        after_rate_limit = asyncio.run(read_state())
        assert after_rate_limit == (
            "repayment_pending",
            1,
            "sent",
            1,
            None,
        )


def test_real_api_rejects_concurrent_repayment_resends_during_cooldown(
    seeded_database: dict[str, int | str],
    successful_telegram_api_stub: dict[str, object],
) -> None:
    repayment_id = seeded_database["repayment_id"]
    resend_path = f"/api/transactions/{repayment_id}/resend-notification"
    recipient_token = _session_token(seeded_database["bob_id"])
    requests_started = threading.Barrier(2)

    def resend() -> tuple[int, dict]:
        requests_started.wait()
        return _request_status(
            api_server,
            recipient_token,
            resend_path,
            method="POST",
        )

    async def read_state() -> tuple[str, int, dict]:
        connection = await _connect()
        try:
            transaction_status = await connection.fetchval(
                "SELECT status FROM transactions WHERE id = $1",
                repayment_id,
            )
            notification_count = await connection.fetchval(
                """
                SELECT COUNT(*)
                FROM pending_notifications
                WHERE transaction_id = $1
                """,
                repayment_id,
            )
            notification = await connection.fetchrow(
                """
                SELECT status, attempt_count, last_error
                FROM pending_notifications
                WHERE transaction_id = $1
                """,
                repayment_id,
            )
            return transaction_status, notification_count, dict(notification)
        finally:
            await connection.close()

    with _running_api_server(str(successful_telegram_api_stub["url"])) as api_server:
        with ThreadPoolExecutor(max_workers=2) as executor:
            futures = [executor.submit(resend) for _ in range(2)]
            responses = [future.result() for future in futures]

    assert sorted(status for status, _ in responses) == [200, 429]
    delivery_response = next(body for status, body in responses if status == 200)
    cooldown_response = next(body for status, body in responses if status == 429)
    _assert_safe_delivery_response(delivery_response)
    _assert_safe_delivery_response(cooldown_response)
    assert delivery_response["status"] == "repayment_pending"
    assert delivery_response["deliveryStatus"] == "sent"
    assert cooldown_response["code"] == "RESEND_RATE_LIMITED"
    assert len(successful_telegram_api_stub["requests"]) == 1

    transaction_status, notification_count, notification = asyncio.run(read_state())
    assert transaction_status == "repayment_pending"
    assert notification_count == 1
    assert notification == {
        "status": "sent",
        "attempt_count": 1,
        "last_error": None,
    }


def test_real_api_creates_a_transaction_on_postgresql_without_telegram(
    seeded_database: dict[str, int],
    api_server: str,
) -> None:
    token = _session_token(seeded_database["alice_id"])

    status, created = _request(
        api_server,
        token,
        "/api/transactions",
        method="POST",
        body={
            "contactId": seeded_database["bob_id"],
            "direction": "given",
            "amount": 45_000,
            "currency": "UZS",
        },
    )

    assert status == 201
    _assert_safe_delivery_response(created)
    assert created["status"] == "pending"
    assert created["deliveryStatus"] == "pending"
    assert created["debtorId"] == seeded_database["bob_id"]
    assert created["creditorId"] == seeded_database["alice_id"]
    assert created["enteredById"] == seeded_database["alice_id"]
    assert created["counterparty"]["id"] == seeded_database["bob_id"]

    async def read_created_state() -> tuple[dict, dict]:
        connection = await _connect()
        try:
            transaction = await connection.fetchrow(
                """
                SELECT debtor_id, creditor_id, entered_by_id, amount, currency,
                       direction, status, note, due_date
                FROM transactions
                WHERE id = $1
                """,
                created["id"],
            )
            notification = await connection.fetchrow(
                """
                SELECT recipient_telegram_id, kind, status, attempt_count, last_error
                FROM pending_notifications
                WHERE transaction_id = $1
                """,
                created["id"],
            )
            return dict(transaction), dict(notification)
        finally:
            await connection.close()

    transaction, notification = asyncio.run(read_created_state())
    assert transaction == {
        "debtor_id": seeded_database["bob_id"],
        "creditor_id": seeded_database["alice_id"],
        "entered_by_id": seeded_database["alice_id"],
        "amount": 45_000,
        "currency": "UZS",
        "direction": "given",
        "status": "pending",
        "note": None,
        "due_date": None,
    }
    assert notification["recipient_telegram_id"] == seeded_database["bob_telegram_id"]
    assert notification["kind"] == "debt"
    assert notification["status"] == "pending"
    assert notification["attempt_count"] == 1
    assert notification["last_error"] == "deferred"


def test_real_api_keeps_repayment_reviewable_when_telegram_rejects_delivery(
    seeded_database: dict[str, int | str],
    api_server_with_telegram: str,
    telegram_api_stub: dict[str, object],
) -> None:
    async def seed_debt() -> None:
        connection = await _connect()
        try:
            await connection.execute(
                """
                INSERT INTO debts
                    (user_low_id, user_high_id, currency, scope_chat_id,
                     balance_low_to_high, updated_at)
                VALUES ($1, $2, 'UZS', 0, 100, NOW())
                """,
                min(seeded_database["alice_id"], seeded_database["bob_id"]),
                max(seeded_database["alice_id"], seeded_database["bob_id"]),
            )
        finally:
            await connection.close()

    asyncio.run(seed_debt())
    token = _session_token(seeded_database["alice_id"])

    status, created = _request(
        api_server_with_telegram,
        token,
        "/api/repayments",
        method="POST",
        body={
            "contactId": seeded_database["bob_id"],
            "amount": 30,
            "currency": "UZS",
            "note": "Telegram rejection regression",
        },
    )

    assert status == 201
    _assert_safe_delivery_response(created)
    assert created["status"] == "repayment_pending"
    assert created["deliveryStatus"] == "manual_review"
    assert telegram_api_stub["status"] in {400, 403}
    assert len(telegram_api_stub["requests"]) == 1

    async def read_created_state() -> tuple[dict, dict]:
        connection = await _connect()
        try:
            transaction = await connection.fetchrow(
                """
                SELECT status
                FROM transactions
                WHERE id = $1
                """,
                created["id"],
            )
            notification = await connection.fetchrow(
                """
                SELECT status, attempt_count, last_error
                FROM pending_notifications
                WHERE transaction_id = $1
                """,
                created["id"],
            )
            return dict(transaction), dict(notification)
        finally:
            await connection.close()

    transaction, notification = asyncio.run(read_created_state())
    assert transaction["status"] == "repayment_pending"
    assert notification == {
        "status": "permanent_failure",
        "attempt_count": 1,
        "last_error": FAILURE_MARKER,
    }


def test_real_api_retries_temporary_repayment_delivery(
    seeded_database: dict[str, int | str],
    temporary_telegram_api_stub: dict[str, object],
) -> None:
    async def seed_debt() -> None:
        connection = await _connect()
        try:
            await connection.execute(
                """
                INSERT INTO debts
                    (user_low_id, user_high_id, currency, scope_chat_id,
                     balance_low_to_high, updated_at)
                VALUES ($1, $2, 'UZS', 0, 100, NOW())
                """,
                min(seeded_database["alice_id"], seeded_database["bob_id"]),
                max(seeded_database["alice_id"], seeded_database["bob_id"]),
            )
        finally:
            await connection.close()

    asyncio.run(seed_debt())
    with _running_api_server(str(temporary_telegram_api_stub["url"])) as api_server:
        token = _session_token(seeded_database["alice_id"])
        status, created = _request(
            api_server,
            token,
            "/api/repayments",
            method="POST",
            body={
                "contactId": seeded_database["bob_id"],
                "amount": 30,
                "currency": "UZS",
                "note": "Temporary Telegram failure regression",
            },
        )

    assert status == 201
    _assert_safe_delivery_response(created)
    assert created["status"] == "repayment_pending"
    assert created["deliveryStatus"] == "sent"
    assert temporary_telegram_api_stub["failure_mode"] in {
        "temporary-500",
        "temporary-network",
    }
    assert len(temporary_telegram_api_stub["requests"]) == 2

    async def read_created_state() -> tuple[dict, dict]:
        connection = await _connect()
        try:
            transaction = await connection.fetchrow(
                """
                SELECT status
                FROM transactions
                WHERE id = $1
                """,
                created["id"],
            )
            notification = await connection.fetchrow(
                """
                SELECT status, attempt_count, last_error
                FROM pending_notifications
                WHERE transaction_id = $1
                """,
                created["id"],
            )
            return dict(transaction), dict(notification)
        finally:
            await connection.close()

    transaction, notification = asyncio.run(read_created_state())
    assert transaction["status"] == "repayment_pending"
    assert notification == {
        "status": "sent",
        "attempt_count": 1,
        "last_error": None,
    }


def test_real_api_keeps_repayment_reviewable_after_telegram_retry_exhaustion(
    seeded_database: dict[str, int | str],
    exhausted_telegram_api_stub: dict[str, object],
) -> None:
    async def seed_debt() -> None:
        connection = await _connect()
        try:
            await connection.execute(
                """
                INSERT INTO debts
                    (user_low_id, user_high_id, currency, scope_chat_id,
                     balance_low_to_high, updated_at)
                VALUES ($1, $2, 'UZS', 0, 100, NOW())
                """,
                min(seeded_database["alice_id"], seeded_database["bob_id"]),
                max(seeded_database["alice_id"], seeded_database["bob_id"]),
            )
        finally:
            await connection.close()

    asyncio.run(seed_debt())
    with _running_api_server(str(exhausted_telegram_api_stub["url"])) as api_server:
        token = _session_token(seeded_database["alice_id"])
        status, created = _request(
            api_server,
            token,
            "/api/repayments",
            method="POST",
            body={
                "contactId": seeded_database["bob_id"],
                "amount": 30,
                "currency": "UZS",
                "note": "Exhausted Telegram retry regression",
            },
        )

        assert status == 201
        _assert_safe_delivery_response(created)
        assert created["status"] == "repayment_pending"
        assert created["deliveryStatus"] == "pending"

        recipient_status, recipient_transactions = _request(
            api_server,
            _session_token(seeded_database["bob_id"]),
            "/api/transactions",
        )

    assert recipient_status == 200
    _assert_safe_delivery_response(recipient_transactions)
    reviewable = next(
        transaction
        for transaction in recipient_transactions
        if transaction["id"] == created["id"]
    )
    assert reviewable["status"] == "repayment_pending"
    assert reviewable["deliveryStatus"] == "pending"
    assert exhausted_telegram_api_stub["failure_mode"] in {
        "exhausted-500",
        "exhausted-network",
    }
    assert len(exhausted_telegram_api_stub["requests"]) == 3

    async def read_created_state() -> tuple[dict, dict]:
        connection = await _connect()
        try:
            transaction = await connection.fetchrow(
                """
                SELECT status
                FROM transactions
                WHERE id = $1
                """,
                created["id"],
            )
            notification = await connection.fetchrow(
                """
                SELECT status, attempt_count, last_error
                FROM pending_notifications
                WHERE transaction_id = $1
                """,
                created["id"],
            )
            return dict(transaction), dict(notification)
        finally:
            await connection.close()

    transaction, notification = asyncio.run(read_created_state())
    assert transaction["status"] == "repayment_pending"
    assert notification == {
        "status": "pending",
        "attempt_count": 1,
        "last_error": TEMPORARY_FAILURE_MARKER
        if exhausted_telegram_api_stub["failure_mode"] == "exhausted-500"
        else "fetch failed",
    }


def test_mobile_entry_creates_a_postgresql_transaction_without_telegram(
    seeded_database: dict[str, int | str],
    api_server: str,
    mobile_server: str,
) -> None:
    environment = os.environ.copy()
    environment.update(
        {
            "MOBILE_URL": mobile_server,
            "SESSION_TOKEN": _session_token(seeded_database["alice_id"]),
            "CONTACT_DISPLAY_NAME": f"@{seeded_database['bob_username']}",
            "EXPECTED_AMOUNT": "37000",
        }
    )
    result = subprocess.run(
        ["node", str(ROOT / "telegram-debt-bot/tests/mobile_entry_browser.mjs")],
        cwd=ROOT,
        env=environment,
        capture_output=True,
        text=True,
        timeout=120,
    )
    if result.returncode != 0:
        details = "\n".join(part for part in (result.stdout, result.stderr) if part)
        pytest.fail(f"Mobile PostgreSQL browser flow failed:\n{details}")
    if controlled_failure := os.environ.get("MOBILE_TRANSACTION_TEST_FAILURE"):
        pytest.fail(controlled_failure)


def test_mobile_entry_failure_captures_real_server_diagnostics(
    seeded_database: dict[str, int | str],
    api_server: str,
    mobile_server: str,
) -> None:
    if not DIAGNOSTICS_DIR:
        pytest.skip("requires MOBILE_TRANSACTION_DIAGNOSTICS_DIR")

    environment = os.environ.copy()
    environment.update(
        {
            "MOBILE_URL": mobile_server,
            "SESSION_TOKEN": _session_token(seeded_database["alice_id"]),
            "CONTACT_DISPLAY_NAME": f"@{seeded_database['bob_username']}",
            "EXPECTED_AMOUNT": "37000",
            "MOBILE_TRANSACTION_TEST_FAILURE": (
                "controlled mobile transaction failure"
            ),
        }
    )
    result = subprocess.run(
        ["node", str(ROOT / "telegram-debt-bot/tests/mobile_entry_browser.mjs")],
        cwd=ROOT,
        env=environment,
        capture_output=True,
        text=True,
        timeout=120,
    )
    details = "\n".join(part for part in (result.stdout, result.stderr) if part)
    assert result.returncode != 0
    assert "controlled mobile transaction failure" in details

    diagnostics_dir = Path(DIAGNOSTICS_DIR)
    api_log = (diagnostics_dir / "api-server.log").read_text(encoding="utf-8")
    mobile_log = (diagnostics_dir / "mobile-server.log").read_text(encoding="utf-8")
    assert "Server listening" in api_log
    assert str(urlsplit(api_server).port) in api_log
    assert "Waiting on http://localhost:" in mobile_log
    assert str(urlsplit(mobile_server).port) in mobile_log




@pytest.mark.parametrize(
    ("decision", "expected_status"),
    [("confirmed", "repayment"), ("rejected", "rejected")],
)
def test_real_api_decides_failed_repayment_and_removes_notification(
    seeded_database: dict[str, int],
    api_server: str,
    decision: str,
    expected_status: str,
) -> None:
    token = _session_token(seeded_database["bob_id"])

    status, before = _request(api_server, token, "/api/transactions")
    assert status == 200
    _assert_safe_delivery_response(before)
    repayment = next(
        transaction
        for transaction in before
        if transaction["id"] == seeded_database["repayment_id"]
    )
    assert repayment["status"] == "repayment_pending"
    assert repayment["deliveryStatus"] == "manual_review"

    status, decided = _request(
        api_server,
        token,
        f"/api/transactions/{seeded_database['repayment_id']}/decision",
        method="POST",
        body={"decision": decision},
    )
    assert status == 200
    _assert_safe_delivery_response(decided)
    assert decided["status"] == expected_status
    assert decided["deliveryStatus"] is None

    async def read_decision_state() -> tuple[str, int]:
        connection = await _connect()
        try:
            transaction_status = await connection.fetchval(
                "SELECT status FROM transactions WHERE id = $1",
                seeded_database["repayment_id"],
            )
            remaining_notifications = await connection.fetchval(
                """
                SELECT COUNT(*)
                FROM pending_notifications
                WHERE transaction_id = $1
                """,
                seeded_database["repayment_id"],
            )
            return transaction_status, remaining_notifications
        finally:
            await connection.close()

    transaction_status, remaining_notifications = asyncio.run(read_decision_state())
    assert transaction_status == expected_status
    assert remaining_notifications == 0