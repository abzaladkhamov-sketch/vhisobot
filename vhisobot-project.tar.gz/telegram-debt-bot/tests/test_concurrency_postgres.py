"""PostgreSQL-backed concurrency tests for pair-balance serialization.

These run only when DATABASE_URL points at a PostgreSQL database (the dev
database in the Replit workspace). They create their own throwaway users
and clean every row they created afterwards.
"""

import asyncio
import base64
import hashlib
import hmac
import json
import os
import random
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from collections.abc import Callable, Iterator
from contextlib import contextmanager
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import pytest
from sqlalchemy import delete, or_, select, text
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

from db import _normalize_database_url
from models import (
    Debt,
    PendingNotification,
    PendingNotificationStatus,
    ReminderLog,
    ReportFrequency,
    Transaction,
    TransactionDirection,
    TransactionStatus,
    User,
)
from services import (
    create_transaction,
    delete_transaction,
    get_debt_between,
    set_transaction_status,
)

DATABASE_URL = os.environ.get("DATABASE_URL", "")
ROOT = Path(__file__).resolve().parents[2]
TEST_SESSION_SECRET = "cross-service-concurrency-test-secret"

pytestmark = pytest.mark.skipif(
    not DATABASE_URL.startswith(("postgres://", "postgresql://", "postgresql+asyncpg://")),
    reason="requires a PostgreSQL DATABASE_URL",
)


@pytest.fixture()
def pg():
    """Yields (run, engine, session_factory) with full cleanup."""
    loop = asyncio.new_event_loop()
    url, connect_args = _normalize_database_url(DATABASE_URL)
    engine = create_async_engine(url, connect_args=connect_args)
    factory = async_sessionmaker(engine, expire_on_commit=False)
    created_user_ids: list[int] = []

    state = {"factory": factory, "created_user_ids": created_user_ids}

    yield loop.run_until_complete, state

    async def cleanup():
        async with factory() as session:
            if created_user_ids:
                pair_filter = or_(
                    Transaction.debtor_id.in_(created_user_ids),
                    Transaction.creditor_id.in_(created_user_ids),
                )
                tx_ids = (
                    await session.execute(
                        select(Transaction.id).where(pair_filter)
                    )
                ).scalars().all()
                if tx_ids:
                    await session.execute(
                        delete(ReminderLog).where(
                            ReminderLog.transaction_id.in_(tx_ids)
                        )
                    )
                await session.execute(delete(Transaction).where(pair_filter))
                await session.execute(
                    delete(Debt).where(
                        or_(
                            Debt.user_low_id.in_(created_user_ids),
                            Debt.user_high_id.in_(created_user_ids),
                        )
                    )
                )
                await session.execute(delete(User).where(User.id.in_(created_user_ids)))
                await session.commit()
        await engine.dispose()

    loop.run_until_complete(cleanup())
    loop.close()


async def _make_pair(state):
    factory = state["factory"]
    async with factory() as session:
        alice = User(telegram_id=-random.randrange(10**12), first_name="TestAlice")
        bob = User(telegram_id=-random.randrange(10**12), first_name="TestBob")
        session.add_all([alice, bob])
        await session.commit()
        state["created_user_ids"] += [alice.id, bob.id]
        return alice, bob


def test_concurrent_first_transactions_do_not_error(pg):
    run, state = pg

    async def scenario():
        alice, bob = await _make_pair(state)
        factory = state["factory"]

        async def add(entered_by, other, amount):
            async with factory() as session:
                a = await session.get(User, entered_by.id)
                b = await session.get(User, other.id)
                await create_transaction(
                    session,
                    entered_by=a,
                    other=b,
                    direction=TransactionDirection.RECEIVED,
                    amount=amount,
                    status=TransactionStatus.CONFIRMED,
                )
                await session.commit()

        # Two first-ever transactions for a brand-new pair race to create
        # the same Debt row.
        await asyncio.gather(add(alice, bob, 10_000), add(bob, alice, 4_000))

        async with factory() as session:
            assert await get_debt_between(session, alice.id, bob.id, "UZS") == 6_000

    run(scenario())


def test_repayment_races_confirmation_without_deadlock(pg):
    run, state = pg

    async def scenario():
        alice, bob = await _make_pair(state)
        factory = state["factory"]

        async with factory() as session:
            a = await session.get(User, alice.id)
            b = await session.get(User, bob.id)
            await create_transaction(
                session,
                entered_by=a,
                other=b,
                direction=TransactionDirection.RECEIVED,
                amount=100_000,
                status=TransactionStatus.CONFIRMED,
            )
            pending = await create_transaction(
                session,
                entered_by=a,
                other=b,
                direction=TransactionDirection.RECEIVED,
                amount=50_000,
                status=TransactionStatus.PENDING,
            )
            await session.commit()
            pending_id = pending.id

        async def repay():
            async with factory() as session:
                a = await session.get(User, alice.id)
                b = await session.get(User, bob.id)
                await create_transaction(
                    session,
                    entered_by=a,
                    other=b,
                    direction=TransactionDirection.GIVEN,
                    amount=80_000,
                    status=TransactionStatus.REPAYMENT,
                )
                await session.commit()

        async def confirm():
            async with factory() as session:
                tx = await session.get(Transaction, pending_id)
                changed = await set_transaction_status(
                    session,
                    tx,
                    TransactionStatus.CONFIRMED,
                    expected_status=TransactionStatus.PENDING,
                )
                assert changed
                await session.commit()

        await asyncio.gather(repay(), confirm())

        async with factory() as session:
            # 100k + 50k confirmed - 80k repaid = 70k, whatever the order.
            assert await get_debt_between(session, alice.id, bob.id, "UZS") == 70_000

    run(scenario())


def test_double_repayment_cannot_overdraw(pg):
    run, state = pg

    async def scenario():
        alice, bob = await _make_pair(state)
        factory = state["factory"]

        async with factory() as session:
            a = await session.get(User, alice.id)
            b = await session.get(User, bob.id)
            await create_transaction(
                session,
                entered_by=a,
                other=b,
                direction=TransactionDirection.RECEIVED,
                amount=100_000,
                status=TransactionStatus.CONFIRMED,
            )
            await session.commit()

        async def repay(amount):
            async with factory() as session:
                a = await session.get(User, alice.id)
                b = await session.get(User, bob.id)
                try:
                    await create_transaction(
                        session,
                        entered_by=a,
                        other=b,
                        direction=TransactionDirection.GIVEN,
                        amount=amount,
                        status=TransactionStatus.REPAYMENT,
                    )
                    await session.commit()
                    return True
                except ValueError:
                    await session.rollback()
                    return False

        results = await asyncio.gather(repay(70_000), repay(70_000))
        # Exactly one 70k repayment fits into a 100k debt.
        assert sorted(results) == [False, True]

        async with factory() as session:
            assert await get_debt_between(session, alice.id, bob.id, "UZS") == 30_000

    run(scenario())


def test_delete_races_repayment_without_deadlock(pg):
    run, state = pg

    async def scenario():
        alice, bob = await _make_pair(state)
        factory = state["factory"]

        async with factory() as session:
            a = await session.get(User, alice.id)
            b = await session.get(User, bob.id)
            loan = await create_transaction(
                session,
                entered_by=a,
                other=b,
                direction=TransactionDirection.RECEIVED,
                amount=100_000,
                status=TransactionStatus.CONFIRMED,
            )
            extra = await create_transaction(
                session,
                entered_by=a,
                other=b,
                direction=TransactionDirection.RECEIVED,
                amount=20_000,
                status=TransactionStatus.CONFIRMED,
            )
            await session.commit()
            extra_id = extra.id

        async def repay():
            async with factory() as session:
                a = await session.get(User, alice.id)
                b = await session.get(User, bob.id)
                try:
                    await create_transaction(
                        session,
                        entered_by=a,
                        other=b,
                        direction=TransactionDirection.GIVEN,
                        amount=110_000,
                        status=TransactionStatus.REPAYMENT,
                    )
                    await session.commit()
                    return True
                except ValueError:
                    await session.rollback()
                    return False

        async def remove_extra():
            async with factory() as session:
                tx = await session.get(Transaction, extra_id)
                try:
                    await delete_transaction(session, tx)
                    await session.commit()
                    return True
                except ValueError:
                    await session.rollback()
                    return False

        repaid, deleted = await asyncio.gather(repay(), remove_extra())

        async with factory() as session:
            final = await get_debt_between(session, alice.id, bob.id, "UZS")
        # Whichever operation won the serialization, the ledger must stay
        # consistent and never negative:
        # both ok  -> impossible (110k repay > 100k remaining) unless repay
        #             won first (120k debt): then delete must have failed.
        assert final >= 0
        if repaid and deleted:
            pytest.fail("repayment overdraft: both operations succeeded")

    run(scenario())


def test_concurrent_wrong_pin_attempts_still_lock(pg):
    """Three simultaneous wrong PIN attempts must produce a persisted
    lockout — the row lock in register_pin_failure prevents lost updates."""
    from services import register_pin_failure
    from timezone import now_uzbekistan

    run, state = pg

    async def scenario():
        alice, _ = await _make_pair(state)
        factory = state["factory"]
        now = now_uzbekistan()

        async def fail_once():
            async with factory() as session:
                remaining = await register_pin_failure(session, alice.id, now)
                await session.commit()
                return remaining

        results = await asyncio.gather(fail_once(), fail_once(), fail_once())
        # One of them must have been the third, locking attempt.
        assert 0 in results

        async with factory() as session:
            refreshed = await session.get(User, alice.id)
            assert refreshed.pin_locked_until is not None
    run(scenario())


class _CountingBot:
    """Records sends; a small delay widens the race window."""

    def __init__(self):
        self.sent = []

    async def send_message(self, chat_id, text, **kwargs):
        await asyncio.sleep(0.05)
        self.sent.append((chat_id, text))


class _StubTelegramBot:
    """Bot-shaped client that sends JSON to the shared Telegram test stub."""

    def __init__(self, telegram_api_base_url: str):
        self.telegram_api_base_url = telegram_api_base_url

    async def send_message(self, chat_id, text, **kwargs):
        del kwargs
        request = urllib.request.Request(
            (
                f"{self.telegram_api_base_url}/bot"
                "123456:cross-service-concurrency-test-token/sendMessage"
            ),
            data=json.dumps({"chat_id": chat_id, "text": text}).encode(),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        await asyncio.to_thread(self._send, request)

    @staticmethod
    def _send(request) -> None:
        with urllib.request.urlopen(request, timeout=30) as response:
            if response.status != 200:
                raise RuntimeError(f"Telegram stub returned {response.status}")


_SCHEDULER_PROCESS_CODE = """
import asyncio
import json
import os
import urllib.request

from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

import scheduler
from db import _normalize_database_url


class ProcessBot:
    def __init__(self, telegram_api_base_url):
        self.telegram_api_base_url = telegram_api_base_url

    async def send_message(self, chat_id, text, **kwargs):
        del kwargs
        request = urllib.request.Request(
            self.telegram_api_base_url
            + "/bot123456:cross-service-concurrency-test-token/sendMessage",
            data=json.dumps({"chat_id": chat_id, "text": text}).encode(),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(request, timeout=30) as response:
            if response.status != 200:
                raise RuntimeError(f"Telegram stub returned {response.status}")


async def main():
    url, connect_args = _normalize_database_url(os.environ["DATABASE_URL"])
    engine = create_async_engine(url, connect_args=connect_args)
    factory = async_sessionmaker(engine, expire_on_commit=False)
    try:
        await scheduler.process_pending_notifications(
            ProcessBot(os.environ["TELEGRAM_API_BASE_URL"]),
            factory,
        )
    finally:
        await engine.dispose()


asyncio.run(main())
"""


def _run_fresh_scheduler_process(telegram_api_base_url: str) -> None:
    environment = os.environ.copy()
    environment.update(
        {
            "TELEGRAM_API_BASE_URL": telegram_api_base_url,
            "PYTHONPATH": str(ROOT / "telegram-debt-bot"),
        }
    )
    result = subprocess.run(
        [sys.executable, "-c", _SCHEDULER_PROCESS_CODE],
        cwd=ROOT / "telegram-debt-bot",
        env=environment,
        capture_output=True,
        text=True,
        timeout=120,
    )
    if result.returncode != 0:
        details = "\n".join(part for part in (result.stdout, result.stderr) if part)
        pytest.fail(f"Fresh scheduler process failed:\n{details}")


class _FailingBot:
    """Fails every Telegram request so the durable retry limit is exercised."""

    def __init__(self):
        self.attempts = []

    async def send_message(self, chat_id, text, **kwargs):
        self.attempts.append((chat_id, text))
        raise RuntimeError("temporary Telegram outage")


async def _api_enqueue_pending_notification(session, entered_by, other) -> int:
    """Create the same pending transaction and queue row as the API route.

    This deliberately uses PostgreSQL SQL rather than the bot's service helper:
    the test must verify that the API writer and the bot reader share the
    database contract, including the unique queue row.
    """
    transaction_id = (
        await session.execute(
            text(
                """
                INSERT INTO transactions
                    (debtor_id, creditor_id, entered_by_id, scope_chat_id,
                     amount, currency, direction, status, note, created_at)
                VALUES (:debtor_id, :creditor_id, :entered_by_id, 0,
                        :amount, 'UZS', 'received', 'pending', NULL, NOW())
                RETURNING id
                """
            ),
            {
                "debtor_id": entered_by.id,
                "creditor_id": other.id,
                "entered_by_id": entered_by.id,
                "amount": 50_000,
            },
        )
    ).scalar_one()
    await session.execute(
        text(
            """
            INSERT INTO pending_notifications
                (transaction_id, recipient_telegram_id, kind,
                 next_attempt_at, status)
            VALUES (:transaction_id, :recipient_telegram_id, 'debt',
                    CURRENT_TIMESTAMP, 'pending')
            ON CONFLICT (transaction_id) DO NOTHING
            """
        ),
        {
            "transaction_id": transaction_id,
            "recipient_telegram_id": other.telegram_id,
        },
    )
    await session.commit()
    return transaction_id


async def _api_enqueue_pending_repayment_notification(
    session, debtor, creditor
) -> int:
    """Create the repayment row consumed by the API resend route."""
    transaction_id = (
        await session.execute(
            text(
                """
                INSERT INTO transactions
                    (debtor_id, creditor_id, entered_by_id, scope_chat_id,
                     amount, currency, direction, status, note, created_at)
                VALUES (:debtor_id, :creditor_id, :entered_by_id, 0,
                        :amount, 'UZS', 'given', 'repayment_pending',
                        'Cross-service delivery race', NOW())
                RETURNING id
                """
            ),
            {
                "debtor_id": debtor.id,
                "creditor_id": creditor.id,
                "entered_by_id": creditor.id,
                "amount": 30_000,
            },
        )
    ).scalar_one()
    await session.execute(
        text(
            """
            INSERT INTO pending_notifications
                (transaction_id, recipient_telegram_id, kind,
                 next_attempt_at, status)
            VALUES (:transaction_id, :recipient_telegram_id, 'repayment',
                    CURRENT_TIMESTAMP, 'pending')
            """
        ),
        {
            "transaction_id": transaction_id,
            "recipient_telegram_id": debtor.telegram_id,
        },
    )
    await session.commit()
    return transaction_id


def _session_token(user_id: int) -> str:
    claims = {
        "sub": user_id,
        "exp": int(time.time()) + 3600,
        "pinUntil": None,
    }
    encoded = base64.urlsafe_b64encode(
        json.dumps(claims, separators=(",", ":")).encode()
    ).rstrip(b"=")
    signature = hmac.new(
        TEST_SESSION_SECRET.encode(),
        encoded,
        hashlib.sha256,
    ).digest()
    encoded_signature = base64.urlsafe_b64encode(signature).rstrip(b"=")
    return f"{encoded.decode()}.{encoded_signature.decode()}"


def _post(base_url: str, path: str, token: str) -> tuple[int, dict]:
    request = urllib.request.Request(
        f"{base_url}{path}",
        headers={"Authorization": f"Bearer {token}"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            return response.status, json.loads(response.read())
    except urllib.error.HTTPError as error:
        return error.code, json.loads(error.read())


def _get(base_url: str, path: str, token: str) -> tuple[int, dict]:
    request = urllib.request.Request(
        f"{base_url}{path}",
        headers={"Authorization": f"Bearer {token}"},
        method="GET",
    )
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            return response.status, json.loads(response.read())
    except urllib.error.HTTPError as error:
        return error.code, json.loads(error.read())


@contextmanager
def _telegram_api_stub(
    response_status: int | Callable[[], int] = 200,
) -> Iterator[tuple[str, list[dict]]]:
    requests: list[dict] = []
    requests_lock = threading.Lock()

    class TelegramStubHandler(BaseHTTPRequestHandler):
        def do_POST(self) -> None:
            if self.headers.get("Transfer-Encoding", "").lower() == "chunked":
                body_parts = []
                while True:
                    chunk_size = int(self.rfile.readline().split(b";", 1)[0], 16)
                    if chunk_size == 0:
                        while self.rfile.readline() not in (b"\r\n", b"\n"):
                            pass
                        break
                    body_parts.append(self.rfile.read(chunk_size))
                    self.rfile.read(2)
                body = b"".join(body_parts)
            else:
                content_length = int(self.headers.get("Content-Length", "0"))
                body = self.rfile.read(content_length)
            if self.headers.get("Content-Type", "").startswith("application/json"):
                payload = json.loads(body)
            else:
                payload = {
                    "path": self.path,
                    "content_type": self.headers.get("Content-Type", ""),
                }
            status = response_status() if callable(response_status) else response_status
            with requests_lock:
                requests.append(payload)
            # Keep the winner in flight long enough for the other process to
            # reach its database claim instead of serializing at the stub.
            time.sleep(0.1)
            response_body = json.dumps(
                {"ok": True, "result": {"message_id": 1}}
                if status == 200
                else {"ok": False, "description": "temporary Telegram outage"}
            ).encode()
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(response_body)))
            self.end_headers()
            self.wfile.write(response_body)

        def log_message(self, format: str, *args: object) -> None:
            del format, args

    server = ThreadingHTTPServer(("127.0.0.1", 0), TelegramStubHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield f"http://127.0.0.1:{server.server_port}", requests
    finally:
        server.shutdown()
        thread.join(timeout=5)
        server.server_close()


@contextmanager
def _running_api_server(telegram_api_base_url: str) -> Iterator[str]:
    probe = __import__("socket").socket()
    probe.bind(("127.0.0.1", 0))
    port = probe.getsockname()[1]
    probe.close()

    environment = os.environ.copy()
    environment.update(
        {
            "NODE_ENV": "development",
            "PORT": str(port),
            "SESSION_SECRET": TEST_SESSION_SECRET,
            "TELEGRAM_BOT_TOKEN": "123456:cross-service-concurrency-test-token",
            "TELEGRAM_API_BASE_URL": telegram_api_base_url,
        }
    )
    process = subprocess.Popen(
        ["pnpm", "--filter", "@workspace/api-server", "run", "dev"],
        cwd=ROOT,
        env=environment,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.STDOUT,
    )
    base_url = f"http://127.0.0.1:{port}"
    deadline = time.monotonic() + 120
    try:
        while time.monotonic() < deadline:
            if process.poll() is not None:
                raise RuntimeError("API server exited before becoming healthy")
            try:
                with urllib.request.urlopen(f"{base_url}/api/healthz", timeout=2) as response:
                    if response.status == 200:
                        break
            except (urllib.error.URLError, TimeoutError):
                time.sleep(0.25)
        else:
            raise RuntimeError("API server did not become healthy within 120 seconds")
        yield base_url
    finally:
        if process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=10)


async def _api_decide_pending_notification(session, transaction_id, status: str) -> None:
    """Apply the API decision's status update and queue cancellation together."""
    await session.execute(
        text("UPDATE transactions SET status = :status WHERE id = :transaction_id"),
        {"status": status, "transaction_id": transaction_id},
    )
    await session.execute(
        text("DELETE FROM pending_notifications WHERE transaction_id = :transaction_id"),
        {"transaction_id": transaction_id},
    )
    await session.commit()


async def _make_notification_due(session_factory, transaction_id: int) -> None:
    async with session_factory() as session:
        await session.execute(
            text(
                """
                UPDATE pending_notifications
                SET next_attempt_at = CURRENT_TIMESTAMP - INTERVAL '1 second'
                WHERE transaction_id = :transaction_id
                """
            ),
            {"transaction_id": transaction_id},
        )
        await session.commit()


async def _make_api_pending_transaction(state) -> tuple[object, object, int]:
    factory = state["factory"]
    alice, bob = await _make_pair(state)
    async with factory() as session:
        transaction_id = await _api_enqueue_pending_notification(session, alice, bob)
    return alice, bob, transaction_id


def test_api_queue_and_bot_workers_share_atomic_claims(pg):
    """API-created work is delivered at most once across concurrent bot workers."""
    import scheduler

    run, state = pg

    async def scenario():
        alice, bob, transaction_id = await _make_api_pending_transaction(state)
        factory = state["factory"]
        bot1, bot2 = _CountingBot(), _CountingBot()

        await asyncio.gather(
            scheduler.process_pending_notifications(bot1, factory),
            scheduler.process_pending_notifications(bot2, factory),
        )

        assert len(bot1.sent) + len(bot2.sent) == 1
        assert (bot1.sent + bot2.sent)[0][0] == bob.telegram_id
        async with factory() as session:
            notification = (
                await session.execute(
                    select(PendingNotification).where(
                        PendingNotification.transaction_id == transaction_id
                    )
                )
            ).scalar_one()
            assert notification.attempt_count == 1
            assert notification.status == PendingNotificationStatus.SENT
            transaction = await session.get(Transaction, transaction_id)
            assert transaction.status == TransactionStatus.PENDING

    run(scenario())


def test_api_and_bot_workers_share_atomic_claims(pg):
    """The real API and bot paths must send one shared repayment notification."""
    import scheduler

    run, state = pg

    async def scenario():
        debtor, creditor = await _make_pair(state)
        factory = state["factory"]
        async with factory() as session:
            transaction_id = await _api_enqueue_pending_repayment_notification(
                session, debtor, creditor
            )

        with _telegram_api_stub() as (telegram_url, telegram_requests):
            with _running_api_server(telegram_url) as api_server:
                bot = _StubTelegramBot(telegram_url)
                api_request = asyncio.to_thread(
                    _post,
                    api_server,
                    f"/api/transactions/{transaction_id}/resend-notification",
                    _session_token(debtor.id),
                )
                api_result, bot_result = await asyncio.gather(
                    api_request,
                    scheduler.process_pending_notifications(bot, factory),
                )

        api_status, api_response = api_result
        assert api_status in {200, 429}
        if api_status == 200:
            assert api_response["deliveryStatus"] == "sent"
        else:
            assert api_response["code"] == "RESEND_RATE_LIMITED"
        assert len(telegram_requests) <= 1
        assert len(telegram_requests) == 1
        async with factory() as session:
            notification = (
                await session.execute(
                    select(PendingNotification).where(
                        PendingNotification.transaction_id == transaction_id
                    )
                )
            ).scalar_one()
            assert notification.attempt_count == 1
            assert notification.status == PendingNotificationStatus.SENT
            transaction = await session.get(Transaction, transaction_id)
            assert transaction.status == TransactionStatus.REPAYMENT_PENDING
        assert bot_result is None

    run(scenario())


def test_api_and_bot_workers_retry_temporary_failure_without_duplicate_delivery(pg):
    """A Telegram outage keeps one reviewable repayment retryable across services."""
    import scheduler

    run, state = pg

    async def scenario():
        debtor, creditor = await _make_pair(state)
        factory = state["factory"]
        async with factory() as session:
            transaction_id = await _api_enqueue_pending_repayment_notification(
                session, debtor, creditor
            )

        with _telegram_api_stub(response_status=503) as (
            telegram_url,
            telegram_requests,
        ):
            with _running_api_server(telegram_url) as api_server:
                bot = _StubTelegramBot(telegram_url)
                api_request = asyncio.to_thread(
                    _post,
                    api_server,
                    f"/api/transactions/{transaction_id}/resend-notification",
                    _session_token(debtor.id),
                )
                api_result, bot_result = await asyncio.gather(
                    api_request,
                    scheduler.process_pending_notifications(bot, factory),
                )

                api_status, api_response = api_result
                assert api_status in {200, 429}
                if api_status == 200:
                    assert api_response["deliveryStatus"] == "pending"
                else:
                    assert api_response["code"] == "RESEND_RATE_LIMITED"
                assert bot_result is None

                # The API makes three transient attempts if it wins the claim;
                # the bot makes one if it wins. Either outcome is one durable
                # attempt, never two concurrent claims.
                assert len(telegram_requests) in {1, 3}
                first_wave_request_count = len(telegram_requests)
                async with factory() as session:
                    notification = (
                        await session.execute(
                            select(PendingNotification).where(
                                PendingNotification.transaction_id == transaction_id
                            )
                        )
                    ).scalar_one()
                    assert notification.attempt_count == 1
                    assert notification.status == PendingNotificationStatus.PENDING
                    assert notification.last_error is not None
                    transaction = await session.get(Transaction, transaction_id)
                    assert transaction.status == TransactionStatus.REPAYMENT_PENDING

                review_status, review_transactions = _get(
                    api_server,
                    "/api/transactions",
                    _session_token(debtor.id),
                )
                assert review_status == 200
                reviewable = next(
                    transaction
                    for transaction in review_transactions
                    if transaction["id"] == transaction_id
                )
                assert reviewable["status"] == "repayment_pending"
                assert reviewable["deliveryStatus"] == "pending"

                await _make_notification_due(factory, transaction_id)
                await scheduler.process_pending_notifications(bot, factory)

                # The next retry is also one bot claim, and the outage means
                # no successful Telegram delivery can be recorded.
                assert len(telegram_requests) == first_wave_request_count + 1
                async with factory() as session:
                    notification = (
                        await session.execute(
                            select(PendingNotification).where(
                                PendingNotification.transaction_id == transaction_id
                            )
                        )
                    ).scalar_one()
                    assert notification.attempt_count == 2
                    assert notification.status == PendingNotificationStatus.PENDING
                    assert notification.last_error is not None
                    transaction = await session.get(Transaction, transaction_id)
                    assert transaction.status == TransactionStatus.REPAYMENT_PENDING

    run(scenario())


def test_api_and_bot_workers_recover_after_temporary_failure(pg):
    """A later scheduler retry delivers one recovered repayment notification."""
    import scheduler

    run, state = pg

    async def scenario():
        debtor, creditor = await _make_pair(state)
        factory = state["factory"]
        async with factory() as session:
            transaction_id = await _api_enqueue_pending_repayment_notification(
                session, debtor, creditor
            )

        telegram_available = False
        with _telegram_api_stub(
            response_status=lambda: 200 if telegram_available else 503
        ) as (
            telegram_url,
            telegram_requests,
        ):
            with _running_api_server(telegram_url) as api_server:
                bot = _StubTelegramBot(telegram_url)
                api_request = asyncio.to_thread(
                    _post,
                    api_server,
                    f"/api/transactions/{transaction_id}/resend-notification",
                    _session_token(debtor.id),
                )
                api_result, bot_result = await asyncio.gather(
                    api_request,
                    scheduler.process_pending_notifications(bot, factory),
                )

                api_status, api_response = api_result
                assert api_status in {200, 429}
                if api_status == 200:
                    assert api_response["deliveryStatus"] == "pending"
                else:
                    assert api_response["code"] == "RESEND_RATE_LIMITED"
                assert bot_result is None

                # The outage affects the initial API/bot race. Depending on
                # which service claims first, the API may make its bounded
                # retries after the bot has claimed and released the row.
                assert len(telegram_requests) in {1, 3, 4}
                initial_request_count = len(telegram_requests)
                async with factory() as session:
                    notification = (
                        await session.execute(
                            select(PendingNotification).where(
                                PendingNotification.transaction_id == transaction_id
                            )
                        )
                    ).scalar_one()
                    initial_attempt_count = notification.attempt_count
                    assert initial_attempt_count in {1, 2}
                    assert notification.status == PendingNotificationStatus.PENDING
                    assert notification.last_error is not None
                    transaction = await session.get(Transaction, transaction_id)
                    assert transaction.status == TransactionStatus.REPAYMENT_PENDING

                telegram_available = True
                await _make_notification_due(factory, transaction_id)
                await scheduler.process_pending_notifications(bot, factory)

                # Recovery is one successful scheduler request, not a second
                # send from either service.
                assert len(telegram_requests) == initial_request_count + 1
                async with factory() as session:
                    notification = (
                        await session.execute(
                            select(PendingNotification).where(
                                PendingNotification.transaction_id == transaction_id
                            )
                        )
                    ).scalar_one()
                    assert notification.attempt_count == initial_attempt_count + 1
                    assert notification.status == PendingNotificationStatus.SENT
                    assert notification.last_error is None
                    transaction = await session.get(Transaction, transaction_id)
                    assert transaction.status == TransactionStatus.REPAYMENT_PENDING

                review_status, review_transactions = _get(
                    api_server,
                    "/api/transactions",
                    _session_token(debtor.id),
                )
                assert review_status == 200
                reviewable = next(
                    transaction
                    for transaction in review_transactions
                    if transaction["id"] == transaction_id
                )
                assert reviewable["status"] == "repayment_pending"
                assert reviewable["deliveryStatus"] == "sent"

                await scheduler.process_pending_notifications(bot, factory)
                assert len(telegram_requests) == initial_request_count + 1

        async with factory() as session:
            transaction = await session.get(Transaction, transaction_id)
            assert transaction.status == TransactionStatus.REPAYMENT_PENDING

    run(scenario())


def test_fresh_scheduler_process_recovers_after_telegram_outage(pg):
    """A replacement bot process retries the durable repayment notification."""
    run, state = pg

    async def scenario():
        debtor, creditor = await _make_pair(state)
        factory = state["factory"]
        async with factory() as session:
            transaction_id = await _api_enqueue_pending_repayment_notification(
                session, debtor, creditor
            )

        telegram_available = False
        with _telegram_api_stub(
            response_status=lambda: 200 if telegram_available else 503
        ) as (telegram_url, telegram_requests):
            # This process represents the bot that was running during the
            # outage. It exits after its scheduler pass, before recovery.
            _run_fresh_scheduler_process(telegram_url)
            assert len(telegram_requests) == 1
            async with factory() as session:
                notification = (
                    await session.execute(
                        select(PendingNotification).where(
                            PendingNotification.transaction_id == transaction_id
                        )
                    )
                ).scalar_one()
                assert notification.attempt_count == 1
                assert notification.status == PendingNotificationStatus.PENDING
                assert notification.last_error is not None
                assert "503" in notification.last_error
                transaction = await session.get(Transaction, transaction_id)
                assert transaction.status == TransactionStatus.REPAYMENT_PENDING

            telegram_available = True
            await _make_notification_due(factory, transaction_id)

            # A new process reads the same row after the outage has cleared.
            _run_fresh_scheduler_process(telegram_url)
            assert len(telegram_requests) == 2
            async with factory() as session:
                notification = (
                    await session.execute(
                        select(PendingNotification).where(
                            PendingNotification.transaction_id == transaction_id
                        )
                    )
                ).scalar_one()
                assert notification.attempt_count == 2
                assert notification.status == PendingNotificationStatus.SENT
                assert notification.last_error is None
                transaction = await session.get(Transaction, transaction_id)
                assert transaction.status == TransactionStatus.REPAYMENT_PENDING

            # A sent row is not eligible for another fresh scheduler process.
            _run_fresh_scheduler_process(telegram_url)
            assert len(telegram_requests) == 2

    run(scenario())


@pytest.mark.parametrize(
    ("decision", "expected_status"),
    [("confirmed", TransactionStatus.CONFIRMED), ("rejected", TransactionStatus.REJECTED)],
)
def test_api_decision_cancels_bot_delivery_after_claim(pg, decision, expected_status):
    """A decision racing a claimed bot row prevents the stale Telegram send."""
    import scheduler

    run, state = pg

    async def scenario():
        _, _, transaction_id = await _make_api_pending_transaction(state)
        factory = state["factory"]

        # The bot has claimed the row but has not started its network request.
        claim = await scheduler._claim_pending_notification(factory, transaction_id)
        assert claim is not None

        async with factory() as session:
            await _api_decide_pending_notification(session, transaction_id, decision)

        bot = _CountingBot()
        result = await scheduler._deliver_claimed_pending_notification(
            bot, factory, claim
        )
        assert result == "cancelled"
        assert bot.sent == []

        # A later scheduler pass cannot resurrect work canceled by the API.
        await scheduler.process_pending_notifications(bot, factory)
        assert bot.sent == []
        async with factory() as session:
            assert await session.get(PendingNotification, claim["id"]) is None
            transaction = await session.get(Transaction, transaction_id)
            assert transaction.status == expected_status

    run(scenario())


def test_api_failed_delivery_reaches_bounded_failure_without_hiding_transaction(pg):
    """Repeated bot failures become terminal while /pending remains reviewable."""
    import scheduler

    run, state = pg

    async def scenario():
        _, _, transaction_id = await _make_api_pending_transaction(state)
        factory = state["factory"]
        bot = _FailingBot()

        for _ in range(scheduler.PENDING_NOTIFICATION_MAX_ATTEMPTS):
            async with factory() as session:
                await session.execute(
                    text(
                        """
                        UPDATE pending_notifications
                        SET next_attempt_at = CURRENT_TIMESTAMP - INTERVAL '1 second'
                        WHERE transaction_id = :transaction_id
                        """
                    ),
                    {"transaction_id": transaction_id},
                )
                await session.commit()
            await scheduler.deliver_pending_notification(
                bot, factory, transaction_id
            )

        async with factory() as session:
            notification = (
                await session.execute(
                    select(PendingNotification).where(
                        PendingNotification.transaction_id == transaction_id
                    )
                )
            ).scalar_one()
            assert notification.attempt_count == scheduler.PENDING_NOTIFICATION_MAX_ATTEMPTS
            assert notification.status == PendingNotificationStatus.PERMANENT_FAILURE
            assert notification.last_error == "temporary Telegram outage"
            transaction = await session.get(Transaction, transaction_id)
            assert transaction.status == TransactionStatus.PENDING

        # The terminal row is bounded: an additional worker pass does not send.
        await scheduler.process_pending_notifications(bot, factory)
        assert len(bot.attempts) == scheduler.PENDING_NOTIFICATION_MAX_ATTEMPTS

    run(scenario())


def test_concurrent_schedulers_send_each_reminder_once(pg):
    """Two bot instances running process_due_reminders simultaneously must
    deliver exactly one reminder per recipient (ReminderLog unique row)."""
    import scheduler
    from datetime import date

    run, state = pg

    async def scenario():
        alice, bob = await _make_pair(state)
        factory = state["factory"]
        today = date(2026, 8, 14)

        async with factory() as session:
            a = await session.get(User, alice.id)
            b = await session.get(User, bob.id)
            await create_transaction(
                session,
                entered_by=a,
                other=b,
                direction=TransactionDirection.RECEIVED,
                amount=90_000,
                status=TransactionStatus.CONFIRMED,
                due_date=today,
            )
            await session.commit()

        bot1, bot2 = _CountingBot(), _CountingBot()
        await asyncio.gather(
            scheduler.process_due_reminders(bot1, factory, today),
            scheduler.process_due_reminders(bot2, factory, today),
        )

        all_sent = bot1.sent + bot2.sent
        # Exactly one message to the debtor and one to the creditor,
        # across both instances combined.
        recipients = sorted(chat_id for chat_id, _ in all_sent)
        assert recipients == sorted([alice.telegram_id, bob.telegram_id])

    run(scenario())


def test_concurrent_schedulers_send_report_once(pg):
    """Two simultaneous process_periodic_reports runs: the atomic
    report_last_sent claim lets only one instance send today's report."""
    import scheduler
    from datetime import date

    run, state = pg

    async def scenario():
        alice, _ = await _make_pair(state)
        factory = state["factory"]
        monday = date(2026, 8, 10)

        async with factory() as session:
            a = await session.get(User, alice.id)
            a.report_frequency = ReportFrequency.WEEKLY
            await session.commit()

        bot1, bot2 = _CountingBot(), _CountingBot()
        await asyncio.gather(
            scheduler.process_periodic_reports(bot1, factory, monday),
            scheduler.process_periodic_reports(bot2, factory, monday),
        )

        all_sent = [
            (c, t)
            for c, t in bot1.sent + bot2.sent
            if c == alice.telegram_id
        ]
        assert len(all_sent) == 1

        async with factory() as session:
            refreshed = await session.get(User, alice.id)
            assert refreshed.report_last_sent == monday

    run(scenario())
