"""Unit tests for the quick-add command parser and contact lookup."""

import pytest

from services import parse_quick_entry


def test_basic_amount_and_username():
    entry = parse_quick_entry("50000 @ali izoh matni")
    assert entry.amount == 50_000
    assert entry.currency == "UZS"
    assert entry.username == "ali"
    assert entry.note == "izoh matni"


def test_currency_specified():
    entry = parse_quick_entry("100 USD @ali tushlik")
    assert entry.amount == 100
    assert entry.currency == "USD"
    assert entry.username == "ali"
    assert entry.note == "tushlik"


def test_username_anywhere_and_no_note():
    entry = parse_quick_entry("5000 taksi puli @vali")
    assert entry.username == "vali"
    assert entry.note == "taksi puli"

    entry2 = parse_quick_entry("5000 @vali")
    assert entry2.username == "vali"
    assert entry2.note is None


def test_no_username_group_style():
    entry = parse_quick_entry("7000 non uchun")
    assert entry.username is None
    assert entry.note == "non uchun"
    assert entry.currency == "UZS"


def test_amount_with_separators():
    assert parse_quick_entry("1,000,000 @a").amount == 1_000_000


def test_only_uppercase_token_is_currency():
    # Lowercase 3-letter words are ordinary note words, not currencies.
    entry = parse_quick_entry("100 eur @a")
    assert entry.currency == "UZS"
    assert entry.note == "eur"
    assert parse_quick_entry("100 EUR @a").currency == "EUR"


def test_error_message_escapes_html():
    with pytest.raises(ValueError) as exc:
        parse_quick_entry("<b>x</b> @user")
    text = str(exc.value)
    assert "<b>" not in text.replace("<code>", "").replace("</code>", "")
    assert "&lt;b&gt;" in text


def test_errors():
    with pytest.raises(ValueError):
        parse_quick_entry("")
    with pytest.raises(ValueError):
        parse_quick_entry("abc @user")
    with pytest.raises(ValueError):
        parse_quick_entry("-5 @user")
    with pytest.raises(ValueError):
        parse_quick_entry("0 @user")
