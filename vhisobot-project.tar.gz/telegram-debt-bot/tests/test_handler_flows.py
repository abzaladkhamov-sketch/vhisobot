"""Handler-level integration tests for the main bot flows.

Covers with a mock Bot/Message stack over in-memory SQLite:
- PIN guard: private chats demand a PIN, group views bypass it
- Pending action dispatch after a successful PIN unlock
- Quick /oldim errors (unknown @username, no contacts) and group reply flow
- Transaction confirm/reject callbacks, including wrong-user and
  already-handled guards
"""

import asyncio
import hashlib

import pytest
from aiogram.filters import CommandObject
from sqlalchemy import select
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

import handlers
import pin as pin_module
from models import (
    Base,
    Transaction,
    TransactionDirection,
    TransactionHistoryHide,
    TransactionStatus,
    User,
    WebAccessCode,
)
from pin import hash_pin
from services import (
    create_transaction,
    get_pending_confirmations,
    get_transaction,
    link_users,
)


class FakeTelegramUser:
    def __init__(self, telegram_id, username=None, first_name="User"):
        self.id = telegram_id
        self.username = username
        self.first_name = first_name
        self.last_name = None
        self.is_bot = False


class FakeChat:
    def __init__(self, chat_type="private", chat_id=1000):
        self.type = chat_type
        self.id = chat_id


class FakeMessage:
    def __init__(self, from_user=None, chat=None, text=None, reply_to=None):
        self.from_user = from_user
        self.chat = chat or FakeChat()
        self.text = text
        self.reply_to_message = reply_to
        self.answers = []
        self.answer_kwargs = []
        self.edits = []
        self.edit_kwargs = []
        self.deleted = False

    async def answer(self, text, **kwargs):
        self.answers.append(text)
        self.answer_kwargs.append(kwargs)

    async def edit_text(self, text, **kwargs):
        self.edits.append(text)
        self.edit_kwargs.append(kwargs)

    async def delete(self):
        self.deleted = True


class FakeCallback:
    def __init__(self, telegram_id, data, chat_type="private", chat_id=1000):
        self.from_user = FakeTelegramUser(telegram_id)
        self.data = data
        self.message = FakeMessage(chat=FakeChat(chat_type, chat_id))
        self.answered = []

    async def answer(self, text=None, **kwargs):
        self.answered.append(text)


class FakeState:
    def __init__(self):
        self.state = None
        self.data = {}

    async def set_state(self, state):
        self.state = state

    async def update_data(self, **kwargs):
        self.data.update(kwargs)

    async def get_data(self):
        return dict(self.data)

    async def clear(self):
        self.state = None
        self.data = {}


class FakeBot:
    """Records outgoing messages; can simulate delivery failures."""

    def __init__(self, fail_with=None):
        self.sent = []  # (chat_id, text, reply_markup)
        self.fail_with = fail_with

    async def send_message(self, chat_id, text, **kwargs):
        if self.fail_with is not None:
            raise self.fail_with
        self.sent.append((chat_id, text, kwargs.get("reply_markup")))

    async def get_me(self):
        class Me:
            username = "debt_test_bot"
            first_name = "DebtBot"

        return Me()


def quick_command(args):
    return CommandObject(prefix="/", command="oldim", args=args)


@pytest.fixture()
def db():
    loop = asyncio.new_event_loop()
    engine = create_async_engine("sqlite+aiosqlite://")

    async def setup():
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
        return async_sessionmaker(engine, expire_on_commit=False)

    factory = loop.run_until_complete(setup())
    yield loop.run_until_complete, factory
    loop.run_until_complete(engine.dispose())
    loop.close()


async def _make_users(session, *, with_pin=False):
    alice = User(
        telegram_id=111,
        username="alice",
        first_name="Alice",
        pin_hash=hash_pin("1234") if with_pin else None,
    )
    bob = User(telegram_id=222, username="bob", first_name="Bob")
    session.add_all([alice, bob])
    await session.flush()
    await link_users(session, alice, bob)
    await session.commit()
    return alice, bob


def test_web_command_issues_hashed_one_time_code(db):
    """The Telegram command must return a usable code without storing it raw."""
    run, factory = db

    async def scenario():
        async with factory() as session:
            alice, _ = await _make_users(session)
            message = FakeMessage(
                from_user=FakeTelegramUser(111, "alice", "Alice"),
                chat=FakeChat("private"),
            )

            await handlers.web_access_handler(message, session)

            code = next(
                part for part in message.answers[-1].split("<code>", 1)[1].split("</code>", 1)
                if part
            )
            record = (
                await session.execute(
                    select(WebAccessCode).where(WebAccessCode.user_id == alice.id)
                )
            ).scalar_one()
            assert len(code) == 8
            assert record.code_hash == hashlib.sha256(code.encode("utf-8")).hexdigest()
            assert record.code_hash != code
            assert record.used_at is None
            assert 590 <= (record.expires_at - record.created_at).total_seconds() <= 610

    run(scenario())


def test_web_command_never_issues_code_in_a_group(db):
    run, factory = db

    async def scenario():
        async with factory() as session:
            await _make_users(session)
            message = FakeMessage(
                from_user=FakeTelegramUser(111, "alice", "Alice"),
                chat=FakeChat("group"),
            )

            await handlers.web_access_handler(message, session)

            codes = (
                await session.execute(select(WebAccessCode))
            ).scalars().all()
            assert codes == []
            assert len(message.answers) == 1
            assert "<code>" not in message.answers[0]
            assert "shaxsiy chat" in message.answers[0]

    run(scenario())


# ---------------------------------------------------------------- PIN guard


def test_balance_private_with_pin_prompts_for_pin(db):
    run, factory = db

    async def scenario():
        async with factory() as session:
            alice, _ = await _make_users(session, with_pin=True)
            pin_module.pin_gate.lock(alice.id)

            message = FakeMessage(
                from_user=FakeTelegramUser(111, "alice", "Alice"),
                chat=FakeChat("private"),
            )
            state = FakeState()
            await handlers.balance_handler(message, state, session)

            assert state.state is handlers.PinStates.waiting_for_unlock
            assert state.data.get("pin_pending") == "balance"
            assert any("PIN" in text for text in message.answers)
            # Balance itself must NOT be rendered.
            assert not any("balans" in t.lower() for t in message.answers)

    run(scenario())


def test_balance_in_group_bypasses_pin(db):
    run, factory = db

    async def scenario():
        async with factory() as session:
            alice, _ = await _make_users(session, with_pin=True)
            pin_module.pin_gate.lock(alice.id)

            message = FakeMessage(
                from_user=FakeTelegramUser(111, "alice", "Alice"),
                chat=FakeChat("group", -500),
            )
            state = FakeState()
            await handlers.balance_handler(message, state, session)

            # No PIN prompt in groups — the (empty) balance is shown.
            assert state.state is None
            assert message.answers == ["Hozircha faol qarzlar yo'q."]

    run(scenario())


# -------------------------------------------- PIN unlock: pending dispatch


def test_correct_pin_unlocks_and_dispatches_balance(db):
    run, factory = db

    async def scenario():
        async with factory() as session:
            alice, _ = await _make_users(session, with_pin=True)
            pin_module.pin_gate.lock(alice.id)
            try:
                message = FakeMessage(
                    from_user=FakeTelegramUser(111, "alice", "Alice"),
                    chat=FakeChat("private"),
                    text="1234",
                )
                state = FakeState()
                await state.set_state(handlers.PinStates.waiting_for_unlock)
                await state.update_data(pin_pending="balance")

                await handlers.pin_unlock_handler(message, state, session)

                assert message.deleted  # the PIN never stays in the chat
                assert pin_module.pin_gate.is_unlocked(alice.id)
                assert state.state is None
                assert any("Ochildi" in t for t in message.answers)
                # Pending action was dispatched: balance rendered.
                assert message.answers[-1] == "Hozircha faol qarzlar yo'q."
            finally:
                pin_module.pin_gate.lock(alice.id)

    run(scenario())


def test_correct_pin_dispatches_history(db):
    run, factory = db

    async def scenario():
        async with factory() as session:
            alice, _ = await _make_users(session, with_pin=True)
            pin_module.pin_gate.lock(alice.id)
            try:
                message = FakeMessage(
                    from_user=FakeTelegramUser(111, "alice", "Alice"),
                    chat=FakeChat("private"),
                    text="1234",
                )
                state = FakeState()
                await state.set_state(handlers.PinStates.waiting_for_unlock)
                await state.update_data(pin_pending="history")

                await handlers.pin_unlock_handler(message, state, session)

                # History contact picker was shown after unlock.
                assert any("tarixni" in t for t in message.answers)
                assert state.state is handlers.HistoryStates.waiting_for_contact
            finally:
                pin_module.pin_gate.lock(alice.id)

    run(scenario())


def test_wrong_pin_counts_attempts_and_keeps_gate_locked(db):
    run, factory = db

    async def scenario():
        async with factory() as session:
            alice, _ = await _make_users(session, with_pin=True)
            pin_module.pin_gate.lock(alice.id)

            state = FakeState()
            await state.set_state(handlers.PinStates.waiting_for_unlock)
            await state.update_data(pin_pending="balance")

            message = FakeMessage(
                from_user=FakeTelegramUser(111, "alice", "Alice"),
                chat=FakeChat("private"),
                text="9999",
            )
            await handlers.pin_unlock_handler(message, state, session)

            assert not pin_module.pin_gate.is_unlocked(alice.id)
            assert any("noto'g'ri" in t for t in message.answers)
            # Still waiting for the PIN; pending action not dispatched.
            assert state.state is handlers.PinStates.waiting_for_unlock

    run(scenario())


# ------------------------------------------------------- quick /oldim flow


def test_quick_oldim_unknown_username_lists_contacts(db):
    run, factory = db

    async def scenario():
        async with factory() as session:
            await _make_users(session)

            message = FakeMessage(
                from_user=FakeTelegramUser(111, "alice", "Alice"),
                chat=FakeChat("private"),
            )
            bot = FakeBot()
            await handlers.quick_received_handler(
                message, quick_command("50000 @ghost"), session, bot
            )

            assert len(message.answers) == 1
            assert "topilmadi" in message.answers[0]
            assert "@bob" in message.answers[0]  # existing contacts listed
            assert bot.sent == []

    run(scenario())


def test_quick_oldim_without_contacts_suggests_invite(db):
    run, factory = db

    async def scenario():
        async with factory() as session:
            lonely = User(telegram_id=333, username="carol", first_name="Carol")
            session.add(lonely)
            await session.commit()

            message = FakeMessage(
                from_user=FakeTelegramUser(333, "carol", "Carol"),
                chat=FakeChat("private"),
            )
            await handlers.quick_received_handler(
                message, quick_command("50000 @ghost"), session, FakeBot()
            )

            assert any("kontaktlaringiz yo'q" in t for t in message.answers)

    run(scenario())


def test_quick_oldim_group_reply_creates_pending_and_notifies(db):
    run, factory = db

    async def scenario():
        async with factory() as session:
            alice, bob = await _make_users(session)

            reply = FakeMessage(
                from_user=FakeTelegramUser(222, "bob", "Bob"),
                chat=FakeChat("group", -500),
            )
            message = FakeMessage(
                from_user=FakeTelegramUser(111, "alice", "Alice"),
                chat=FakeChat("group", -500),
                reply_to=reply,
            )
            bot = FakeBot()
            await handlers.quick_received_handler(
                message, quick_command("50000 qarz"), session, bot
            )

            # Bob got the confirmation request with a keyboard.
            assert len(bot.sent) == 1
            chat_id, text, markup = bot.sent[0]
            assert chat_id == 222
            assert "tasdiqlash" in text
            assert markup is not None
            # Alice got the summary; balance waits for confirmation.
            assert any("Saqlandi" in t for t in message.answers)
            assert any("tasdiqlagach" in t for t in message.answers)

            tx = await get_transaction(session, 1)
            assert tx is not None
            assert tx.status == TransactionStatus.PENDING
            assert tx.scope_chat_id == -500
            assert tx.debtor_id == alice.id
            assert tx.creditor_id == bob.id

    run(scenario())


# ------------------------------------------------- confirm/reject callbacks


async def _pending_tx(session, alice, bob):
    tx = await create_transaction(
        session,
        entered_by=alice,
        other=bob,
        direction=TransactionDirection.RECEIVED,
        amount=50000,
        status=TransactionStatus.PENDING,
    )
    await session.commit()
    return tx


def test_step_by_step_add_reviews_before_creating(db):
    run, factory = db

    async def scenario():
        async with factory() as session:
            alice, bob = await _make_users(session)
            state = FakeState()
            await state.set_state(handlers.AddDebtStates.waiting_for_due_date)
            await state.update_data(
                contact_id=bob.id,
                direction=TransactionDirection.RECEIVED.value,
                amount=50000,
                currency="UZS",
                note="Sinov",
            )
            message = FakeMessage(
                from_user=FakeTelegramUser(111, "alice", "Alice"),
                chat=FakeChat("private"),
                text="31.12.2026",
            )
            bot = FakeBot()

            await handlers.due_date_handler(message, state, session, bot)

            assert await get_transaction(session, 1) is None
            assert state.state is handlers.AddDebtStates.waiting_for_confirmation
            assert any("Yuborishdan oldingi xulosa" in text for text in message.answers)
            assert any("50 000 UZS" in text for text in message.answers)
            assert any("Balans faqat" in text for text in message.answers)

            nonce = (await state.get_data())["confirmation_nonce"]
            callback = FakeCallback(111, f"add:confirm:{nonce}")
            await handlers.add_confirm_callback(callback, state, session, bot)

            transaction = await get_transaction(session, 1)
            assert transaction is not None
            assert transaction.status == TransactionStatus.PENDING
            assert transaction.debtor_id == alice.id
            assert transaction.creditor_id == bob.id
            assert state.state is None
            assert any("Qarz so'rovi yuborildi" in text for text in callback.message.edits)
            assert len(bot.sent) == 1

    run(scenario())


def test_step_by_step_add_confirmation_is_single_use_under_concurrency(db):
    run, factory = db

    async def scenario():
        async with factory() as session:
            alice, bob = await _make_users(session)
            state = FakeState()
            await state.set_state(handlers.AddDebtStates.waiting_for_confirmation)
            await state.update_data(
                contact_id=bob.id,
                direction=TransactionDirection.GIVEN.value,
                amount=75000,
                currency="UZS",
                note=None,
                due_date=None,
                scope_chat_id=0,
                confirmation_ready=True,
                confirmation_nonce="single-use-nonce",
            )

        bot = FakeBot()
        callbacks = [
            FakeCallback(111, "add:confirm:single-use-nonce"),
            FakeCallback(111, "add:confirm:single-use-nonce"),
        ]

        async def confirm(callback):
            async with factory() as callback_session:
                await handlers.add_confirm_callback(
                    callback, state, callback_session, bot
                )

        await asyncio.gather(*(confirm(callback) for callback in callbacks))

        async with factory() as session:
            transactions = (await session.execute(select(Transaction))).scalars().all()
            assert len(transactions) == 1
            assert transactions[0].status == TransactionStatus.PENDING

        assert len(bot.sent) == 1
        assert sum(
            any("eskirgan" in (answer or "") for answer in callback.answered)
            for callback in callbacks
        ) == 1
        assert state.state is None

    run(scenario())


def test_stale_review_cannot_submit_new_flow_data(db):
    run, factory = db

    async def scenario():
        async with factory() as session:
            _, bob = await _make_users(session)

        state = FakeState()
        await state.set_state(handlers.AddDebtStates.waiting_for_confirmation)
        await state.update_data(
            contact_id=bob.id,
            direction=TransactionDirection.RECEIVED.value,
            amount=99000,
            currency="UZS",
            note="Yangi review",
            due_date=None,
            scope_chat_id=0,
            confirmation_ready=True,
            confirmation_nonce="review-b",
        )
        bot = FakeBot()

        stale_callback = FakeCallback(111, "add:confirm:review-a")
        async with factory() as session:
            await handlers.add_confirm_callback(
                stale_callback, state, session, bot
            )

        async with factory() as session:
            assert (await session.execute(select(Transaction))).scalars().all() == []
        assert any("eskirgan" in (answer or "") for answer in stale_callback.answered)
        assert (await state.get_data())["confirmation_nonce"] == "review-b"

        current_callback = FakeCallback(111, "add:confirm:review-b")
        async with factory() as session:
            await handlers.add_confirm_callback(
                current_callback, state, session, bot
            )

        async with factory() as session:
            transactions = (await session.execute(select(Transaction))).scalars().all()
            assert len(transactions) == 1
            assert transactions[0].amount == 99000
        assert len(bot.sent) == 1

    run(scenario())


def test_confirm_callback_by_counterparty(db):
    run, factory = db

    async def scenario():
        async with factory() as session:
            alice, bob = await _make_users(session)
            tx = await _pending_tx(session, alice, bob)

            callback = FakeCallback(222, f"txconfirm:{tx.id}")
            bot = FakeBot()
            await handlers.confirm_transaction_callback(callback, session, bot)

            await session.refresh(tx)
            assert tx.status == TransactionStatus.CONFIRMED
            assert any("Tasdiqlandi" in t for t in callback.message.edits)
            # The entrant was notified.
            assert any(chat_id == 111 for chat_id, _, _ in bot.sent)

    run(scenario())


def test_undeliverable_confirmation_stays_pending_for_counterparty(db, monkeypatch):
    """A Telegram delivery issue must never confirm a debt without review."""
    run, factory = db

    class DeliveryUnavailable(Exception):
        pass

    async def scenario():
        async with factory() as session:
            alice, bob = await _make_users(session)
            tx = await _pending_tx(session, alice, bob)
            message = FakeMessage(from_user=FakeTelegramUser(111))
            monkeypatch.setattr(handlers, "TelegramForbiddenError", DeliveryUnavailable)

            await handlers._notify_and_summarize(
                message,
                session,
                FakeBot(DeliveryUnavailable()),
                alice,
                bob,
                tx,
            )

            await session.refresh(tx)
            assert tx.status == TransactionStatus.PENDING
            assert tx.id in {
                pending.id
                for pending in await get_pending_confirmations(session, bob)
            }
            assert any("/pending" in answer for answer in message.answers)

    run(scenario())


def test_pending_notification_retries_transient_delivery_failure(monkeypatch):
    class EventuallyAvailableBot:
        def __init__(self):
            self.attempts = 0

        async def send_message(self, chat_id, text, **kwargs):
            self.attempts += 1
            if self.attempts < 3:
                raise RuntimeError("temporary Telegram outage")

    delays = []

    async def fake_sleep(delay):
        delays.append(delay)

    monkeypatch.setattr(handlers.asyncio, "sleep", fake_sleep)
    bot = EventuallyAvailableBot()
    delivered = asyncio.run(
        handlers._send_pending_notification(
            bot,
            222,
            "pending repayment",
            reply_markup=None,
        )
    )

    assert delivered
    assert bot.attempts == 3
    assert delays == [0.25, 1.0]


def test_confirm_callback_explains_ledger_conflict(db, monkeypatch):
    run, factory = db

    async def scenario():
        async with factory() as session:
            alice, bob = await _make_users(session)
            tx = await _pending_tx(session, alice, bob)

            async def fail_confirmation(*args, **kwargs):
                raise ValueError(
                    "Bu amal mavjud qaytarish tranzaksiyalariga zid keladi."
                )

            monkeypatch.setattr(
                handlers, "set_transaction_status", fail_confirmation
            )
            callback = FakeCallback(222, f"txconfirm:{tx.id}")
            await handlers.confirm_transaction_callback(
                callback, session, FakeBot()
            )

            assert callback.message.edits == []
            assert any("qaytarish" in (answer or "") for answer in callback.answered)

    run(scenario())


def test_confirm_callback_rejected_for_wrong_user(db):
    run, factory = db

    async def scenario():
        async with factory() as session:
            alice, bob = await _make_users(session)
            tx = await _pending_tx(session, alice, bob)

            # The entrant (Alice) must not confirm her own entry.
            callback = FakeCallback(111, f"txconfirm:{tx.id}")
            await handlers.confirm_transaction_callback(
                callback, session, FakeBot()
            )

            await session.refresh(tx)
            assert tx.status == TransactionStatus.PENDING
            assert callback.message.edits == []
            assert any(
                "ikkinchi tomon" in (t or "") for t in callback.answered
            )

    run(scenario())


def test_reject_callback_by_counterparty(db):
    run, factory = db

    async def scenario():
        async with factory() as session:
            alice, bob = await _make_users(session)
            tx = await _pending_tx(session, alice, bob)

            callback = FakeCallback(222, f"txreject:{tx.id}")
            await handlers.reject_transaction_callback(
                callback, session, FakeBot()
            )

            await session.refresh(tx)
            assert tx.status == TransactionStatus.REJECTED
            assert any("Rad etildi" in t for t in callback.message.edits)

    run(scenario())


def test_confirm_callback_on_already_handled_transaction(db):
    run, factory = db

    async def scenario():
        async with factory() as session:
            alice, bob = await _make_users(session)
            tx = await create_transaction(
                session,
                entered_by=alice,
                other=bob,
                direction=TransactionDirection.RECEIVED,
                amount=50000,
                status=TransactionStatus.CONFIRMED,
            )
            await session.commit()

            callback = FakeCallback(222, f"txconfirm:{tx.id}")
            await handlers.confirm_transaction_callback(
                callback, session, FakeBot()
            )

            assert callback.message.edits == []
            assert any(
                "allaqachon" in (t or "") for t in callback.answered
            )

    run(scenario())


def test_history_hide_buttons_and_callback_are_scoped_and_idempotent(db):
    run, factory = db

    async def scenario():
        async with factory() as session:
            alice, bob = await _make_users(session)
            rejected = await create_transaction(
                session,
                entered_by=alice,
                other=bob,
                direction=TransactionDirection.RECEIVED,
                amount=50_000,
                status=TransactionStatus.REJECTED,
                scope_chat_id=0,
            )
            active = await create_transaction(
                session,
                entered_by=alice,
                other=bob,
                direction=TransactionDirection.RECEIVED,
                amount=60_000,
                status=TransactionStatus.CONFIRMED,
                scope_chat_id=0,
            )
            await session.commit()

            history_callback = FakeCallback(
                111, f"history_contact:{bob.id}", chat_id=1000
            )
            await handlers.history_contact_callback(
                history_callback, FakeState(), session
            )
            pair_markup = history_callback.message.edit_kwargs[-1]["reply_markup"]
            pair_callbacks = [
                button.callback_data
                for row in pair_markup.inline_keyboard
                for button in row
            ]
            assert pair_callbacks == [f"historyhide:pair-{bob.id}:{rejected.id}"]
            assert active.id in {
                transaction.id
                for transaction in (
                    await session.execute(select(Transaction))
                ).scalars()
            }

            all_history_message = FakeMessage(
                from_user=FakeTelegramUser(111, "alice", "Alice"),
                chat=FakeChat("private", 1000),
            )
            await handlers._send_all_history(all_history_message, session, alice)
            all_markup = all_history_message.answer_kwargs[-1]["reply_markup"]
            all_callbacks = [
                button.callback_data
                for row in all_markup.inline_keyboard
                for button in row
            ]
            assert all_callbacks == [f"historyhide:all:{rejected.id}"]

            hide_callback = FakeCallback(
                111, f"historyhide:pair-{bob.id}:{rejected.id}", chat_id=1000
            )
            await handlers.history_hide_callback(hide_callback, session)
            await handlers.history_hide_callback(hide_callback, session)

            hidden_rows = (
                await session.execute(select(TransactionHistoryHide))
            ).scalars().all()
            assert len(hidden_rows) == 1
            assert hidden_rows[0].transaction_id == rejected.id
            assert "yashirildi" in (hide_callback.answered[0] or "")
            assert "60 000 UZS" in hide_callback.message.edits[-1]
            assert hide_callback.message.edit_kwargs[-1]["reply_markup"] is None

    run(scenario())


def test_history_hide_callback_rejects_nonparticipant_and_stale_keyboard(db):
    run, factory = db

    async def scenario():
        async with factory() as session:
            alice, bob = await _make_users(session)
            rejected = await create_transaction(
                session,
                entered_by=alice,
                other=bob,
                direction=TransactionDirection.RECEIVED,
                amount=50_000,
                status=TransactionStatus.REJECTED,
                scope_chat_id=0,
            )
            outsider = User(telegram_id=333, username="outsider", first_name="Outsider")
            session.add(outsider)
            await session.commit()

            outsider_callback = FakeCallback(
                333, f"historyhide:all:{rejected.id}", chat_id=1000
            )
            await handlers.history_hide_callback(outsider_callback, session)
            assert any(
                "ruxsat yo'q" in (answer or "")
                for answer in outsider_callback.answered
            )

            stale_callback = FakeCallback(
                111, "historyhide:all:999999999", chat_id=1000
            )
            await handlers.history_hide_callback(stale_callback, session)
            assert any(
                "ruxsat yo'q" in (answer or "")
                for answer in stale_callback.answered
            )
            assert (
                await session.execute(select(TransactionHistoryHide))
            ).scalars().all() == []

    run(scenario())
