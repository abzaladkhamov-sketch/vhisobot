from types import SimpleNamespace

from models import TransactionDirection, TransactionStatus
from services import calculate_user_pair_net


def tx(
    debtor_id: int,
    creditor_id: int,
    amount: int,
    status: TransactionStatus = TransactionStatus.CONFIRMED,
):
    return SimpleNamespace(
        debtor_id=debtor_id,
        creditor_id=creditor_id,
        amount=amount,
        direction=TransactionDirection.RECEIVED,
        status=status,
    )


def test_received_means_current_user_owes_other():
    transactions = [tx(debtor_id=1, creditor_id=2, amount=50_000)]

    assert calculate_user_pair_net(
        user_id=1,
        other_user_id=2,
        transactions=transactions,
    ) == 50_000
    assert calculate_user_pair_net(
        user_id=2,
        other_user_id=1,
        transactions=transactions,
    ) == -50_000


def test_given_reduces_existing_debt():
    transactions = [
        tx(debtor_id=1, creditor_id=2, amount=100_000),
        tx(debtor_id=2, creditor_id=1, amount=30_000),
    ]

    assert calculate_user_pair_net(
        user_id=1,
        other_user_id=2,
        transactions=transactions,
    ) == 70_000


def test_settled_pair_has_zero_balance():
    transactions = [
        tx(debtor_id=1, creditor_id=2, amount=100_000),
        tx(debtor_id=2, creditor_id=1, amount=100_000),
    ]

    assert calculate_user_pair_net(
        user_id=1,
        other_user_id=2,
        transactions=transactions,
    ) == 0


def test_pending_and_rejected_transactions_are_excluded():
    transactions = [
        tx(debtor_id=1, creditor_id=2, amount=100_000),
        tx(debtor_id=1, creditor_id=2, amount=40_000, status=TransactionStatus.PENDING),
        tx(debtor_id=1, creditor_id=2, amount=25_000, status=TransactionStatus.REJECTED),
    ]

    assert calculate_user_pair_net(
        user_id=1,
        other_user_id=2,
        transactions=transactions,
    ) == 100_000


def test_repayment_reduces_debt():
    transactions = [
        tx(debtor_id=1, creditor_id=2, amount=100_000),
        tx(debtor_id=2, creditor_id=1, amount=30_000, status=TransactionStatus.REPAYMENT),
    ]

    assert calculate_user_pair_net(
        user_id=1,
        other_user_id=2,
        transactions=transactions,
    ) == 70_000


def test_full_repayment_settles_debt():
    transactions = [
        tx(debtor_id=1, creditor_id=2, amount=100_000),
        tx(debtor_id=2, creditor_id=1, amount=100_000, status=TransactionStatus.REPAYMENT),
    ]

    assert calculate_user_pair_net(
        user_id=1,
        other_user_id=2,
        transactions=transactions,
    ) == 0


def test_legacy_rows_without_status_count_as_confirmed():
    legacy = SimpleNamespace(debtor_id=1, creditor_id=2, amount=10_000)

    assert calculate_user_pair_net(
        user_id=1,
        other_user_id=2,
        transactions=[legacy],
    ) == 10_000
