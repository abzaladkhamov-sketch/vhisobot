"""Daily scheduler: due-date reminders and periodic balance reports.

Runs alongside polling as an asyncio task. Every day at RUN_HOUR
(Tashkent time) it sends:
- due-date reminders (1 day before, on the day, and after the deadline)
  to both sides of a debt, at most once per transaction/kind/day;
- weekly (Monday) or monthly (1st) balance summaries to users who opted
  in via /settings.
"""

from __future__ import annotations

import asyncio
import logging
from datetime import date, datetime, timedelta
from html import escape

from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError
from sqlalchemy import delete, or_, select, update
from sqlalchemy.exc import IntegrityError

from models import (
    PendingNotification,
    PendingNotificationStatus,
    ReminderLog,
    ReportFrequency,
    Transaction,
    TransactionStatus,
    User,
)
from services import format_money, get_balances, get_debt_between
from keyboards import confirm_transaction_keyboard
from timezone import format_uzbekistan_date, now_uzbekistan

logger = logging.getLogger(__name__)

RUN_HOUR = 9  # 09:00 Asia/Tashkent
PENDING_NOTIFICATION_MAX_ATTEMPTS = 5
PENDING_NOTIFICATION_RETRY_DELAYS = (
    timedelta(minutes=1),
    timedelta(minutes=5),
    timedelta(minutes=30),
    timedelta(hours=2),
)
PENDING_NOTIFICATION_POLL_SECONDS = 30


def classify_due(due: date, today: date) -> str | None:
    """Which reminder (if any) applies to this due date today."""
    delta = (due - today).days
    if delta == 1:
        return "due_soon"
    if delta == 0:
        return "due_today"
    if delta < 0:
        return "overdue"
    return None


def seconds_until_next_run(now: datetime) -> float:
    """Seconds from `now` (Tashkent) until the next RUN_HOUR:00."""
    target = now.replace(hour=RUN_HOUR, minute=0, second=0, microsecond=0)
    if target <= now:
        target += timedelta(days=1)
    return (target - now).total_seconds()


def report_due_today(frequency: str, today: date) -> bool:
    if frequency == ReportFrequency.WEEKLY:
        return today.weekday() == 0  # Monday
    if frequency == ReportFrequency.MONTHLY:
        return today.day == 1
    return False


def _pending_notification_retry_delay(attempt_count: int) -> timedelta:
    """Return the durable delay after an attempt has been claimed."""
    index = min(
        max(attempt_count - 1, 0),
        len(PENDING_NOTIFICATION_RETRY_DELAYS) - 1,
    )
    return PENDING_NOTIFICATION_RETRY_DELAYS[index]


async def _expire_exhausted_notifications(session_factory) -> None:
    async with session_factory() as session:
        await session.execute(
            update(PendingNotification)
            .where(
                PendingNotification.status == PendingNotificationStatus.PENDING,
                PendingNotification.attempt_count
                >= PENDING_NOTIFICATION_MAX_ATTEMPTS,
            )
            .values(status=PendingNotificationStatus.PERMANENT_FAILURE)
        )
        await session.commit()


async def _claim_pending_notification(
    session_factory,
    transaction_id: int | None = None,
):
    """Claim one due notification, atomically across bot/API processes."""
    async with session_factory() as session:
        query = (
            select(PendingNotification)
            .join(Transaction, Transaction.id == PendingNotification.transaction_id)
            .where(
                PendingNotification.status == PendingNotificationStatus.PENDING,
                PendingNotification.next_attempt_at <= now_uzbekistan(),
                PendingNotification.attempt_count
                < PENDING_NOTIFICATION_MAX_ATTEMPTS,
                Transaction.status.in_(
                    [TransactionStatus.PENDING, TransactionStatus.REPAYMENT_PENDING]
                ),
            )
            .with_for_update(skip_locked=True)
            .limit(1)
        )
        if transaction_id is not None:
            query = query.where(
                PendingNotification.transaction_id == transaction_id
            )
        result = await session.execute(query)
        notification = result.scalar_one_or_none()
        if notification is None:
            return None
        notification.attempt_count += 1
        notification.next_attempt_at = (
            now_uzbekistan()
            + _pending_notification_retry_delay(notification.attempt_count)
        )
        await session.commit()
        return {
            "id": notification.id,
            "transaction_id": notification.transaction_id,
            "recipient_telegram_id": notification.recipient_telegram_id,
            "kind": notification.kind,
            "attempt_count": notification.attempt_count,
        }


async def _finish_pending_notification(
    session_factory,
    notification_id: int,
    *,
    delivered: bool,
    permanent: bool = False,
    error: str | None = None,
) -> None:
    async with session_factory() as session:
        notification = await session.get(PendingNotification, notification_id)
        if notification is None:
            return
        if delivered:
            notification.status = PendingNotificationStatus.SENT
            notification.last_error = None
        elif permanent or notification.attempt_count >= PENDING_NOTIFICATION_MAX_ATTEMPTS:
            notification.status = PendingNotificationStatus.PERMANENT_FAILURE
            notification.last_error = error
        else:
            notification.status = PendingNotificationStatus.PENDING
            notification.last_error = error
        await session.commit()


async def _deliver_claimed_pending_notification(bot, session_factory, claim) -> str:
    """Build and send a claimed request after a final status check."""
    async with session_factory() as session:
        transaction = await session.get(Transaction, claim["transaction_id"])
        if transaction is None or transaction.status not in (
            TransactionStatus.PENDING,
            TransactionStatus.REPAYMENT_PENDING,
        ):
            await session.execute(
                delete(PendingNotification).where(
                    PendingNotification.id == claim["id"]
                )
            )
            await session.commit()
            return "cancelled"
        sender = await session.get(User, transaction.entered_by_id)
        recipient_result = await session.execute(
            select(User).where(
                User.telegram_id == claim["recipient_telegram_id"]
            )
        )
        recipient = recipient_result.scalar_one_or_none()
        if sender is None or recipient is None:
            error = "notification participants no longer exist"
            await _finish_pending_notification(
                session_factory,
                claim["id"],
                delivered=False,
                permanent=True,
                error=error,
            )
            return "permanent_failure"

        money = format_money(transaction.amount, transaction.currency)
        sender_name = escape(sender.display_name())
        if claim["kind"] == "repayment":
            view = f"Siz <b>{sender_name}</b> dan <b>{money}</b> qaytaruv oldingiz."
            title = "qaytaruv"
        elif transaction.direction == "received":
            view = f"Siz <b>{sender_name}</b> ga <b>{money}</b> berdingiz."
            title = "tranzaksiya"
        else:
            view = f"Siz <b>{sender_name}</b> dan <b>{money}</b> oldingiz."
            title = "tranzaksiya"
        note = f"\nIzoh: {escape(transaction.note)}" if transaction.note else ""
        due = (
            f"\nMuddat: {format_uzbekistan_date(transaction.due_date)}"
            if transaction.due_date
            else ""
        )
        text = (
            f"🔔 <b>Yangi {title} — tasdiqlash kerak</b>\n\n"
            f"{view}{note}{due}\n\n"
            "To'g'ri bo'lsa tasdiqlang, xato bo'lsa rad eting:"
        )

    try:
        await bot.send_message(
            claim["recipient_telegram_id"],
            text,
            reply_markup=confirm_transaction_keyboard(claim["transaction_id"]),
        )
    except (TelegramForbiddenError, TelegramBadRequest) as error:
        await _finish_pending_notification(
            session_factory,
            claim["id"],
            delivered=False,
            permanent=True,
            error=str(error)[:1000],
        )
        return "permanent_failure"
    except Exception as error:
        await _finish_pending_notification(
            session_factory,
            claim["id"],
            delivered=False,
            error=str(error)[:1000],
        )
        return "retrying"
    await _finish_pending_notification(
        session_factory, claim["id"], delivered=True
    )
    return "sent"


async def deliver_pending_notification(
    bot,
    session_factory,
    transaction_id: int,
) -> str:
    """Deliver one queued request if it is due."""
    claim = await _claim_pending_notification(session_factory, transaction_id)
    if claim is None:
        return "not_due"
    return await _deliver_claimed_pending_notification(
        bot, session_factory, claim
    )


async def process_pending_notifications(bot, session_factory) -> None:
    """Drain due queue rows; safe for more than one bot/API worker."""
    await _expire_exhausted_notifications(session_factory)
    while True:
        claim = await _claim_pending_notification(session_factory)
        if claim is None:
            return
        await _deliver_claimed_pending_notification(
            bot, session_factory, claim
        )


def _reminder_texts(
    kind: str,
    debtor: User,
    creditor: User,
    money: str,
    due: date,
) -> tuple[str, str]:
    """(text for debtor, text for creditor). Names are HTML-escaped."""
    due_text = format_uzbekistan_date(due)
    if kind == "due_soon":
        head = f"⏰ <b>Eslatma:</b> muddat ertaga ({due_text})."
    elif kind == "due_today":
        head = f"⏰ <b>Eslatma:</b> muddat bugun ({due_text})."
    else:
        head = f"❗️ <b>Muddati o'tgan qarz</b> (muddat: {due_text})."
    debtor_text = (
        f"{head}\nSiz <b>{escape(creditor.display_name())}</b> ga "
        f"<b>{money}</b> qaytarishingiz kerak."
    )
    creditor_text = (
        f"{head}\n<b>{escape(debtor.display_name())}</b> sizga "
        f"<b>{money}</b> qaytarishi kerak."
    )
    return debtor_text, creditor_text


async def _send_reminder_once(
    bot,
    session_factory,
    *,
    transaction_id: int,
    kind: str,
    role: str,
    today: date,
    telegram_id: int,
    text: str,
) -> None:
    """Deliver one reminder at most once per tx/kind/role/day.

    The dedupe row and the Telegram send commit or roll back together, so
    a transient delivery failure is retried on the next scheduler run
    instead of being silently marked as sent.
    """
    async with session_factory() as session:
        session.add(
            ReminderLog(
                transaction_id=transaction_id,
                kind=f"{kind}:{role}",
                sent_on=today,
            )
        )
        try:
            await session.flush()
        except IntegrityError:
            await session.rollback()
            return
        try:
            await bot.send_message(telegram_id, text)
        except Exception:
            await session.rollback()
            logger.info(
                "Reminder %s:%s for tx %s not delivered", kind, role, transaction_id
            )
            return
        await session.commit()


async def process_due_reminders(bot, session_factory, today: date) -> None:
    async with session_factory() as session:
        result = await session.execute(
            select(Transaction).where(
                Transaction.due_date.is_not(None),
                Transaction.due_date <= today + timedelta(days=1),
                Transaction.status == TransactionStatus.CONFIRMED,
            )
        )
        transactions = list(result.scalars().all())

    for tx in transactions:
        kind = classify_due(tx.due_date, today)
        if kind is None:
            continue
        async with session_factory() as session:
            # Outstanding amount in this direction right now. Zero or
            # negative means the debt is settled — no reminder.
            net = await get_debt_between(
                session, tx.debtor_id, tx.creditor_id, tx.currency, tx.scope_chat_id
            )
            if net <= 0:
                continue
            debtor = await session.get(User, tx.debtor_id)
            creditor = await session.get(User, tx.creditor_id)
        if debtor is None or creditor is None:
            continue

        # Remind about the actually unpaid amount, not the original
        # transaction amount (partial repayments reduce it).
        outstanding = min(tx.amount, net)
        money = format_money(outstanding, tx.currency)
        debtor_text, creditor_text = _reminder_texts(
            kind, debtor, creditor, money, tx.due_date
        )
        for role, user, text in (
            ("debtor", debtor, debtor_text),
            ("creditor", creditor, creditor_text),
        ):
            await _send_reminder_once(
                bot,
                session_factory,
                transaction_id=tx.id,
                kind=kind,
                role=role,
                today=today,
                telegram_id=user.telegram_id,
                text=text,
            )


def _report_lines(balances) -> list[str]:
    lines = []
    for item in balances:
        money = format_money(item.amount, item.currency)
        name = escape(item.other.display_name())
        if item.user_owes_other:
            lines.append(f"• Siz <b>{name}</b> ga <b>{money}</b> qarzdorsiz.")
        else:
            lines.append(f"• <b>{name}</b> sizga <b>{money}</b> berishi kerak.")
    return lines


async def process_periodic_reports(bot, session_factory, today: date) -> None:
    async with session_factory() as session:
        result = await session.execute(
            select(User.id).where(
                User.report_frequency.in_(
                    [ReportFrequency.WEEKLY.value, ReportFrequency.MONTHLY.value]
                )
            )
        )
        user_ids = [row[0] for row in result.all()]

    for user_id in user_ids:
        async with session_factory() as session:
            db_user = await session.get(User, user_id)
            if db_user is None or not report_due_today(
                db_user.report_frequency, today
            ):
                continue
            # Atomic claim: only one scheduler instance wins today's send.
            claim = await session.execute(
                update(User)
                .where(
                    User.id == user_id,
                    or_(
                        User.report_last_sent.is_(None),
                        User.report_last_sent != today,
                    ),
                )
                .values(report_last_sent=today)
            )
            if claim.rowcount == 0:
                await session.rollback()
                continue
            balances = await get_balances(session, db_user, 0)
            title = (
                "📊 <b>Haftalik hisobot</b>"
                if db_user.report_frequency == ReportFrequency.WEEKLY
                else "📊 <b>Oylik hisobot</b>"
            )
            body = (
                "\n".join(_report_lines(balances))
                if balances
                else "Faol qarzlar yo'q. 🎉"
            )
            telegram_id = db_user.telegram_id
            await session.commit()
        try:
            await bot.send_message(
                telegram_id,
                f"{title}\n{format_uzbekistan_date(today)}\n\n{body}",
            )
        except Exception:
            logger.info("Report not delivered to user %s", user_id)


async def run_daily_checks(bot, session_factory) -> None:
    try:
        await process_pending_notifications(bot, session_factory)
    except Exception:
        logger.exception("Pending notification processing failed")
    today = now_uzbekistan().date()
    try:
        await process_due_reminders(bot, session_factory, today)
    except Exception:
        logger.exception("Due reminder processing failed")
    try:
        await process_periodic_reports(bot, session_factory, today)
    except Exception:
        logger.exception("Periodic report processing failed")


async def scheduler_loop(bot, session_factory) -> None:
    logger.info("Scheduler started (daily at %02d:00 Asia/Tashkent)", RUN_HOUR)
    await run_daily_checks(bot, session_factory)
    while True:
        daily_delay = seconds_until_next_run(now_uzbekistan())
        delay = min(daily_delay, PENDING_NOTIFICATION_POLL_SECONDS)
        try:
            await asyncio.sleep(delay)
        except asyncio.CancelledError:
            raise
        await process_pending_notifications(bot, session_factory)
        if daily_delay <= PENDING_NOTIFICATION_POLL_SECONDS:
            await run_daily_checks(bot, session_factory)
