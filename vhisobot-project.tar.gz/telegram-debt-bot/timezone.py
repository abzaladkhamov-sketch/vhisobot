from datetime import datetime, timezone
from zoneinfo import ZoneInfo


UZBEKISTAN_TZ = ZoneInfo("Asia/Tashkent")


def now_uzbekistan() -> datetime:
    return datetime.now(UZBEKISTAN_TZ)


def as_uzbekistan(value: datetime | None) -> datetime | None:
    if value is None:
        return None
    if value.tzinfo is None:
        # PostgreSQL/SQLite may return a naive UTC value for a timezone column.
        value = value.replace(tzinfo=timezone.utc)
    return value.astimezone(UZBEKISTAN_TZ)


def format_uzbekistan_datetime(value: datetime | None) -> str:
    converted = as_uzbekistan(value)
    return converted.strftime("%d.%m.%Y %H:%M") if converted else "—"


def today_uzbekistan():
    return now_uzbekistan().date()


def format_uzbekistan_date(value) -> str:
    return value.strftime("%d.%m.%Y") if value else "—"
