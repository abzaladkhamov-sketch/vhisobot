from __future__ import annotations

import asyncio
from collections import defaultdict
from datetime import date, timedelta
from html import escape
import secrets
from urllib.parse import urlencode

from aiogram import Bot, F, Router
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError
from aiogram.filters import Command, CommandObject, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from currencies import currency_keyboard, currency_name, is_valid_currency_code
from keyboards import (
    MENU_ADD,
    MENU_ALL_HISTORY,
    MENU_BALANCE,
    MENU_HELP,
    MENU_HISTORY,
    MENU_INVITE,
    MENU_MANAGE,
    MENU_SETTINGS,
    INVITE_REQUEST_ID,
    SKIP_DUE,
    SKIP_NOTE,
    balance_repay_keyboard,
    confirm_transaction_keyboard,
    contacts_keyboard,
    direction_keyboard,
    history_hide_keyboard,
    invite_keyboard,
    invite_share_keyboard,
    main_menu_keyboard,
    manage_actions_keyboard,
    manage_list_keyboard,
    privacy_menu_keyboard,
    report_settings_keyboard,
    review_transaction_keyboard,
    skip_due_keyboard,
    skip_note_keyboard,
)
from models import (
    PendingNotification,
    ReportFrequency,
    Transaction,
    TransactionDirection,
    TransactionStatus,
    User,
    PendingNotificationStatus,
)
from services import (
    create_transaction,
    create_web_access_code,
    delete_transaction,
    format_money,
    get_all_transactions,
    get_contacts,
    get_debt_between,
    get_entered_transactions,
    get_nearest_due_date,
    get_pending_confirmations,
    get_pair_transactions,
    can_hide_transaction,
    hide_transaction_for_user,
    find_contact_by_username,
    register_pin_failure,
    parse_due_date,
    parse_quick_entry,
    get_transaction,
    get_user_by_telegram_id,
    get_balances,
    get_balance_breakdown,
    add_pending_invite,
    consume_pending_invite,
    link_users,
    set_transaction_status,
    update_transaction,
    upsert_shared_user,
    upsert_user,
)
import pin as pin_module
from pin import hash_pin, is_valid_pin, pin_gate, verify_pin
from states import (
    AddDebtStates,
    EditStates,
    HistoryStates,
    PinStates,
    RepayStates,
)
from timezone import (
    format_uzbekistan_date,
    format_uzbekistan_datetime,
    now_uzbekistan,
    today_uzbekistan,
)

router = Router()
_add_confirm_locks: defaultdict[int, asyncio.Lock] = defaultdict(asyncio.Lock)
_PENDING_NOTIFICATION_RETRY_DELAYS = (0.25, 1.0)


def _user_label(user: User) -> str:
    return escape(user.display_name())


async def _send_pending_notification(
    bot: Bot,
    telegram_id: int,
    text: str,
    *,
    reply_markup,
) -> bool:
    """Send a pending request, retrying transient Telegram failures.

    Delivery is deliberately separate from the transaction lifecycle. A
    successful retry only delivers the review controls; it never changes the
    pending transaction's status.
    """
    attempts = len(_PENDING_NOTIFICATION_RETRY_DELAYS) + 1
    for attempt in range(attempts):
        try:
            await bot.send_message(
                telegram_id,
                text,
                reply_markup=reply_markup,
            )
            return True
        except (TelegramForbiddenError, TelegramBadRequest):
            # A blocked bot or invalid chat/message cannot be repaired by
            # retrying. The pending list remains the durable review path.
            return False
        except Exception:
            if attempt == attempts - 1:
                return False
            await asyncio.sleep(_PENDING_NOTIFICATION_RETRY_DELAYS[attempt])
    return False


async def _mark_pending_notification_sent(
    session: AsyncSession,
    transaction_id: int,
) -> None:
    await session.execute(
        update(PendingNotification)
        .where(PendingNotification.transaction_id == transaction_id)
        .values(
            status=PendingNotificationStatus.SENT,
            last_error=None,
        )
    )
    await session.commit()


async def _claim_pending_notification_for_delivery(
    session: AsyncSession,
    transaction_id: int,
) -> bool:
    """Claim the queue row before the immediate send to avoid duplicates."""
    result = await session.execute(
        select(PendingNotification)
        .join(Transaction, Transaction.id == PendingNotification.transaction_id)
        .where(
            PendingNotification.transaction_id == transaction_id,
            PendingNotification.status == PendingNotificationStatus.PENDING,
            PendingNotification.next_attempt_at <= now_uzbekistan(),
            PendingNotification.attempt_count < 5,
            Transaction.status.in_(
                [TransactionStatus.PENDING, TransactionStatus.REPAYMENT_PENDING]
            ),
        )
        .with_for_update(skip_locked=True)
    )
    notification = result.scalar_one_or_none()
    if notification is None:
        return False
    notification.attempt_count += 1
    notification.next_attempt_at = now_uzbekistan() + timedelta(minutes=1)
    await session.commit()
    return True


async def _send_queued_pending_notification(
    bot: Bot,
    session: AsyncSession,
    transaction_id: int,
    telegram_id: int,
    text: str,
    *,
    reply_markup,
) -> bool:
    if not await _claim_pending_notification_for_delivery(session, transaction_id):
        return False
    delivered = await _send_pending_notification(
        bot,
        telegram_id,
        text,
        reply_markup=reply_markup,
    )
    if delivered:
        await _mark_pending_notification_sent(session, transaction_id)
    return delivered


def _status_mark(status: TransactionStatus) -> str:
    return {
        TransactionStatus.PENDING: "⏳ Tasdiqlash kutilmoqda · ",
        TransactionStatus.REPAYMENT_PENDING: "⏳ Qaytaruv tasdiqlash kutilmoqda · ",
        TransactionStatus.CONFIRMED: "✅ Tasdiqlangan · ",
        TransactionStatus.REJECTED: "❌ Rad etilgan · ",
        TransactionStatus.REPAYMENT: "💵 Qaytaruv · ",
    }.get(status, "")


def _history_action(tx: Transaction, user: User) -> str:
    if tx.status == TransactionStatus.REPAYMENT:
        if tx.entered_by_id == user.id:
            return "Siz qaytaruv kiritdingiz — qarzingiz kamaydi"
        return "Qaytaruv kiritildi — sizga qarz kamaydi"
    if tx.status == TransactionStatus.REPAYMENT_PENDING:
        if tx.entered_by_id == user.id:
            return "Siz qaytaruv kiritdingiz — tasdiqlash kutilmoqda"
        return "Qaytaruv so'rovi keldi — tasdiqlash kutilmoqda"
    direction = "Siz oldingiz" if tx.debtor_id == user.id else "Siz berdingiz"
    if tx.status == TransactionStatus.PENDING:
        return f"{direction} — balans hali o'zgarmagan"
    if tx.status == TransactionStatus.REJECTED:
        return f"{direction} — balansga qo'shilmagan"
    return direction


def _pending_next_action(tx: Transaction, user: User) -> str:
    if tx.status not in {
        TransactionStatus.PENDING,
        TransactionStatus.REPAYMENT_PENDING,
    }:
        return ""
    if tx.status == TransactionStatus.REPAYMENT_PENDING:
        if tx.entered_by_id == user.id:
            return " | Keyingi amal: ikkinchi tomon qaytaruvni tasdiqlashini kuting"
        return " | Keyingi amal: qaytaruvni tasdiqlang yoki rad eting"
    if tx.entered_by_id == user.id:
        return " | Keyingi amal: ikkinchi tomon tasdiqlashini kuting"
    return " | Keyingi amal: tasdiqlang yoki rad eting"


def _due_suffix(tx: Transaction) -> str:
    if not tx.due_date:
        return ""
    formatted = format_uzbekistan_date(tx.due_date)
    if tx.due_date < today_uzbekistan() and tx.status in {
        TransactionStatus.CONFIRMED,
        TransactionStatus.PENDING,
    }:
        return f" | ❗️ muddati o'tgan ({formatted})"
    return f" | ⏰ {formatted}"


def _scope_chat_id(message: Message) -> int:
    """0 is personal history; every Telegram group gets its own scope."""
    if message.chat.type in {"group", "supergroup"}:
        return message.chat.id
    return 0


async def _current_user(session: AsyncSession, message: Message) -> User:
    return await upsert_user(session, message.from_user)


async def _ensure_registered(session: AsyncSession, message: Message) -> User:
    user = await _current_user(session, message)
    await session.commit()
    return user


@router.message(CommandStart())
async def start_handler(
    message: Message,
    command: CommandObject,
    session: AsyncSession,
    bot: Bot,
) -> None:
    user = await upsert_user(session, message.from_user)
    payload = command.args or ""
    linked_text = ""

    if payload.startswith("link_"):
        try:
            inviter_telegram_id = int(payload.removeprefix("link_"))
        except ValueError:
            inviter_telegram_id = 0
        inviter = await get_user_by_telegram_id(session, inviter_telegram_id)
        if inviter and inviter.id != user.id:
            await link_users(session, inviter, user)
    else:
        inviter = await consume_pending_invite(session, user.telegram_id)
        if inviter and inviter.id != user.id:
            await link_users(session, inviter, user)

    if inviter and inviter.id != user.id:
        bot_info = await bot.get_me()
        bot_label = f"@{bot_info.username}" if bot_info.username else bot_info.first_name
        if payload.startswith("link_"):
            linked_text = (
                "\n\n🎉 <b>Siz taklif qilindingiz!</b>\n"
                f"<b>{escape(inviter.display_name())}</b> sizni "
                f"<b>{escape(bot_label)}</b> orqali qarz hisob-kitoblariga "
                "taklif qildi.\n\n"
                "Endi bir-biringizning qarzlaringizni kiritishingiz mumkin."
            )
        else:
            linked_text = (
                "\n\n🎉 <b>Sizni taklif qilgan foydalanuvchi:</b>\n"
                f"<b>{escape(inviter.display_name())}</b>\n\n"
                f"U sizni <b>{escape(bot_label)}</b> orqali qarz "
                "hisob-kitoblariga taklif qildi. Endi bir-biringizning "
                "qarzlaringizni kiritishingiz mumkin."
            )

    await session.commit()
    await message.answer(
        f"Assalomu alaykum, <b>{_user_label(user)}</b>!"
        f"{linked_text}\n\n"
        "Men siz va boshqa foydalanuvchilar o'rtasidagi qarzlarni hisoblayman.\n\n"
        "<b>Asosiy buyruqlar:</b>\n"
        "/invite — kontaktni botga taklif qilish\n"
        "/add — qarz kiritish\n"
        "/balance — joriy qarzlar va qaytarish\n"
        "/history — operatsiyalar tarixi\n"
        "/all_history — barcha operatsiyalar\n"
        "/manage — tranzaksiyani o'chirish/tahrirlash\n"
        "/settings — davriy hisobot sozlamalari\n"
        "/web — web va mobil ilovaga kirish kodi\n"
        "/pending — tasdiqlash kutilayotgan tranzaksiyalar\n"
        "/id — Telegram ID'ingizni ko'rish\n"
        "/help — yordam",
        reply_markup=main_menu_keyboard(),
    )


@router.message(Command("help"))
async def help_handler(message: Message, session: AsyncSession) -> None:
    await _ensure_registered(session, message)
    await message.answer(
        "<b>Qanday ishlaydi?</b>\n\n"
        "1. /invite orqali boshqa foydalanuvchini ulang.\n"
        "2. /add buyrug'i bilan summa va yo'nalishni kiriting.\n"
        "3. <b>Oldim</b> desangiz, siz boshqa odamga qarzdor bo'lasiz.\n"
        "4. <b>Berdim</b> desangiz, boshqa odam sizga qarzdor bo'ladi.\n\n"
        "Har bir tranzaksiya bir marta saqlanadi. Yangi tranzaksiyani "
        "ikkinchi tomon tasdiqlagach balans yangilanadi. Tasdiqlash xabari "
        "yetib bormasa ham, ikkinchi tomon /pending, web yoki mobil ilovadan "
        "uni tasdiqlay oladi.\n\n"
        "<b>Tezkor kiritish:</b>\n"
        "<code>/oldim 50000 @user izoh</code> — bir xabarda qarz kiritish\n"
        "<code>/berdim 100 USD @user izoh</code> — teskari yo'nalishda\n"
        "Guruhda @user o'rniga odamning xabariga reply qilsangiz ham bo'ladi.\n\n"
        "<b>Qaytaruv kiritish:</b> /balance dagi tugma orqali qarzni to'liq yoki "
        "qisman qaytarganingizni yozing.\n"
        "<b>Tahrirlash:</b> /manage orqali o'zingiz kiritgan tranzaksiyani "
        "o'chirish yoki summa/izohini o'zgartirish mumkin.\n"
        "<b>Muddat:</b> qarz kiritishda qaytarish sanasini qo'ysangiz, "
        "muddat yaqinlashganda ikkala tomonga eslatma keladi.\n"
        "<b>Hisobot:</b> /settings orqali haftalik yoki oylik balans "
        "xulosasini yoqish mumkin.\n"
        "<b>Maxfiylik:</b> /settings dagi «Maxfiylik» bo'limida 4 xonali "
        "PIN o'rnatsangiz, shaxsiy chatda balans va tarix PIN bilan "
        "himoyalanadi.\n\n"
        "Kontakt taklif qilishda link ko'chirish shart emas: "
        "Telegram kontaktini tanlash tugmasidan foydalaning.\n\n"
        "Guruhda /add buyrug'ini qarz hisoblanadigan odam xabariga "
        "reply qilib yuboring. Guruh hisoboti shaxsiy hisobotdan alohida.",
    )


@router.message(Command("id"))
async def id_handler(message: Message, session: AsyncSession) -> None:
    user = await _ensure_registered(session, message)
    await message.answer(
        f"Sizning Telegram ID'ingiz: <code>{message.from_user.id}</code>\n"
        f"Bot ichidagi ID'ingiz: <code>{user.id}</code>"
    )


@router.message(Command("web"))
async def web_access_handler(message: Message, session: AsyncSession) -> None:
    """Create a short-lived code that authorizes the web/mobile client."""
    if message.chat.type != "private":
        await message.answer(
            "Kirish kodini olish uchun bot bilan shaxsiy chatni ochib, /web yuboring."
        )
        return
    user = await _current_user(session, message)
    code = await create_web_access_code(session, user)
    await session.commit()
    await message.answer(
        "<b>Web va mobil ilova uchun kirish kodi</b>\n\n"
        f"<code>{code}</code>\n\n"
        "Bu kod 10 daqiqa ishlaydi va faqat bir marta qo'llanadi. "
        "Uni Qarz Hisobi website yoki mobil ilovasidagi kirish oynasiga yozing. "
        "Kodni hech kim bilan ulashmang."
    )


@router.message(Command("pending"))
async def pending_confirmations_handler(message: Message, session: AsyncSession) -> None:
    """Let Telegram-only users review requests created on web or mobile."""
    if message.chat.type != "private":
        await message.answer("Tasdiqlash so'rovlarini bot bilan shaxsiy chatda oching.")
        return
    user = await _current_user(session, message)
    transactions = await get_pending_confirmations(session, user)
    if not transactions:
        await message.answer("Tasdiqlash kutilayotgan tranzaksiyalar yo'q.")
        return
    await message.answer(
        f"⏳ Sizdan tasdiqlash kutilayotgan {len(transactions)} ta tranzaksiya:"
    )
    for transaction in transactions[:20]:
        entered_by, _ = await _transaction_participants(session, transaction)
        if entered_by is None:
            continue
        direction = TransactionDirection(transaction.direction)
        money = format_money(transaction.amount, transaction.currency)
        if transaction.status == TransactionStatus.REPAYMENT_PENDING:
            detail = (
                f"Siz <b>{_user_label(entered_by)}</b> dan "
                f"<b>{money}</b> qaytaruv oldingiz."
            )
        elif direction == TransactionDirection.RECEIVED:
            detail = f"Siz <b>{_user_label(entered_by)}</b> ga <b>{money}</b> berdingiz."
        else:
            detail = f"Siz <b>{_user_label(entered_by)}</b> dan <b>{money}</b> oldingiz."
        note = f"\nIzoh: {escape(transaction.note)}" if transaction.note else ""
        await message.answer(
            f"{detail}{note}\n\nTo'g'ri bo'lsa tasdiqlang, xato bo'lsa rad eting:",
            reply_markup=confirm_transaction_keyboard(transaction.id),
        )


@router.message(Command("invite"))
async def invite_handler(message: Message, session: AsyncSession, bot: Bot) -> None:
    await _ensure_registered(session, message)
    if message.chat.type in {"group", "supergroup"}:
        await message.answer(
            "Kontaktni shaxsiy chatda taklif qiling. Guruhda esa "
            "qarz qo'shish uchun foydalanuvchi xabariga reply qilib /add yuboring."
        )
        return
    await message.answer(
        "Link yuborish shart emas.\n\n"
        "Quyidagi tugmani bosib, qarz hisoblamoqchi bo'lgan Telegram "
        "kontaktni tanlang. Kontakt botni hali ishlatmagan bo'lsa, "
        "u botni Telegram qidiruvidan topib /start qilishi kerak. "
        "Shundan keyin aloqa avtomatik faollashadi.",
        reply_markup=invite_keyboard(),
    )


@router.message(F.users_shared)
async def shared_user_handler(
    message: Message, session: AsyncSession, bot: Bot
) -> None:
    shared = message.users_shared
    if shared is None or shared.request_id != INVITE_REQUEST_ID:
        return
    if not shared.users:
        await message.answer("Kontakt tanlanmadi.", reply_markup=main_menu_keyboard())
        return

    inviter = await _current_user(session, message)
    selected = await get_user_by_telegram_id(session, shared.users[0].user_id)
    selected_was_new = selected is None
    selected = await upsert_shared_user(session, shared.users[0])
    if inviter.id == selected.id:
        await session.commit()
        await message.answer(
            "O'zingizni kontakt sifatida tanlab bo'lmaydi.",
            reply_markup=main_menu_keyboard(),
        )
        return

    await link_users(session, inviter, selected)
    if selected_was_new:
        await add_pending_invite(session, inviter, selected.telegram_id)
    await session.commit()
    bot_info = await bot.get_me()
    bot_label = f"@{bot_info.username}" if bot_info.username else bot_info.first_name
    bot_link = f"https://t.me/{bot_info.username}" if bot_info.username else ""
    inviter_name = inviter.display_name()

    # HTML version — sent directly by the bot when the user has already started it.
    invite_notification_html = (
        "🤝 <b>Sizga taklif!</b>\n\n"
        f"👤 <b>{escape(inviter_name)}</b> sizni "
        f"<b>{escape(bot_label)}</b> orqali\n"
        "qarz hisob-kitoblariga taklif qildi.\n\n"
        "Bu bot bilan:\n"
        "💸 Qarz kiritish oson\n"
        "📊 Balans har doim ko'rinib turadi\n"
        "🕐 Tarix saqlanib boradi\n\n"
        "▶️ Boshlash uchun /start yuboring."
    )

    # Plain-text version — used in the Telegram share URL (HTML tags not rendered there).
    invite_notification_plain = (
        "🤝 Sizga taklif!\n\n"
        f"👤 {inviter_name} sizni {bot_label} orqali\n"
        "qarz hisob-kitoblariga taklif qildi.\n\n"
        "Bu bot bilan:\n"
        "💸 Qarz kiritish oson\n"
        "📊 Balans har doim ko'rinib turadi\n"
        "🕐 Tarix saqlanib boradi\n\n"
        f"▶️ Boshlash: {bot_link}"
    )

    notification_sent = True
    try:
        await bot.send_message(selected.telegram_id, invite_notification_html)
    except Exception:
        # Telegram does not allow a bot to initiate a chat before /start.
        notification_sent = False

    if not notification_sent:
        share_url = "https://t.me/share/url?" + urlencode(
            {"url": bot_link, "text": invite_notification_plain}
        )
        await message.answer(
            "📨 <b>Taklifnoma</b>\n\n"
            "Bot bilan hali suhbat boshlamagan. "
            "Quyidagi taklifnomani unga yuboring:\n\n"
            "<blockquote>"
            + invite_notification_html.replace("\n", "\n")
            + "</blockquote>",
            reply_markup=invite_share_keyboard(share_url),
        )

    delivery_note = (
        "✉️ Taklif xabari unga yuborildi."
        if notification_sent
        else "📤 Taklifnomani yuborish uchun yuqoridagi tugmani bosing."
    )
    await message.answer(
        f"✅ <b>{_user_label(selected)}</b> kontaktlar ro'yxatiga qo'shildi.\n\n"
        f"{delivery_note}",
        reply_markup=main_menu_keyboard(),
    )


@router.message(Command("add"))
async def add_handler(message: Message, state: FSMContext, session: AsyncSession) -> None:
    # A new guided flow invalidates every review button from an older flow.
    await state.clear()
    if message.chat.type in {"group", "supergroup"}:
        reply = message.reply_to_message
        if (
            reply is None
            or reply.from_user is None
            or reply.from_user.is_bot
            or reply.from_user.id == message.from_user.id
        ):
            await message.answer(
                "Guruhda qarz qo'shish uchun /add buyrug'ini "
                "qarz hisoblanadigan odamning xabariga reply qilib yuboring."
            )
            return
        user = await _current_user(session, message)
        other = await upsert_user(session, reply.from_user)
        await link_users(session, user, other)
        await session.commit()
        await state.update_data(contact_id=other.id)
        await state.set_state(AddDebtStates.waiting_for_direction)
        await message.answer(
            f"<b>{_user_label(other)}</b> bilan operatsiya.\n\n"
            "Qarz yo'nalishini tanlang:\n"
            "• <b>Oldim</b> — men qarzdorman.\n"
            "• <b>Berdim</b> — undan olishim kerak.",
            reply_markup=direction_keyboard(),
        )
        return

    user = await _ensure_registered(session, message)
    contacts = await get_contacts(session, user)
    if not contacts:
        await message.answer(
            "Avval /invite orqali kamida bitta foydalanuvchini ulang."
        )
        return
    await state.set_state(AddDebtStates.waiting_for_contact)
    await message.answer(
        "Kim bilan qarz kiritasiz?",
        reply_markup=contacts_keyboard(contacts, "add_contact"),
    )


@router.callback_query(
    AddDebtStates.waiting_for_contact, F.data.startswith("add_contact:")
)
async def add_contact_callback(
    callback: CallbackQuery, state: FSMContext
) -> None:
    contact_id = int(callback.data.split(":", 1)[1])
    await state.update_data(contact_id=contact_id)
    await state.set_state(AddDebtStates.waiting_for_direction)
    await callback.message.edit_text(
        "Qarz yo'nalishini tanlang:\n\n"
        "• <b>Oldim</b> — men qarzdorman.\n"
        "• <b>Berdim</b> — undan olishim kerak.",
        reply_markup=direction_keyboard(),
    )
    await callback.answer()


@router.callback_query(
    AddDebtStates.waiting_for_direction, F.data.startswith("direction:")
)
async def direction_callback(callback: CallbackQuery, state: FSMContext) -> None:
    direction = callback.data.split(":", 1)[1]
    await state.update_data(direction=direction)
    await state.set_state(AddDebtStates.waiting_for_currency)
    await callback.message.edit_text(
        "Valyutani tanlang:",
        reply_markup=currency_keyboard(),
    )
    await callback.answer()


@router.callback_query(
    AddDebtStates.waiting_for_currency, F.data == "currency:OTHER"
)
async def custom_currency_start_callback(
    callback: CallbackQuery, state: FSMContext
) -> None:
    await state.set_state(AddDebtStates.waiting_for_custom_currency)
    await callback.message.edit_text(
        "Valyuta kodini 3 ta lotin harfi bilan yuboring.\n"
        "Masalan: <code>KWD</code>, <code>CAD</code> yoki <code>JPY</code>"
    )
    await callback.answer()


@router.callback_query(
    AddDebtStates.waiting_for_currency,
    F.data.startswith("currency:") & (F.data != "currency:OTHER"),
)
async def currency_callback(callback: CallbackQuery, state: FSMContext) -> None:
    currency = callback.data.split(":", 1)[1]
    await state.update_data(currency=currency)
    await state.set_state(AddDebtStates.waiting_for_amount)
    await callback.message.edit_text(
        f"Tanlangan valyuta: <b>{currency_name(currency)}</b>\n\n"
        "Summani faqat musbat butun son ko'rinishida yuboring.\n"
        "Masalan: <code>50000</code>"
    )
    await callback.answer()


@router.message(AddDebtStates.waiting_for_custom_currency)
async def custom_currency_handler(message: Message, state: FSMContext) -> None:
    currency = (message.text or "").strip().upper()
    if not is_valid_currency_code(currency):
        await message.answer(
            "Valyuta kodi aynan 3 ta lotin harfidan iborat bo'lishi kerak.\n"
            "Masalan: <code>KWD</code>"
        )
        return
    await state.update_data(currency=currency)
    await state.set_state(AddDebtStates.waiting_for_amount)
    await message.answer(
        f"Tanlangan valyuta: <b>{currency}</b>\n\n"
        "Summani faqat musbat butun son ko'rinishida yuboring.\n"
        "Masalan: <code>50000</code>"
    )


@router.message(AddDebtStates.waiting_for_amount)
async def amount_handler(message: Message, state: FSMContext) -> None:
    raw_amount = (message.text or "").replace(" ", "").replace(",", "")
    if not raw_amount.isdigit() or int(raw_amount) <= 0:
        await message.answer("Iltimos, noldan katta butun summa kiriting.")
        return
    await state.update_data(amount=int(raw_amount))
    await state.set_state(AddDebtStates.waiting_for_note)
    await message.answer(
        "Izoh yuboring yoki tugmani bosing:",
        reply_markup=skip_note_keyboard(),
    )


@router.message(AddDebtStates.waiting_for_note)
async def note_handler(message: Message, state: FSMContext) -> None:
    note = (
        None
        if (message.text or "").strip().lower()
        in {SKIP_NOTE.lower(), "otkazib yuborish", "skip"}
        else message.text
    )
    await state.update_data(note=note)
    await state.set_state(AddDebtStates.waiting_for_due_date)
    await message.answer(
        "Qaytarish muddatini kiriting yoki tugmani bosing.\n"
        "Masalan: <code>20.08.2026</code> yoki <code>20.08</code>",
        reply_markup=skip_due_keyboard(),
    )


@router.message(AddDebtStates.waiting_for_due_date)
async def due_date_handler(
    message: Message, state: FSMContext, session: AsyncSession, bot: Bot
) -> None:
    raw = (message.text or "").strip()
    due_date = None
    if raw.lower() not in {SKIP_DUE.lower(), "muddatsiz", "skip"}:
        try:
            due_date = parse_due_date(raw, today_uzbekistan())
        except ValueError as error:
            await message.answer(str(error), reply_markup=skip_due_keyboard())
            return

    data = await state.get_data()
    other = await session.get(User, data["contact_id"])
    if other is None:
        await state.clear()
        await message.answer("Kontakt topilmadi. Qaytadan /add ni bosing.")
        return

    direction = TransactionDirection(data["direction"])
    money = format_money(int(data["amount"]), data.get("currency", "UZS"))
    direction_text = (
        "Oldim — men qarzdorman"
        if direction == TransactionDirection.RECEIVED
        else "Berdim — undan olishim kerak"
    )
    balance_effect = (
        "Tasdiqlangach sizning qarzingiz oshadi."
        if direction == TransactionDirection.RECEIVED
        else "Tasdiqlangach uning sizga qarzi oshadi."
    )
    note_text = escape(data["note"]) if data.get("note") else "—"
    due_text = format_uzbekistan_date(due_date) if due_date else "Muddatsiz"
    await state.update_data(
        due_date=due_date.isoformat() if due_date else None,
        scope_chat_id=_scope_chat_id(message),
        confirmation_ready=True,
        confirmation_nonce=(confirmation_nonce := secrets.token_urlsafe(8)),
    )
    await state.set_state(AddDebtStates.waiting_for_confirmation)
    await message.answer(
        "<b>Yuborishdan oldingi xulosa</b>\n\n"
        f"Kontakt: <b>{_user_label(other)}</b>\n"
        f"Qarz yo'nalishi: <b>{direction_text}</b>\n"
        f"Summa: <b>{money}</b>\n"
        f"Muddat: <b>{due_text}</b>\n"
        f"Izoh: {note_text}\n\n"
        f"{balance_effect}\n"
        "Balans faqat ikkinchi tomon tasdiqlagach yangilanadi.",
        reply_markup=review_transaction_keyboard(confirmation_nonce),
    )


@router.callback_query(F.data.startswith("add:confirm:"))
async def add_confirm_callback(
    callback: CallbackQuery, state: FSMContext, session: AsyncSession, bot: Bot
) -> None:
    async with _add_confirm_locks[callback.from_user.id]:
        data = await state.get_data()
        callback_nonce = callback.data.rsplit(":", 1)[-1]
        if (
            not data.get("confirmation_ready")
            or not secrets.compare_digest(
                callback_nonce, str(data.get("confirmation_nonce", ""))
            )
        ):
            await callback.answer(
                "Bu tasdiqlash tugmasi eskirgan, yuborilgan yoki bekor qilingan.",
                show_alert=True,
            )
            return

        # Claim this confirmation before the first database await. Concurrent
        # callbacks for the same user then observe an empty state and cannot
        # create or notify a duplicate transaction.
        await state.clear()
        await callback.message.edit_text("⏳ Qarz so'rovi yuborilmoqda...")

        user = await get_user_by_telegram_id(session, callback.from_user.id)
        contact_id = data.get("contact_id")
        other = await session.get(User, contact_id) if contact_id else None
        if user is None or other is None:
            await callback.answer(
                "Foydalanuvchi topilmadi. /add ni qayta boshlang.",
                show_alert=True,
            )
            return
        due_date_raw = data.get("due_date")
        try:
            transaction = await create_transaction(
                session,
                entered_by=user,
                other=other,
                direction=TransactionDirection(data["direction"]),
                amount=int(data["amount"]),
                currency=data.get("currency", "UZS"),
                scope_chat_id=int(data.get("scope_chat_id", 0)),
                note=data.get("note"),
                status=TransactionStatus.PENDING,
                due_date=date.fromisoformat(due_date_raw) if due_date_raw else None,
            )
        except (KeyError, TypeError, ValueError) as error:
            await session.rollback()
            await callback.message.edit_text(
                "❌ Qarz so'rovini yuborib bo'lmadi. /add ni qayta boshlang."
            )
            await callback.answer(
                f"Yuborib bo'lmadi: {error}",
                show_alert=True,
            )
            return
        await session.commit()
        await callback.message.edit_text("✅ Qarz so'rovi yuborildi. Tafsilotlar quyida.")
        await _notify_and_summarize(callback.message, session, bot, user, other, transaction)
        await callback.answer("Yuborildi")


async def _notify_and_summarize(
    message: Message,
    session: AsyncSession,
    bot: Bot,
    user: User,
    other: User,
    transaction: Transaction,
) -> None:
    """Send the confirmation request to the counterparty and summarize.

    Shared by the step-by-step /add flow and the quick /oldim /berdim
    commands. The transaction must already be committed as PENDING.
    """
    direction = TransactionDirection(transaction.direction)
    money = format_money(transaction.amount, transaction.currency)
    saved_at = format_uzbekistan_datetime(transaction.created_at)
    due_line = (
        f"\nMuddat: ⏰ {format_uzbekistan_date(transaction.due_date)}"
        if transaction.due_date
        else ""
    )

    # From the counterparty's perspective the direction is inverted.
    if direction == TransactionDirection.RECEIVED:
        other_view = f"Siz <b>{_user_label(user)}</b> ga <b>{money}</b> berdingiz."
    else:
        other_view = f"Siz <b>{_user_label(user)}</b> dan <b>{money}</b> oldingiz."
    note_line = f"\nIzoh: {escape(transaction.note)}" if transaction.note else ""

    notification_delivered = await _send_queued_pending_notification(
        bot,
        session,
        transaction.id,
        other.telegram_id,
        "🔔 <b>Yangi qarz so'rovi — tasdiqlash kutilmoqda</b>\n\n"
        f"{other_view}{note_line}{due_line}\n"
        f"Vaqt: {saved_at}\n\n"
        "To'g'ri bo'lsa tasdiqlang, xato bo'lsa rad eting:",
        reply_markup=confirm_transaction_keyboard(transaction.id),
    )

    if direction == TransactionDirection.RECEIVED:
        summary = (
            f"Siz <b>{_user_label(other)}</b> dan {money} oldingiz. "
            "Sizning qarzingiz oshadi."
        )
    else:
        summary = (
            f"Siz <b>{_user_label(other)}</b> ga {money} berdingiz. "
            "Uning sizga qarzi oshadi."
        )
    if notification_delivered:
        status_line = "⏳ Balans ikkinchi tomon tasdiqlagach yangilanadi."
    else:
        status_line = (
            "⏳ Tasdiqlash xabari yetkazilmadi. Tranzaksiya kutilmoqda "
            "holatida qoldi — ikkinchi tomon /pending, web yoki mobil "
            "ilovadan tasdiqlagach balansga qo'shiladi."
        )
    await message.answer(
        f"✅ Saqlandi — qarz so'rovi yuborildi.\n\n"
        f"{summary}{due_line}\nVaqt: {saved_at}\n\n{status_line}",
        reply_markup=main_menu_keyboard(),
    )


QUICK_USAGE = (
    "<b>Tezkor kiritish:</b>\n"
    "<code>/oldim 50000 @user izoh</code> — siz @user'dan oldingiz\n"
    "<code>/berdim 100 USD @user izoh</code> — siz @user'ga berdingiz\n"
    "Valyuta ko'rsatilmasa UZS. Guruhda esa @user o'rniga "
    "odamning xabariga reply qiling."
)


async def _quick_add(
    message: Message,
    command: CommandObject,
    session: AsyncSession,
    bot: Bot,
    direction: TransactionDirection,
) -> None:
    user = await _current_user(session, message)
    try:
        entry = parse_quick_entry(command.args or "")
    except ValueError as error:
        await session.commit()
        await message.answer(f"{error}\n\n{QUICK_USAGE}")
        return

    is_group = message.chat.type in {"group", "supergroup"}
    other: User | None = None

    if is_group:
        reply = message.reply_to_message
        if (
            reply is not None
            and reply.from_user is not None
            and not reply.from_user.is_bot
            and reply.from_user.id != message.from_user.id
        ):
            other = await upsert_user(session, reply.from_user)
            await link_users(session, user, other)

    if other is None and entry.username:
        other = await find_contact_by_username(session, user, entry.username)
        if other is None:
            contacts = await get_contacts(session, user)
            await session.commit()
            if contacts:
                names = "\n".join(
                    f"• {_user_label(c)}" for c in contacts[:20]
                )
                await message.answer(
                    f"<b>@{escape(entry.username)}</b> kontaktlaringiz orasida "
                    f"topilmadi.\n\nMavjud kontaktlar:\n{names}\n\n"
                    "Yangi kontakt uchun /invite dan foydalaning."
                )
            else:
                await message.answer(
                    "Hali kontaktlaringiz yo'q. Avval /invite orqali "
                    "foydalanuvchini ulang."
                )
            return

    if other is None:
        await session.commit()
        if is_group:
            await message.answer(
                "Kimga tegishli ekanini ko'rsating: odamning xabariga "
                f"reply qiling yoki @username yozing.\n\n{QUICK_USAGE}"
            )
        else:
            await message.answer(
                f"@username ko'rsatilmadi.\n\n{QUICK_USAGE}"
            )
        return

    if other.id == user.id:
        await session.commit()
        await message.answer("O'zingizga tranzaksiya kiritib bo'lmaydi.")
        return

    try:
        transaction = await create_transaction(
            session,
            entered_by=user,
            other=other,
            direction=direction,
            amount=entry.amount,
            currency=entry.currency,
            scope_chat_id=_scope_chat_id(message),
            note=entry.note,
            status=TransactionStatus.PENDING,
        )
    except ValueError as error:
        await session.rollback()
        await message.answer(str(error))
        return
    await session.commit()
    await _notify_and_summarize(message, session, bot, user, other, transaction)


@router.message(Command("oldim"))
async def quick_received_handler(
    message: Message, command: CommandObject, session: AsyncSession, bot: Bot
) -> None:
    await _quick_add(
        message, command, session, bot, TransactionDirection.RECEIVED
    )


@router.message(Command("berdim"))
async def quick_given_handler(
    message: Message, command: CommandObject, session: AsyncSession, bot: Bot
) -> None:
    await _quick_add(message, command, session, bot, TransactionDirection.GIVEN)


async def _transaction_participants(
    session: AsyncSession, transaction: Transaction
) -> tuple[User | None, User | None]:
    """(entered_by, counterparty) users of a transaction."""
    entered_by = await session.get(User, transaction.entered_by_id)
    other_id = (
        transaction.creditor_id
        if transaction.debtor_id == transaction.entered_by_id
        else transaction.debtor_id
    )
    other = await session.get(User, other_id)
    return entered_by, other


@router.callback_query(F.data.startswith("txconfirm:"))
async def confirm_transaction_callback(
    callback: CallbackQuery, session: AsyncSession, bot: Bot
) -> None:
    transaction = await get_transaction(
        session, int(callback.data.split(":", 1)[1])
    )
    if transaction is None or transaction.status not in {
        TransactionStatus.PENDING,
        TransactionStatus.REPAYMENT_PENDING,
    }:
        await callback.answer("Bu tranzaksiya allaqachon ko'rib chiqilgan.", show_alert=True)
        return
    entered_by, other = await _transaction_participants(session, transaction)
    if other is None or other.telegram_id != callback.from_user.id:
        await callback.answer("Bu tranzaksiyani faqat ikkinchi tomon tasdiqlaydi.", show_alert=True)
        return

    try:
        changed = await set_transaction_status(
            session,
            transaction,
            (
                TransactionStatus.REPAYMENT
                if transaction.status == TransactionStatus.REPAYMENT_PENDING
                else TransactionStatus.CONFIRMED
            ),
            expected_status=transaction.status,
        )
    except ValueError as error:
        await session.rollback()
        await callback.answer(str(error), show_alert=True)
        return
    if not changed:
        await session.rollback()
        await callback.answer("Bu tranzaksiya allaqachon ko'rib chiqilgan.", show_alert=True)
        return
    await session.commit()
    money = format_money(transaction.amount, transaction.currency)
    is_repayment = transaction.status == TransactionStatus.REPAYMENT
    await callback.message.edit_text(
        (
            f"✅ Qaytaruv tasdiqlandi: {money}\nBalans yangilandi."
            if is_repayment
            else f"✅ Tasdiqlandi — qarz: {money}\nBalans yangilandi."
        )
    )
    await callback.answer("Tasdiqlandi")
    if entered_by:
        try:
            await bot.send_message(
                entered_by.telegram_id,
                (
                    f"✅ <b>{_user_label(other)}</b> {money} miqdoridagi "
                    "qaytaruvni tasdiqladi. Balans yangilandi."
                    if is_repayment
                    else f"✅ <b>{_user_label(other)}</b> {money} miqdoridagi "
                    "qarz so'rovini tasdiqladi. Balans yangilandi."
                ),
            )
        except Exception:
            pass


@router.callback_query(F.data.startswith("txreject:"))
async def reject_transaction_callback(
    callback: CallbackQuery, session: AsyncSession, bot: Bot
) -> None:
    transaction = await get_transaction(
        session, int(callback.data.split(":", 1)[1])
    )
    if transaction is None or transaction.status not in {
        TransactionStatus.PENDING,
        TransactionStatus.REPAYMENT_PENDING,
    }:
        await callback.answer("Bu tranzaksiya allaqachon ko'rib chiqilgan.", show_alert=True)
        return
    entered_by, other = await _transaction_participants(session, transaction)
    if other is None or other.telegram_id != callback.from_user.id:
        await callback.answer("Bu tranzaksiyani faqat ikkinchi tomon rad etadi.", show_alert=True)
        return

    try:
        changed = await set_transaction_status(
            session,
            transaction,
            TransactionStatus.REJECTED,
            expected_status=transaction.status,
        )
    except ValueError as error:
        await session.rollback()
        await callback.answer(str(error), show_alert=True)
        return
    if not changed:
        await session.rollback()
        await callback.answer("Bu tranzaksiya allaqachon ko'rib chiqilgan.", show_alert=True)
        return
    await session.commit()
    money = format_money(transaction.amount, transaction.currency)
    is_repayment = transaction.status == TransactionStatus.REPAYMENT_PENDING
    await callback.message.edit_text(
        (
            f"❌ Qaytaruv rad etildi: {money}\nBalans o'zgarmadi."
            if is_repayment
            else f"❌ Rad etildi — qarz: {money}\nU balansga qo'shilmadi."
        )
    )
    await callback.answer("Rad etildi")
    if entered_by:
        try:
            await bot.send_message(
                entered_by.telegram_id,
                (
                    f"❌ <b>{_user_label(other)}</b> {money} miqdoridagi "
                    "qaytaruvni rad etdi. Balans o'zgarmadi."
                    if is_repayment
                    else f"❌ <b>{_user_label(other)}</b> {money} miqdoridagi "
                    "qarz so'rovini rad etdi. U balansga qo'shilmadi.\n"
                    "Xato bo'lsa, qarzni qaytadan kiriting."
                ),
            )
        except Exception:
            pass


async def _pin_required(
    message: Message,
    state: FSMContext,
    user: User,
    pending: str,
) -> bool:
    """True when the command must wait for a PIN first.

    The PIN only applies in private chats; group views stay untouched.
    """
    if _scope_chat_id(message) != 0:
        return False
    if not user.pin_hash or pin_gate.is_unlocked(user.id):
        return False
    await state.set_state(PinStates.waiting_for_unlock)
    await state.update_data(pin_pending=pending)
    remaining = pin_module.lockout_remaining(
        user.pin_locked_until, now_uzbekistan()
    )
    if remaining:
        await message.answer(
            f"⏳ Juda ko'p xato urinish. {remaining} soniyadan so'ng "
            "qayta urinib ko'ring."
        )
    else:
        await message.answer(
            "🔒 4 xonali PIN kodingizni kiriting.\n"
            "Bekor qilish uchun /cancel yozing."
        )
    return True


async def _pin_required_callback(
    callback: CallbackQuery,
    state: FSMContext,
    user: User,
    pending: str,
) -> bool:
    """PIN gate for callbacks fired from stale keyboards (e.g. a history
    contact list rendered before the 5-minute unlock expired)."""
    if callback.message is None or callback.message.chat.type != "private":
        return False
    if not user.pin_hash or pin_gate.is_unlocked(user.id):
        return False
    await state.set_state(PinStates.waiting_for_unlock)
    await state.update_data(pin_pending=pending)
    remaining = pin_module.lockout_remaining(
        user.pin_locked_until, now_uzbekistan()
    )
    if remaining:
        await callback.message.answer(
            f"⏳ Juda ko'p xato urinish. {remaining} soniyadan so'ng "
            "qayta urinib ko'ring."
        )
    else:
        await callback.message.answer(
            "🔒 PIN sessiyasi tugagan. 4 xonali PIN kodingizni kiriting.\n"
            "Bekor qilish uchun /cancel yozing."
        )
    await callback.answer("PIN talab qilinadi")
    return True


def _is_pin_cancel(text: str) -> bool:
    """Any command or explicit cancel word aborts the PIN flow — commands
    must never be swallowed as wrong PIN attempts."""
    t = text.strip().lower()
    return t.startswith("/") or t in {"bekor", "bekor qilish"}


@router.message(Command("balance"))
async def balance_handler(
    message: Message, state: FSMContext, session: AsyncSession
) -> None:
    user = await _ensure_registered(session, message)
    if await _pin_required(message, state, user, "balance"):
        return
    await _send_balance(message, session, user)


async def _send_balance(
    message: Message, session: AsyncSession, user: User
) -> None:
    balances = await get_balances(session, user, _scope_chat_id(message))
    if not balances:
        await message.answer("Hozircha faol qarzlar yo'q.")
        return
    scope_chat_id = _scope_chat_id(message)
    today = today_uzbekistan()
    lines = ["<b>Joriy balanslar</b>\n"]
    for item in balances:
        breakdown = await get_balance_breakdown(
            session,
            user_id=user.id,
            other_user_id=item.other.id,
            currency=item.currency,
            scope_chat_id=scope_chat_id,
        )
        debtor_id, creditor_id = (
            (user.id, item.other.id)
            if item.user_owes_other
            else (item.other.id, user.id)
        )
        due = await get_nearest_due_date(
            session, debtor_id, creditor_id, item.currency, scope_chat_id
        )
        if due is None:
            due_text = ""
        elif due < today:
            due_text = f" — ❗️ muddati o'tgan ({format_uzbekistan_date(due)})"
        else:
            due_text = f" — ⏰ muddat: {format_uzbekistan_date(due)}"
        if item.user_owes_other:
            lines.append(
                f"• Siz <b>{_user_label(item.other)}</b> ga "
                f"<b>{format_money(item.amount, item.currency)}</b> qarzdorsiz."
                f"{due_text}"
            )
        else:
            lines.append(
                f"• <b>{_user_label(item.other)}</b> sizga "
                f"<b>{format_money(item.amount, item.currency)}</b> berishi kerak."
                f"{due_text}"
            )
        lines.append(
            f"  Berdingiz: {format_money(breakdown.lent_total, item.currency)} | "
            f"Oldingiz: {format_money(breakdown.borrowed_total, item.currency)}\n"
            f"  Qaytardingiz: {format_money(breakdown.repaid_by_user, item.currency)} | "
            f"Sizga qaytarildi: {format_money(breakdown.repaid_to_user, item.currency)}"
        )
    repayable = [
        (item.other, item.currency) for item in balances if item.user_owes_other
    ]
    if repayable:
        lines.append("\nQarzni qaytargan bo'lsangiz, qaytaruvni kiriting:")
        await message.answer(
            "\n".join(lines), reply_markup=balance_repay_keyboard(repayable)
        )
    else:
        await message.answer("\n".join(lines))


@router.callback_query(F.data.startswith("repay:"))
async def repay_start_callback(
    callback: CallbackQuery, state: FSMContext, session: AsyncSession
) -> None:
    _, other_id_raw, currency = callback.data.split(":", 2)
    user = await get_user_by_telegram_id(session, callback.from_user.id)
    other = await session.get(User, int(other_id_raw))
    if user is None or other is None:
        await callback.answer("Foydalanuvchi topilmadi.", show_alert=True)
        return
    # The repay keyboard comes from a /balance view — it may be a stale
    # message left on screen after the PIN session expired.
    if await _pin_required_callback(callback, state, user, "balance"):
        return
    scope_chat_id = _scope_chat_id(callback.message)
    debt = await get_debt_between(
        session, user.id, other.id, currency, scope_chat_id
    )
    if debt <= 0:
        await callback.answer(
            "Bu yo'nalishda faol qarz yo'q.", show_alert=True
        )
        return
    await state.set_state(RepayStates.waiting_for_amount)
    await state.update_data(
        repay_other_id=other.id,
        repay_currency=currency,
        repay_scope=scope_chat_id,
    )
    await callback.message.answer(
        f"<b>{_user_label(other)}</b> ga qarzingiz: "
        f"<b>{format_money(debt, currency)}</b>\n\n"
        "Qaytargan summani yuboring (to'liq yoki qisman).\n"
        f"Masalan: <code>{debt}</code>"
    )
    await callback.answer()


@router.message(RepayStates.waiting_for_amount)
async def repay_amount_handler(
    message: Message, state: FSMContext, session: AsyncSession, bot: Bot
) -> None:
    raw_amount = (message.text or "").replace(" ", "").replace(",", "")
    if not raw_amount.isdigit() or int(raw_amount) <= 0:
        await message.answer("Iltimos, noldan katta butun summa kiriting.")
        return
    amount = int(raw_amount)
    data = await state.get_data()
    user = await _current_user(session, message)
    other = await session.get(User, data["repay_other_id"])
    currency = data["repay_currency"]
    scope_chat_id = int(data["repay_scope"])
    if other is None:
        await state.clear()
        await message.answer("Kontakt topilmadi. Qaytadan /balance ni bosing.")
        return
    # Informational read only. The authoritative overdraft check happens
    # inside create_transaction's balance recalculation, which serializes
    # concurrent repayments via the pair advisory lock.
    debt = await get_debt_between(
        session, user.id, other.id, currency, scope_chat_id
    )
    if debt <= 0:
        await state.clear()
        await message.answer("Bu yo'nalishda faol qarz qolmagan.")
        return
    if amount > debt:
        await message.answer(
            f"Qarzingiz {format_money(debt, currency)}. "
            "Undan katta summa kiritib bo'lmaydi. Qaytadan kiriting."
        )
        return

    try:
        transaction = await create_transaction(
            session,
            entered_by=user,
            other=other,
            direction=TransactionDirection.GIVEN,
            amount=amount,
            currency=currency,
            scope_chat_id=scope_chat_id,
            note="Qaytaruv",
            status=TransactionStatus.REPAYMENT_PENDING,
        )
    except ValueError:
        # The ledger invariant rejected the repayment (e.g. a concurrent
        # repayment already covered the debt).
        await session.rollback()
        await state.clear()
        await message.answer(
            "Qarz miqdori shu orada o'zgargan. /balance ni qayta oching "
            "va qaytaruvni qaytadan kiriting.",
            reply_markup=main_menu_keyboard(),
        )
        return
    await session.commit()
    await state.clear()

    await message.answer(
        f"✅ Qaytaruv so'rovi yuborildi: {format_money(amount, currency)}\n"
        "Balans ikkinchi tomon tasdiqlagach yangilanadi.",
        reply_markup=main_menu_keyboard(),
    )
    notification_delivered = await _send_queued_pending_notification(
        bot,
        session,
        transaction.id,
        other.telegram_id,
        f"🔔 <b>{_user_label(user)}</b> sizga "
        f"{format_money(amount, currency)} qaytaruv kiritdi.\n\n"
        "To'g'ri bo'lsa tasdiqlang, xato bo'lsa rad eting:",
        reply_markup=confirm_transaction_keyboard(transaction.id),
    )
    if not notification_delivered:
        await message.answer(
            "Tasdiqlash xabari yetkazilmadi. Qaytaruv pending holatda qoldi — "
            "ikkinchi tomon /pending, web yoki mobil ilovadan tasdiqlashi mumkin."
        )


@router.message(Command("history"))
async def history_handler(
    message: Message, state: FSMContext, session: AsyncSession
) -> None:
    user = await _ensure_registered(session, message)
    if await _pin_required(message, state, user, "history"):
        return
    await _start_history(message, state, session, user)


async def _start_history(
    message: Message, state: FSMContext, session: AsyncSession, user: User
) -> None:
    contacts = await get_contacts(session, user)
    if not contacts:
        await message.answer("Tarix ko'rish uchun avval /invite orqali kontakt ulang.")
        return
    await state.set_state(HistoryStates.waiting_for_contact)
    await message.answer(
        "Qaysi foydalanuvchi bilan tarixni ko'ramiz?",
        reply_markup=contacts_keyboard(contacts, "history_contact"),
    )


@router.callback_query(
    HistoryStates.waiting_for_contact, F.data.startswith("history_contact:")
)
async def history_contact_callback(
    callback: CallbackQuery, state: FSMContext, session: AsyncSession
) -> None:
    user = await session.scalar(
        select(User).where(
            User.telegram_id == callback.from_user.id
        )
    )
    if user is None:
        await state.clear()
        await callback.answer("Avval /start ni bosing.", show_alert=True)
        return
    if await _pin_required_callback(callback, state, user, "history"):
        return
    other = await session.get(User, int(callback.data.split(":", 1)[1]))
    if other is None:
        await state.clear()
        await callback.answer("Kontakt topilmadi.", show_alert=True)
        return
    transactions = await get_pair_transactions(
        session,
        user_id=user.id,
        other_user_id=other.id,
        scope_chat_id=_scope_chat_id(callback.message),
    )
    await state.clear()
    hide_items = []
    for tx in transactions:
        if await can_hide_transaction(session, tx, user.id):
            hide_items.append((tx.id, f"{format_money(tx.amount, tx.currency)}"))
    if not transactions:
        text = f"<b>{_user_label(other)}</b> bilan tranzaksiyalar yo'q."
        markup = None
    else:
        lines = [f"<b>{_user_label(other)} bilan tarix</b>\n"]
        for tx in transactions:
            date = format_uzbekistan_datetime(tx.created_at)
            action = _history_action(tx, user)
            note = f" — {escape(tx.note)}" if tx.note else ""
            mark = _status_mark(tx.status)
            due = _due_suffix(tx)
            lines.append(
                f"• {date} | {mark}{action}: "
                f"<b>{format_money(tx.amount, tx.currency)}</b>{note}{due}"
                f"{_pending_next_action(tx, user)}"
            )
        text = "\n".join(lines)
        markup = history_hide_keyboard(hide_items, f"pair-{other.id}") if hide_items else None
    await callback.message.edit_text(text, reply_markup=markup)
    await callback.answer()


@router.callback_query(F.data.startswith("historyhide:"))
async def history_hide_callback(
    callback: CallbackQuery, session: AsyncSession
) -> None:
    parts = callback.data.split(":")
    if len(parts) != 3:
        await callback.answer("Tarix amali noto'g'ri.", show_alert=True)
        return
    scope, raw_transaction_id = parts[1], parts[2]
    try:
        transaction_id = int(raw_transaction_id)
    except ValueError:
        await callback.answer("Tranzaksiya topilmadi.", show_alert=True)
        return
    user = await get_user_by_telegram_id(session, callback.from_user.id)
    transaction = await get_transaction(session, transaction_id)
    if user is None or transaction is None or user.id not in {
        transaction.debtor_id,
        transaction.creditor_id,
    }:
        await callback.answer("Bu yozuvni yashirishga ruxsat yo'q.", show_alert=True)
        return
    if not await hide_transaction_for_user(session, transaction, user.id):
        await callback.answer(
            "Faqat rad etilgan yoki to'liq yopilgan qarzni yashirish mumkin.",
            show_alert=True,
        )
        return
    await session.commit()
    if scope == "all":
        transactions = await get_all_transactions(
            session, user.id, _scope_chat_id(callback.message)
        )
        title = "<b>So'nggi operatsiyalar</b>\n"
        markup_scope = "all"
    elif scope.startswith("pair-"):
        try:
            other_id = int(scope.split("-", 1)[1])
        except ValueError:
            await callback.answer("Kontakt topilmadi.", show_alert=True)
            return
        other = await session.get(User, other_id)
        if other is None:
            await callback.answer("Kontakt topilmadi.", show_alert=True)
            return
        transactions = await get_pair_transactions(
            session,
            user_id=user.id,
            other_user_id=other.id,
            scope_chat_id=_scope_chat_id(callback.message),
        )
        title = f"<b>{_user_label(other)} bilan tarix</b>\n"
        markup_scope = f"pair-{other.id}"
    else:
        await callback.answer("Yashirildi.")
        return
    if not transactions:
        await callback.message.edit_text(
            title + "\nHozircha ko'rsatiladigan yozuv yo'q."
        )
    else:
        lines = [title]
        hide_items = []
        for tx in transactions:
            other_id = tx.creditor_id if tx.debtor_id == user.id else tx.debtor_id
            other = await session.get(User, other_id)
            if other is None:
                continue
            lines.append(
                f"• {format_uzbekistan_datetime(tx.created_at)} | "
                f"{_status_mark(tx.status)}{_history_action(tx, user)}: "
                f"<b>{format_money(tx.amount, tx.currency)}</b>"
                f"{_pending_next_action(tx, user)}"
            )
            if await can_hide_transaction(session, tx, user.id):
                hide_items.append((tx.id, format_money(tx.amount, tx.currency)))
        await callback.message.edit_text(
            "\n".join(lines),
            reply_markup=history_hide_keyboard(hide_items, markup_scope)
            if hide_items
            else None,
        )
    await callback.answer("Yozuv sizning tarixingizdan yashirildi.")


async def _delete_pin_message(message: Message) -> None:
    """Remove the message containing a PIN so it never stays in the chat."""
    try:
        await message.delete()
    except Exception:
        pass


@router.message(PinStates.waiting_for_unlock)
async def pin_unlock_handler(
    message: Message, state: FSMContext, session: AsyncSession
) -> None:
    text = message.text or ""
    if _is_pin_cancel(text):
        await state.clear()
        await message.answer(
            "Bekor qilindi. Kerakli buyruqni qaytadan yuboring.",
            reply_markup=main_menu_keyboard(),
        )
        return
    pin = text.strip()
    await _delete_pin_message(message)
    user = await _current_user(session, message)
    if not user.pin_hash:
        await session.commit()
        await state.clear()
        await message.answer("PIN o'rnatilmagan.", reply_markup=main_menu_keyboard())
        return

    now = now_uzbekistan()
    remaining_lockout = pin_module.lockout_remaining(user.pin_locked_until, now)
    if remaining_lockout:
        await session.commit()
        await message.answer(
            f"⏳ Juda ko'p xato urinish. {remaining_lockout} soniyadan "
            "so'ng qayta urinib ko'ring."
        )
        return

    if not is_valid_pin(pin) or not verify_pin(pin, user.pin_hash):
        attempts_left = await register_pin_failure(session, user.id, now)
        await session.commit()
        if attempts_left == 0:
            await message.answer(
                "🚫 3 marta xato kiritildi. 1 daqiqa kutib, "
                "keyin qayta urinib ko'ring."
            )
        else:
            await message.answer(
                f"❌ PIN noto'g'ri. Yana {attempts_left} ta urinish qoldi."
            )
        return

    pin_module.clear_failures(user)
    await session.commit()
    pin_gate.unlock(user.id)
    data = await state.get_data()
    pending = data.get("pin_pending")
    await state.clear()
    await message.answer("🔓 Ochildi. 5 daqiqa davomida PIN qayta so'ralmaydi.")
    if pending == "balance":
        await _send_balance(message, session, user)
    elif pending == "history":
        await _start_history(message, state, session, user)
    elif pending == "all_history":
        await _send_all_history(message, session, user)


@router.callback_query(F.data == "privacy:menu")
async def privacy_menu_callback(
    callback: CallbackQuery, session: AsyncSession
) -> None:
    user = await get_user_by_telegram_id(session, callback.from_user.id)
    if user is None:
        await callback.answer("Avval /start ni bosing.", show_alert=True)
        return
    if callback.message.chat.type != "private":
        await callback.answer(
            "Maxfiylik sozlamalari faqat shaxsiy chatda.", show_alert=True
        )
        return
    status = (
        "🔒 PIN yoqilgan. /balance, /history va /all_history "
        "shaxsiy chatda PIN so'raydi."
        if user.pin_hash
        else "🔓 PIN o'rnatilmagan."
    )
    await callback.message.edit_text(
        f"<b>Maxfiylik</b>\n\n{status}",
        reply_markup=privacy_menu_keyboard(bool(user.pin_hash)),
    )
    await callback.answer()


@router.callback_query(F.data.in_({"privacy:set", "privacy:change", "privacy:remove"}))
async def privacy_action_callback(
    callback: CallbackQuery, state: FSMContext, session: AsyncSession
) -> None:
    user = await get_user_by_telegram_id(session, callback.from_user.id)
    if user is None:
        await callback.answer("Avval /start ni bosing.", show_alert=True)
        return
    if callback.message.chat.type != "private":
        await callback.answer(
            "Maxfiylik sozlamalari faqat shaxsiy chatda.", show_alert=True
        )
        return
    action = callback.data.split(":", 1)[1]
    if action == "set":
        if user.pin_hash:
            await callback.answer("PIN allaqachon o'rnatilgan.", show_alert=True)
            return
        await state.set_state(PinStates.waiting_for_new)
        await callback.message.edit_text(
            "Yangi 4 xonali PIN yuboring. Xabar darhol o'chiriladi."
        )
    else:
        if not user.pin_hash:
            await callback.answer("PIN o'rnatilmagan.", show_alert=True)
            return
        await state.set_state(PinStates.waiting_for_current)
        await state.update_data(pin_mode=action)
        await callback.message.edit_text(
            "Joriy PIN kodingizni yuboring. Xabar darhol o'chiriladi."
        )
    await callback.answer()


@router.message(PinStates.waiting_for_current)
async def pin_current_handler(
    message: Message, state: FSMContext, session: AsyncSession
) -> None:
    text = message.text or ""
    if _is_pin_cancel(text):
        await state.clear()
        await message.answer(
            "Bekor qilindi.", reply_markup=main_menu_keyboard()
        )
        return
    pin = text.strip()
    await _delete_pin_message(message)
    user = await _current_user(session, message)

    now = now_uzbekistan()
    remaining_lockout = pin_module.lockout_remaining(user.pin_locked_until, now)
    if remaining_lockout:
        await session.commit()
        await message.answer(
            f"⏳ Juda ko'p xato urinish. {remaining_lockout} soniyadan "
            "so'ng qayta urinib ko'ring."
        )
        return

    if not user.pin_hash or not is_valid_pin(pin) or not verify_pin(
        pin, user.pin_hash
    ):
        attempts_left = await register_pin_failure(session, user.id, now)
        await session.commit()
        if attempts_left == 0:
            await message.answer(
                "🚫 3 marta xato kiritildi. 1 daqiqa kutib, "
                "keyin qayta urinib ko'ring."
            )
        else:
            await message.answer(
                f"❌ PIN noto'g'ri. Yana {attempts_left} ta urinish qoldi."
            )
        return

    pin_module.clear_failures(user)
    data = await state.get_data()
    if data.get("pin_mode") == "remove":
        user.pin_hash = None
        await session.commit()
        pin_gate.lock(user.id)
        await state.clear()
        await message.answer(
            "🗑 PIN o'chirildi. Endi balans va tarix PIN'siz ochiladi."
        )
        return

    await session.commit()
    await state.set_state(PinStates.waiting_for_new)
    await message.answer(
        "Yangi 4 xonali PIN yuboring. Bekor qilish uchun /cancel yozing."
    )


@router.message(PinStates.waiting_for_new)
async def pin_new_handler(message: Message, state: FSMContext) -> None:
    text = message.text or ""
    if _is_pin_cancel(text):
        await state.clear()
        await message.answer("Bekor qilindi.", reply_markup=main_menu_keyboard())
        return
    pin = text.strip()
    await _delete_pin_message(message)
    if not is_valid_pin(pin):
        await message.answer(
            "PIN aynan 4 ta raqamdan iborat bo'lishi kerak. "
            "Masalan: <code>1234</code>. Qaytadan yuboring."
        )
        return
    # Only a salted hash goes into FSM storage — never the plain PIN.
    await state.update_data(new_pin_hash=hash_pin(pin))
    await state.set_state(PinStates.waiting_for_new_confirm)
    await message.answer("PIN'ni tasdiqlash uchun yana bir marta yuboring.")


@router.message(PinStates.waiting_for_new_confirm)
async def pin_confirm_handler(
    message: Message, state: FSMContext, session: AsyncSession
) -> None:
    text = message.text or ""
    if _is_pin_cancel(text):
        await state.clear()
        await message.answer("Bekor qilindi.", reply_markup=main_menu_keyboard())
        return
    pin = text.strip()
    await _delete_pin_message(message)
    data = await state.get_data()
    new_pin_hash = data.get("new_pin_hash")
    if not new_pin_hash or not verify_pin(pin, new_pin_hash):
        await state.set_state(PinStates.waiting_for_new)
        await message.answer(
            "PIN'lar mos kelmadi. Yangi PIN'ni qaytadan yuboring."
        )
        return
    user = await _current_user(session, message)
    user.pin_hash = new_pin_hash
    pin_module.clear_failures(user)
    await session.commit()
    pin_gate.lock(user.id)
    await state.clear()
    await message.answer(
        "✅ PIN o'rnatildi. Endi shaxsiy chatda /balance, /history va "
        "/all_history ochishdan oldin PIN so'raladi.\n"
        "To'g'ri kiritilgach 5 daqiqa davomida qayta so'ralmaydi."
    )


@router.callback_query(F.data == "flow:cancel")
async def cancel_callback(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    await callback.message.edit_text("Amaliyot bekor qilindi.")
    await callback.answer()


@router.message(Command("all_history"))
async def all_history_handler(
    message: Message, state: FSMContext, session: AsyncSession
) -> None:
    user = await _ensure_registered(session, message)
    if await _pin_required(message, state, user, "all_history"):
        return
    await _send_all_history(message, session, user)


async def _send_all_history(
    message: Message, session: AsyncSession, user: User
) -> None:
    transactions = await get_all_transactions(
        session, user.id, _scope_chat_id(message)
    )
    if not transactions:
        await message.answer("Hozircha hech qanday tranzaksiya yo'q.")
        return
    lines = ["<b>So'nggi operatsiyalar</b>\n"]
    hide_items = []
    for tx in transactions:
        other_id = tx.creditor_id if tx.debtor_id == user.id else tx.debtor_id
        other = await session.get(User, other_id)
        if other is None:
            continue
        action = _history_action(tx, user)
        date = format_uzbekistan_datetime(tx.created_at)
        mark = _status_mark(tx.status)
        lines.append(
            f"• {date} | {mark}{action} — {_user_label(other)}: "
            f"<b>{format_money(tx.amount, tx.currency)}</b>{_due_suffix(tx)}"
            f"{_pending_next_action(tx, user)}"
        )
        if await can_hide_transaction(session, tx, user.id):
            hide_items.append((tx.id, format_money(tx.amount, tx.currency)))
    await message.answer(
        "\n".join(lines),
        reply_markup=history_hide_keyboard(hide_items, "all") if hide_items else None,
    )


def _manage_label(tx: Transaction, other: User | None) -> str:
    direction = "Oldim" if tx.direction == TransactionDirection.RECEIVED else "Berdim"
    if tx.status == TransactionStatus.REPAYMENT:
        direction = "Qaytaruv"
    other_name = other.display_name() if other else "?"
    return f"{direction} | {other_name} | {format_money(tx.amount, tx.currency)}"


@router.message(Command("manage"))
async def manage_handler(message: Message, session: AsyncSession) -> None:
    user = await _ensure_registered(session, message)
    transactions = await get_entered_transactions(
        session, user.id, _scope_chat_id(message)
    )
    if not transactions:
        await message.answer("Siz kiritgan tranzaksiyalar yo'q.")
        return
    items = []
    for tx in transactions:
        other_id = tx.creditor_id if tx.debtor_id == user.id else tx.debtor_id
        other = await session.get(User, other_id)
        items.append((tx.id, _manage_label(tx, other)))
    await message.answer(
        "O'chirish yoki tahrirlash uchun tranzaksiyani tanlang "
        "(faqat o'zingiz kiritganlar):",
        reply_markup=manage_list_keyboard(items),
    )


@router.callback_query(F.data.startswith("manage:"))
async def manage_select_callback(
    callback: CallbackQuery, session: AsyncSession
) -> None:
    user = await get_user_by_telegram_id(session, callback.from_user.id)
    transaction = await get_transaction(session, int(callback.data.split(":", 1)[1]))
    if user is None or transaction is None:
        await callback.answer("Tranzaksiya topilmadi.", show_alert=True)
        return
    if transaction.entered_by_id != user.id:
        await callback.answer(
            "Faqat o'zingiz kiritgan tranzaksiyani o'zgartira olasiz.",
            show_alert=True,
        )
        return
    if transaction.scope_chat_id != _scope_chat_id(callback.message):
        await callback.answer(
            "Bu tranzaksiya boshqa chat hisobotiga tegishli.", show_alert=True
        )
        return
    other_id = (
        transaction.creditor_id
        if transaction.debtor_id == user.id
        else transaction.debtor_id
    )
    other = await session.get(User, other_id)
    note = escape(transaction.note) if transaction.note else "—"
    status_names = {
        TransactionStatus.PENDING: "⏳ Tasdiqlash kutilmoqda",
        TransactionStatus.REPAYMENT_PENDING: "⏳ Qaytaruv tasdiqlash kutilmoqda",
        TransactionStatus.CONFIRMED: "✅ Tasdiqlangan",
        TransactionStatus.REJECTED: "❌ Rad etilgan",
        TransactionStatus.REPAYMENT: "💵 Qaytaruv",
    }
    await callback.message.edit_text(
        f"<b>{_manage_label(transaction, other)}</b>\n"
        f"Holat: {status_names.get(transaction.status, transaction.status)}\n"
        f"Izoh: {note}\n"
        f"Vaqt: {format_uzbekistan_datetime(transaction.created_at)}\n\n"
        "Amalni tanlang:",
        reply_markup=manage_actions_keyboard(transaction.id),
    )
    await callback.answer()


async def _notify_counterparty(
    bot: Bot, session: AsyncSession, transaction_other: User | None, text: str
) -> None:
    if transaction_other is None:
        return
    try:
        await bot.send_message(transaction_other.telegram_id, text)
    except Exception:
        pass


@router.callback_query(F.data.startswith("txdelete:"))
async def delete_transaction_callback(
    callback: CallbackQuery, session: AsyncSession, bot: Bot
) -> None:
    user = await get_user_by_telegram_id(session, callback.from_user.id)
    transaction = await get_transaction(session, int(callback.data.split(":", 1)[1]))
    if user is None or transaction is None:
        await callback.answer("Tranzaksiya topilmadi.", show_alert=True)
        return
    if transaction.entered_by_id != user.id:
        await callback.answer(
            "Faqat o'zingiz kiritgan tranzaksiyani o'chira olasiz.", show_alert=True
        )
        return
    if transaction.scope_chat_id != _scope_chat_id(callback.message):
        await callback.answer(
            "Bu tranzaksiya boshqa chat hisobotiga tegishli.", show_alert=True
        )
        return
    other_id = (
        transaction.creditor_id
        if transaction.debtor_id == user.id
        else transaction.debtor_id
    )
    other = await session.get(User, other_id)
    money = format_money(transaction.amount, transaction.currency)
    try:
        await delete_transaction(session, transaction)
    except ValueError as error:
        await session.rollback()
        await callback.answer(str(error), show_alert=True)
        return
    await session.commit()
    await callback.message.edit_text(
        f"🗑 Tranzaksiya o'chirildi: {money}\nBalans qayta hisoblandi."
    )
    await callback.answer("O'chirildi")
    await _notify_counterparty(
        bot,
        session,
        other,
        f"🗑 <b>{_user_label(user)}</b> {money} miqdoridagi tranzaksiyani "
        "o'chirdi. Balansingiz qayta hisoblandi.",
    )


@router.callback_query(F.data.startswith("txeditamount:"))
async def edit_amount_start_callback(
    callback: CallbackQuery, state: FSMContext, session: AsyncSession
) -> None:
    user = await get_user_by_telegram_id(session, callback.from_user.id)
    transaction = await get_transaction(session, int(callback.data.split(":", 1)[1]))
    if user is None or transaction is None or transaction.entered_by_id != user.id:
        await callback.answer("Tranzaksiya topilmadi.", show_alert=True)
        return
    if transaction.scope_chat_id != _scope_chat_id(callback.message):
        await callback.answer(
            "Bu tranzaksiya boshqa chat hisobotiga tegishli.", show_alert=True
        )
        return
    if transaction.status in {
        TransactionStatus.REPAYMENT,
        TransactionStatus.REPAYMENT_PENDING,
    }:
        await callback.answer(
            "Qaytarish summasini o'zgartirib bo'lmaydi. "
            "Uni o'chirib, qaytadan kiriting.",
            show_alert=True,
        )
        return
    await state.set_state(EditStates.waiting_for_amount)
    await state.update_data(edit_tx_id=transaction.id)
    await callback.message.edit_text(
        f"Joriy summa: <b>{format_money(transaction.amount, transaction.currency)}</b>\n\n"
        "Yangi summani yuboring:"
    )
    await callback.answer()


@router.callback_query(F.data.startswith("txeditnote:"))
async def edit_note_start_callback(
    callback: CallbackQuery, state: FSMContext, session: AsyncSession
) -> None:
    user = await get_user_by_telegram_id(session, callback.from_user.id)
    transaction = await get_transaction(session, int(callback.data.split(":", 1)[1]))
    if user is None or transaction is None or transaction.entered_by_id != user.id:
        await callback.answer("Tranzaksiya topilmadi.", show_alert=True)
        return
    if transaction.scope_chat_id != _scope_chat_id(callback.message):
        await callback.answer(
            "Bu tranzaksiya boshqa chat hisobotiga tegishli.", show_alert=True
        )
        return
    await state.set_state(EditStates.waiting_for_note)
    await state.update_data(edit_tx_id=transaction.id)
    current = escape(transaction.note) if transaction.note else "—"
    await callback.message.edit_text(
        f"Joriy izoh: {current}\n\nYangi izohni yuboring:"
    )
    await callback.answer()


async def _finish_edit(
    message: Message,
    state: FSMContext,
    session: AsyncSession,
    bot: Bot,
    *,
    amount: int | None = None,
    note: str | None = None,
) -> None:
    data = await state.get_data()
    user = await _current_user(session, message)
    transaction = await get_transaction(session, int(data["edit_tx_id"]))
    if transaction is None or transaction.entered_by_id != user.id:
        await state.clear()
        await message.answer("Tranzaksiya topilmadi.")
        return
    try:
        await update_transaction(session, transaction, amount=amount, note=note)
    except ValueError as error:
        await session.rollback()
        await state.clear()
        await message.answer(str(error), reply_markup=main_menu_keyboard())
        return

    other_id = (
        transaction.creditor_id
        if transaction.debtor_id == user.id
        else transaction.debtor_id
    )
    other = await session.get(User, other_id)
    money = format_money(transaction.amount, transaction.currency)
    changed = "summasi" if amount is not None else "izohi"
    note_suffix = f"\nIzoh: {escape(transaction.note)}" if transaction.note else ""

    # A changed amount alters the agreed terms — it must be re-confirmed
    # by the counterparty (repayments never reach this point).
    needs_reconfirm = (
        amount is not None
        and transaction.status
        in {TransactionStatus.CONFIRMED, TransactionStatus.PENDING}
        and other is not None
    )
    reconfirm_sent = False
    if needs_reconfirm:
        try:
            await set_transaction_status(
                session, transaction, TransactionStatus.PENDING
            )
        except ValueError as error:
            await session.rollback()
            await state.clear()
            await message.answer(str(error), reply_markup=main_menu_keyboard())
            return
        await session.commit()
        try:
            await bot.send_message(
                other.telegram_id,
                "✏️ <b>Tranzaksiya o'zgartirildi — qayta tasdiqlash kerak</b>\n\n"
                f"<b>{_user_label(user)}</b> summani <b>{money}</b> ga "
                f"o'zgartirdi.{note_suffix}\n\n"
                "To'g'ri bo'lsa tasdiqlang, xato bo'lsa rad eting:",
                reply_markup=confirm_transaction_keyboard(transaction.id),
            )
            reconfirm_sent = True
        except (TelegramForbiddenError, TelegramBadRequest):
            # Counterparty can't press buttons — keep it counted.
            await set_transaction_status(
                session, transaction, TransactionStatus.CONFIRMED
            )
            await session.commit()
        except Exception:
            # Transient delivery failure: leave the transaction pending
            # rather than silently confirming a changed amount.
            reconfirm_sent = True
    else:
        await session.commit()

    await state.clear()
    status_note = (
        "\n⏳ Yangi summa ikkinchi tomon tasdiqlagach balansga qo'shiladi."
        if reconfirm_sent
        else ""
    )
    await message.answer(
        f"✏️ Tranzaksiya {changed} yangilandi: <b>{money}</b>"
        f"{note_suffix}{status_note}",
        reply_markup=main_menu_keyboard(),
    )
    if not reconfirm_sent:
        await _notify_counterparty(
            bot,
            session,
            other,
            f"✏️ <b>{_user_label(user)}</b> tranzaksiya {changed}ni o'zgartirdi.\n"
            f"Yangi qiymat: {money}{note_suffix}"
            + "\nBalansingiz qayta hisoblandi.",
        )


@router.message(EditStates.waiting_for_amount)
async def edit_amount_handler(
    message: Message, state: FSMContext, session: AsyncSession, bot: Bot
) -> None:
    raw_amount = (message.text or "").replace(" ", "").replace(",", "")
    if not raw_amount.isdigit() or int(raw_amount) <= 0:
        await message.answer("Iltimos, noldan katta butun summa kiriting.")
        return
    await _finish_edit(message, state, session, bot, amount=int(raw_amount))


@router.message(EditStates.waiting_for_note)
async def edit_note_handler(
    message: Message, state: FSMContext, session: AsyncSession, bot: Bot
) -> None:
    new_note = (message.text or "").strip()
    if not new_note:
        await message.answer("Iltimos, izoh matnini yuboring.")
        return
    await _finish_edit(message, state, session, bot, note=new_note)


# Reply-keyboard buttons are mapped to the same reliable command handlers.
@router.message(F.text == MENU_ADD)
async def add_menu_handler(
    message: Message, state: FSMContext, session: AsyncSession
) -> None:
    await add_handler(message, state, session)


@router.message(F.text == MENU_BALANCE)
async def balance_menu_handler(
    message: Message, state: FSMContext, session: AsyncSession
) -> None:
    await balance_handler(message, state, session)


@router.message(F.text == MENU_HISTORY)
async def history_menu_handler(
    message: Message, state: FSMContext, session: AsyncSession
) -> None:
    await history_handler(message, state, session)


@router.message(F.text == MENU_ALL_HISTORY)
async def all_history_menu_handler(
    message: Message, state: FSMContext, session: AsyncSession
) -> None:
    await all_history_handler(message, state, session)


@router.message(F.text == MENU_INVITE)
async def invite_menu_handler(
    message: Message, session: AsyncSession, bot: Bot
) -> None:
    await invite_handler(message, session, bot)


@router.message(F.text == MENU_MANAGE)
async def manage_menu_handler(message: Message, session: AsyncSession) -> None:
    await manage_handler(message, session)


@router.message(Command("settings"))
async def settings_handler(message: Message, session: AsyncSession) -> None:
    user = await _ensure_registered(session, message)
    await message.answer(
        "⚙️ <b>Sozlamalar</b>\n\n"
        "Davriy hisobot: tanlangan davrda umumiy balans xulosasi "
        "avtomatik yuboriladi (O'zbekiston vaqti bilan, soat 09:00 da).\n"
        "Maxfiylik: balans va tarixni PIN bilan himoyalash.",
        reply_markup=report_settings_keyboard(user.report_frequency),
    )


@router.callback_query(F.data.startswith("reportfreq:"))
async def report_frequency_callback(
    callback: CallbackQuery, session: AsyncSession
) -> None:
    value = callback.data.split(":", 1)[1]
    if value not in {f.value for f in ReportFrequency}:
        await callback.answer("Noto'g'ri qiymat.", show_alert=True)
        return
    user = await get_user_by_telegram_id(session, callback.from_user.id)
    if user is None:
        await callback.answer("Avval /start ni bosing.", show_alert=True)
        return
    user.report_frequency = value
    await session.commit()
    labels = {
        "off": "o'chirildi",
        "weekly": "haftalik (har dushanba)",
        "monthly": "oylik (har oyning 1-sanasi)",
    }
    await callback.message.edit_text(
        f"⚙️ Davriy hisobot: <b>{labels[value]}</b>.",
    )
    await callback.answer("Saqlandi")


@router.message(F.text == MENU_SETTINGS)
async def settings_menu_handler(message: Message, session: AsyncSession) -> None:
    await settings_handler(message, session)


@router.message(F.text == MENU_HELP)
async def help_menu_handler(message: Message, session: AsyncSession) -> None:
    await help_handler(message, session)
