from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup


SUPPORTED_CURRENCIES = {
    "UZS": "So'm (UZS)",
    "USD": "AQSh dollari (USD)",
    "TRY": "Lira (TRY)",
    "AED": "Birlashgan Arab Amirliklari dirhami (AED)",
    "SAR": "Saudiya riali (SAR)",
}


def currency_name(code: str) -> str:
    return SUPPORTED_CURRENCIES.get(code, code)


def is_valid_currency_code(code: str) -> bool:
    return len(code) == 3 and code.isascii() and code.isalpha()


def currency_keyboard() -> InlineKeyboardMarkup:
    codes = list(SUPPORTED_CURRENCIES)
    rows = []
    for index in range(0, len(codes), 2):
        rows.append(
            [
                InlineKeyboardButton(
                    text=f"{code} — {SUPPORTED_CURRENCIES[code]}",
                    callback_data=f"currency:{code}",
                )
                for code in codes[index : index + 2]
            ]
        )
    rows.append(
        [
            InlineKeyboardButton(
                text="Boshqa valyuta (ISO kod)",
                callback_data="currency:OTHER",
            )
        ]
    )
    rows.append(
        [InlineKeyboardButton(text="Bekor qilish", callback_data="flow:cancel")]
    )
    return InlineKeyboardMarkup(inline_keyboard=rows)
