"""PIN hashing and in-memory unlock/attempt tracking.

The PIN itself is never stored — only a salted PBKDF2 hash. Successful
unlock sessions live in memory (a restart just asks for the PIN again,
which is fail-closed), while failed attempts and the lockout deadline are
persisted on the User row so restarts cannot bypass the lockout. Atomic
registration of failures happens in services.register_pin_failure under a
row lock.
"""

from __future__ import annotations

import hashlib
import hmac
import secrets
import time

PBKDF2_ITERATIONS = 100_000
UNLOCK_SECONDS = 5 * 60
MAX_ATTEMPTS = 3
LOCKOUT_SECONDS = 60


def is_valid_pin(pin: str) -> bool:
    return len(pin) == 4 and pin.isdigit()


def hash_pin(pin: str) -> str:
    salt = secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac(
        "sha256", pin.encode(), bytes.fromhex(salt), PBKDF2_ITERATIONS
    )
    return f"pbkdf2_sha256${PBKDF2_ITERATIONS}${salt}${digest.hex()}"


def verify_pin(pin: str, stored: str) -> bool:
    try:
        algo, iterations, salt, expected = stored.split("$")
        if algo != "pbkdf2_sha256":
            return False
        digest = hashlib.pbkdf2_hmac(
            "sha256", pin.encode(), bytes.fromhex(salt), int(iterations)
        )
        return hmac.compare_digest(digest.hex(), expected)
    except (ValueError, TypeError):
        return False


class PinGate:
    """Per-user unlock sessions.

    Only the successful-unlock session is kept in memory: losing it on a
    restart merely re-asks for the PIN (fail-closed). Failed attempts and
    the lockout deadline are persisted on the User row instead, so a
    restart can never bypass the one-minute lockout.
    """

    def __init__(self, clock=time.monotonic) -> None:
        self._clock = clock
        self._unlocked_until: dict[int, float] = {}

    def is_unlocked(self, user_id: int) -> bool:
        return self._clock() < self._unlocked_until.get(user_id, 0.0)

    def unlock(self, user_id: int) -> None:
        self._unlocked_until[user_id] = self._clock() + UNLOCK_SECONDS

    def lock(self, user_id: int) -> None:
        """Forget the unlock session (e.g. after the PIN is changed/removed)."""
        self._unlocked_until.pop(user_id, None)


pin_gate = PinGate()


# --- Durable failure/lockout state (mutates the User row; caller commits) ---

from datetime import datetime, timedelta  # noqa: E402


def lockout_remaining(locked_until: datetime | None, now: datetime) -> int:
    """Seconds the user still has to wait, 0 when not locked out."""
    if locked_until is None:
        return 0
    if locked_until.tzinfo is None and now.tzinfo is not None:
        # SQLite returns naive datetimes; they were written in `now`'s zone.
        locked_until = locked_until.replace(tzinfo=now.tzinfo)
    remaining = (locked_until - now).total_seconds()
    return max(0, int(remaining + 0.999))


def register_failure(user, now: datetime) -> int:
    """Record a wrong PIN on the User row. Returns remaining attempts
    (0 => the user just got locked out for LOCKOUT_SECONDS)."""
    failures = (user.pin_failed_attempts or 0) + 1
    if failures >= MAX_ATTEMPTS:
        user.pin_failed_attempts = 0
        user.pin_locked_until = now + timedelta(seconds=LOCKOUT_SECONDS)
        return 0
    user.pin_failed_attempts = failures
    return MAX_ATTEMPTS - failures


def clear_failures(user) -> None:
    user.pin_failed_attempts = 0
    user.pin_locked_until = None
