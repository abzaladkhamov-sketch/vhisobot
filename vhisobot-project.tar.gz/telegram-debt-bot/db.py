from collections.abc import AsyncIterator
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy import text

from config import get_settings
from models import Base


def _normalize_database_url(url: str) -> tuple[str, dict]:
    """Normalize Replit/PostgreSQL URLs for asyncpg."""
    if url.startswith("postgresql://"):
        url = url.replace("postgresql://", "postgresql+asyncpg://", 1)
    elif url.startswith("postgres://"):
        url = url.replace("postgres://", "postgresql+asyncpg://", 1)

    parts = urlsplit(url)
    query_items = dict(parse_qsl(parts.query, keep_blank_values=True))
    sslmode = query_items.pop("sslmode", None)
    normalized_url = urlunsplit(
        (
            parts.scheme,
            parts.netloc,
            parts.path,
            urlencode(query_items),
            parts.fragment,
        )
    )

    # libpq uses `sslmode`, while asyncpg expects a boolean `ssl` connect arg.
    connect_args = {}
    if sslmode in {"require", "verify-ca", "verify-full"}:
        connect_args["ssl"] = True
    return normalized_url, connect_args


settings = get_settings()
database_url, connect_args = _normalize_database_url(settings.database_url)
engine: AsyncEngine = create_async_engine(
    database_url,
    connect_args=connect_args,
    pool_pre_ping=True,
)
session_factory = async_sessionmaker(engine, expire_on_commit=False)


async def get_session() -> AsyncIterator[AsyncSession]:
    async with session_factory() as session:
        yield session


async def init_db() -> None:
    async with engine.begin() as connection:
        await connection.run_sync(Base.metadata.create_all)
        await _migrate_multicurrency(connection)
        await _migrate_transaction_history_hides(connection)
        await _migrate_pending_notifications(connection)


async def _migrate_transaction_history_hides(connection) -> None:
    """Create the per-user history hiding table for existing installations."""
    dialect = connection.dialect.name
    if dialect == "postgresql":
        await connection.execute(
            text(
                """
                CREATE TABLE IF NOT EXISTS transaction_history_hides (
                    id SERIAL PRIMARY KEY,
                    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                    transaction_id INTEGER NOT NULL REFERENCES transactions(id) ON DELETE CASCADE,
                    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    CONSTRAINT uq_transaction_history_hide_user_transaction
                        UNIQUE (user_id, transaction_id)
                )
                """
            )
        )
        await connection.execute(
            text(
                "CREATE INDEX IF NOT EXISTS ix_transaction_history_hides_user_id "
                "ON transaction_history_hides (user_id)"
            )
        )
        await connection.execute(
            text(
                "CREATE INDEX IF NOT EXISTS ix_transaction_history_hides_transaction_id "
                "ON transaction_history_hides (transaction_id)"
            )
        )
        return
    if dialect != "sqlite":
        return
    await connection.execute(
        text(
            """
            CREATE TABLE IF NOT EXISTS transaction_history_hides (
                id INTEGER PRIMARY KEY,
                user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                transaction_id INTEGER NOT NULL REFERENCES transactions(id) ON DELETE CASCADE,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                CONSTRAINT uq_transaction_history_hide_user_transaction
                    UNIQUE (user_id, transaction_id)
            )
            """
        )
    )


async def _migrate_pending_notifications(connection) -> None:
    """Create the shared durable Telegram notification queue."""
    dialect = connection.dialect.name
    if dialect == "postgresql":
        await connection.execute(
            text(
                """
                CREATE TABLE IF NOT EXISTS pending_notifications (
                    id SERIAL PRIMARY KEY,
                    transaction_id INTEGER NOT NULL REFERENCES transactions(id) ON DELETE CASCADE,
                    recipient_telegram_id BIGINT NOT NULL,
                    kind VARCHAR(16) NOT NULL,
                    attempt_count INTEGER NOT NULL DEFAULT 0,
                    next_attempt_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    status VARCHAR(24) NOT NULL DEFAULT 'pending',
                    last_error TEXT,
                    resend_available_at TIMESTAMPTZ,
                    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    CONSTRAINT uq_pending_notification_transaction
                        UNIQUE (transaction_id)
                )
                """
            )
        )
        await connection.execute(
            text(
                "ALTER TABLE pending_notifications "
                "ADD COLUMN IF NOT EXISTS resend_available_at TIMESTAMPTZ"
            )
        )
        await connection.execute(
            text(
                "CREATE INDEX IF NOT EXISTS ix_pending_notifications_due "
                "ON pending_notifications (status, next_attempt_at)"
            )
        )
        return
    if dialect != "sqlite":
        return
    await connection.execute(
        text(
            """
            CREATE TABLE IF NOT EXISTS pending_notifications (
                id INTEGER PRIMARY KEY,
                transaction_id INTEGER NOT NULL REFERENCES transactions(id) ON DELETE CASCADE,
                recipient_telegram_id BIGINT NOT NULL,
                kind VARCHAR(16) NOT NULL,
                attempt_count INTEGER NOT NULL DEFAULT 0,
                next_attempt_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                status VARCHAR(24) NOT NULL DEFAULT 'pending',
                last_error TEXT,
                resend_available_at DATETIME,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                CONSTRAINT uq_pending_notification_transaction
                    UNIQUE (transaction_id)
            )
            """
        )
    )
    columns = {
        row[1]
        for row in (
            await connection.execute(text("PRAGMA table_info(pending_notifications)"))
        ).all()
    }
    if "resend_available_at" not in columns:
        await connection.execute(
            text(
                "ALTER TABLE pending_notifications "
                "ADD COLUMN resend_available_at DATETIME"
            )
        )
    await connection.execute(
        text(
            "CREATE INDEX IF NOT EXISTS ix_pending_notifications_due "
            "ON pending_notifications (status, next_attempt_at)"
        )
    )


async def _migrate_multicurrency(connection) -> None:
    """Add currency support without deleting the existing UZS history."""
    dialect = connection.dialect.name
    if dialect == "postgresql":
        await connection.execute(
            text(
                "ALTER TABLE transactions "
                "ADD COLUMN IF NOT EXISTS currency VARCHAR(3) NOT NULL DEFAULT 'UZS'"
            )
        )
        await connection.execute(
            text(
                "ALTER TABLE debts "
                "ADD COLUMN IF NOT EXISTS currency VARCHAR(3) NOT NULL DEFAULT 'UZS'"
            )
        )
        await connection.execute(
            text(
                "ALTER TABLE transactions "
                "ADD COLUMN IF NOT EXISTS scope_chat_id BIGINT NOT NULL DEFAULT 0"
            )
        )
        await connection.execute(
            text(
                "ALTER TABLE debts "
                "ADD COLUMN IF NOT EXISTS scope_chat_id BIGINT NOT NULL DEFAULT 0"
            )
        )
        await connection.execute(
            text(
                "ALTER TABLE transactions "
                "ADD COLUMN IF NOT EXISTS status VARCHAR(32) NOT NULL DEFAULT 'confirmed'"
            )
        )
        await connection.execute(
            text(
                "ALTER TABLE transactions "
                "ALTER COLUMN status TYPE VARCHAR(32)"
            )
        )
        await connection.execute(
            text(
                "ALTER TABLE transactions "
                "ADD COLUMN IF NOT EXISTS due_date DATE"
            )
        )
        await connection.execute(
            text(
                "ALTER TABLE users "
                "ADD COLUMN IF NOT EXISTS report_frequency VARCHAR(8) NOT NULL DEFAULT 'off'"
            )
        )
        await connection.execute(
            text(
                "ALTER TABLE users "
                "ADD COLUMN IF NOT EXISTS report_last_sent DATE"
            )
        )
        await connection.execute(
            text(
                "ALTER TABLE users "
                "ADD COLUMN IF NOT EXISTS pin_hash VARCHAR(255)"
            )
        )
        await connection.execute(
            text(
                "ALTER TABLE users "
                "ADD COLUMN IF NOT EXISTS pin_failed_attempts INTEGER NOT NULL DEFAULT 0"
            )
        )
        await connection.execute(
            text(
                "ALTER TABLE users "
                "ADD COLUMN IF NOT EXISTS pin_locked_until TIMESTAMPTZ"
            )
        )
        await connection.execute(
            text(
                "ALTER TABLE reminder_logs "
                "ALTER COLUMN kind TYPE VARCHAR(32)"
            )
        )
        await connection.execute(
            text("ALTER TABLE debts DROP CONSTRAINT IF EXISTS uq_debt_pair")
        )
        await connection.execute(
            text(
                "ALTER TABLE debts "
                "DROP CONSTRAINT IF EXISTS uq_debt_pair_currency"
            )
        )
        await connection.execute(
            text(
                """
                DO $$
                BEGIN
                    IF NOT EXISTS (
                        SELECT 1 FROM pg_constraint
                        WHERE conname = 'uq_debt_pair_currency_scope'
                    ) THEN
                        ALTER TABLE debts
                        ADD CONSTRAINT uq_debt_pair_currency_scope
                        UNIQUE (user_low_id, user_high_id, currency, scope_chat_id);
                    END IF;
                END $$;
                """
            )
        )
        return

    if dialect != "sqlite":
        return

    transaction_columns = {
        row[1]
        for row in (await connection.execute(text("PRAGMA table_info(transactions)"))).all()
    }
    if "currency" not in transaction_columns:
        await connection.execute(
            text(
                "ALTER TABLE transactions "
                "ADD COLUMN currency VARCHAR(3) NOT NULL DEFAULT 'UZS'"
            )
        )
    if "scope_chat_id" not in transaction_columns:
        await connection.execute(
            text(
                "ALTER TABLE transactions "
                "ADD COLUMN scope_chat_id BIGINT NOT NULL DEFAULT 0"
            )
        )
    if "status" not in transaction_columns:
        await connection.execute(
            text(
                "ALTER TABLE transactions "
                "ADD COLUMN status VARCHAR(32) NOT NULL DEFAULT 'confirmed'"
            )
        )
    if "due_date" not in transaction_columns:
        await connection.execute(
            text("ALTER TABLE transactions ADD COLUMN due_date DATE")
        )

    user_columns = {
        row[1]
        for row in (await connection.execute(text("PRAGMA table_info(users)"))).all()
    }
    if "report_frequency" not in user_columns:
        await connection.execute(
            text(
                "ALTER TABLE users "
                "ADD COLUMN report_frequency VARCHAR(8) NOT NULL DEFAULT 'off'"
            )
        )
    if "report_last_sent" not in user_columns:
        await connection.execute(
            text("ALTER TABLE users ADD COLUMN report_last_sent DATE")
        )
    if "pin_hash" not in user_columns:
        await connection.execute(
            text("ALTER TABLE users ADD COLUMN pin_hash VARCHAR(255)")
        )
    if "pin_failed_attempts" not in user_columns:
        await connection.execute(
            text(
                "ALTER TABLE users "
                "ADD COLUMN pin_failed_attempts INTEGER NOT NULL DEFAULT 0"
            )
        )
    if "pin_locked_until" not in user_columns:
        await connection.execute(
            text("ALTER TABLE users ADD COLUMN pin_locked_until DATETIME")
        )

    debt_columns = {
        row[1]
        for row in (await connection.execute(text("PRAGMA table_info(debts)"))).all()
    }
    if "currency" not in debt_columns or "scope_chat_id" not in debt_columns:
        await connection.execute(text("ALTER TABLE debts RENAME TO debts_legacy"))
        await connection.execute(
            text(
                """
                CREATE TABLE debts (
                    id INTEGER PRIMARY KEY,
                    user_low_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                    user_high_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                    scope_chat_id BIGINT NOT NULL DEFAULT 0,
                    currency VARCHAR(3) NOT NULL DEFAULT 'UZS',
                    balance_low_to_high BIGINT NOT NULL DEFAULT 0,
                    updated_at DATETIME,
                    CONSTRAINT uq_debt_pair_currency_scope
                        UNIQUE (user_low_id, user_high_id, currency, scope_chat_id)
                )
                """
            )
        )
        scope_expression = (
            "scope_chat_id" if "scope_chat_id" in debt_columns else "0"
        )
        currency_expression = (
            "currency" if "currency" in debt_columns else "'UZS'"
        )
        await connection.execute(
            text(
                f"""
                INSERT INTO debts
                    (id, user_low_id, user_high_id, scope_chat_id, currency,
                     balance_low_to_high, updated_at)
                SELECT id, user_low_id, user_high_id,
                       {scope_expression}, {currency_expression},
                       balance_low_to_high, updated_at
                FROM debts_legacy
                """
            )
        )
        await connection.execute(text("DROP TABLE debts_legacy"))
