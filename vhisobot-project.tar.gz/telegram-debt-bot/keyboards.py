from aiogram.types import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    ReplyKeyboardMarkup,
    ReplyKeyboardRemove,
)

from models import User

MENU_ADD = "Qarz kiritish"
MENU_BALANCE = "Balans"
MENU_HISTORY = "Tarix"
MENU_ALL_HISTORY = "Barcha tarix"
MENU_INVITE = "Kontakt taklif qilish"
MENU_HELP = "Yordam"
MENU_MANAGE = "Tahrirlash"
MENU_SETTINGS = "Sozlamalar"
SKIP_NOTE = "O'tkazib yuborish"
SKIP_DUE = "Muddatsiz"
INVITE_SELECT_CONTACT = "Telegram kontaktini tanlash"
INVITE_REQUEST_ID = 1001


def main_menu_keyboard() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text=MENU_ADD), KeyboardButton(text=MENU_BALANCE)],
            [KeyboardButton(text=MENU_HISTORY), KeyboardButton(text=MENU_ALL_HISTORY)],
            [KeyboardButton(text=MENU_MANAGE), KeyboardButton(text=MENU_INVITE)],
            [KeyboardButton(text=MENU_SETTINGS), KeyboardButton(text=MENU_HELP)],
        ],
        resize_keyboard=True,
        is_persistent=True,
        input_field_placeholder="Kerakli amalni tanlang",
    )


def skip_note_keyboard() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[[KeyboardButton(text=SKIP_NOTE)]],
        resize_keyboard=True,
        one_time_keyboard=True,
        input_field_placeholder="Izoh kiriting yoki tugmani bosing",
    )


def skip_due_keyboard() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[[KeyboardButton(text=SKIP_DUE)]],
        resize_keyboard=True,
        one_time_keyboard=True,
        input_field_placeholder="Sana kiriting yoki tugmani bosing",
    )


def report_settings_keyboard(current: str) -> InlineKeyboardMarkup:
    def label(value: str, text: str) -> str:
        return f"✅ {text}" if current == value else text

    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=label("off", "O'chirilgan"),
                    callback_data="reportfreq:off",
                ),
            ],
            [
                InlineKeyboardButton(
                    text=label("weekly", "Haftalik (dushanba)"),
                    callback_data="reportfreq:weekly",
                ),
            ],
            [
                InlineKeyboardButton(
                    text=label("monthly", "Oylik (1-sana)"),
                    callback_data="reportfreq:monthly",
                ),
            ],
            [
                InlineKeyboardButton(
                    text="🔒 Maxfiylik (PIN)",
                    callback_data="privacy:menu",
                ),
            ],
        ]
    )


def privacy_menu_keyboard(has_pin: bool) -> InlineKeyboardMarkup:
    if has_pin:
        rows = [
            [
                InlineKeyboardButton(
                    text="✏️ PIN'ni o'zgartirish",
                    callback_data="privacy:change",
                )
            ],
            [
                InlineKeyboardButton(
                    text="🗑 PIN'ni o'chirish",
                    callback_data="privacy:remove",
                )
            ],
        ]
    else:
        rows = [
            [
                InlineKeyboardButton(
                    text="🔐 PIN o'rnatish",
                    callback_data="privacy:set",
                )
            ]
        ]
    rows.append(
        [InlineKeyboardButton(text="Bekor qilish", callback_data="flow:cancel")]
    )
    return InlineKeyboardMarkup(inline_keyboard=rows)


def invite_keyboard() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[
            [
                KeyboardButton(
                    text=INVITE_SELECT_CONTACT,
                    request_users={
                        "request_id": INVITE_REQUEST_ID,
                        "user_is_bot": False,
                        "max_quantity": 1,
                        "request_name": True,
                        "request_username": True,
                    },
                )
            ],
        ],
        resize_keyboard=True,
        one_time_keyboard=True,
        input_field_placeholder="Kontaktni tanlang",
    )


def invite_share_keyboard(share_url: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="📤 Taklifnomani ulashish", url=share_url)]
        ]
    )


def remove_keyboard() -> ReplyKeyboardRemove:
    return ReplyKeyboardRemove()


def contacts_keyboard(
    contacts: list[User], callback_prefix: str
) -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton(
                text=contact.display_name()[:50],
                callback_data=f"{callback_prefix}:{contact.id}",
            )
        ]
        for contact in contacts
    ]
    rows.append(
        [InlineKeyboardButton(text="Bekor qilish", callback_data="flow:cancel")]
    )
    return InlineKeyboardMarkup(inline_keyboard=rows)


def confirm_transaction_keyboard(transaction_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="✅ Tasdiqlash",
                    callback_data=f"txconfirm:{transaction_id}",
                ),
                InlineKeyboardButton(
                    text="❌ Rad etish",
                    callback_data=f"txreject:{transaction_id}",
                ),
            ]
        ]
    )


def history_hide_keyboard(items: list[tuple[int, str]], scope: str) -> InlineKeyboardMarkup:
    """One hide button per eligible transaction in a rendered history."""
    rows = [
        [
            InlineKeyboardButton(
                text=f"🗑 Tarixdan yashirish — {label[:42]}",
                callback_data=f"historyhide:{scope}:{transaction_id}",
            )
        ]
        for transaction_id, label in items
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)


def review_transaction_keyboard(nonce: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="✅ Tasdiqlash va yuborish",
                    callback_data=f"add:confirm:{nonce}",
                )
            ],
            [InlineKeyboardButton(text="Bekor qilish", callback_data="flow:cancel")],
        ]
    )


def balance_repay_keyboard(repayable: list[tuple[User, str]]) -> InlineKeyboardMarkup:
    """One row per debt the current user can repay: (other, currency)."""
    rows = [
        [
            InlineKeyboardButton(
                text=f"💵 Qaytaruv kiritish — {other.display_name()[:32]} ({currency})",
                callback_data=f"repay:{other.id}:{currency}",
            )
        ]
        for other, currency in repayable
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)


def manage_list_keyboard(items: list[tuple[int, str]]) -> InlineKeyboardMarkup:
    """items: (transaction_id, label)."""
    rows = [
        [
            InlineKeyboardButton(
                text=label[:60],
                callback_data=f"manage:{transaction_id}",
            )
        ]
        for transaction_id, label in items
    ]
    rows.append(
        [InlineKeyboardButton(text="Bekor qilish", callback_data="flow:cancel")]
    )
    return InlineKeyboardMarkup(inline_keyboard=rows)


def manage_actions_keyboard(transaction_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="✏️ Summani o'zgartirish",
                    callback_data=f"txeditamount:{transaction_id}",
                ),
            ],
            [
                InlineKeyboardButton(
                    text="📝 Izohni o'zgartirish",
                    callback_data=f"txeditnote:{transaction_id}",
                ),
            ],
            [
                InlineKeyboardButton(
                    text="🗑 O'chirish",
                    callback_data=f"txdelete:{transaction_id}",
                ),
                InlineKeyboardButton(text="Bekor qilish", callback_data="flow:cancel"),
            ],
        ]
    )


def direction_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="Oldim — men qarzdorman",
                    callback_data="direction:received",
                ),
                InlineKeyboardButton(
                    text="Berdim — undan olishim kerak",
                    callback_data="direction:given",
                ),
            ],
            [InlineKeyboardButton(text="Bekor qilish", callback_data="flow:cancel")],
        ]
    )
