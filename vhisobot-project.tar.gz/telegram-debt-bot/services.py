from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, timedelta
from html import escape as html_escape
import hashlib
import secrets

from sqlalchemy import case, delete, desc, exists, func, or_, select, update
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.exc import IntegrityError

from currencies import is_valid_currency_code
from models import (
    Debt,
    PendingInvite,
    PendingNotification,
    Transaction,
    TransactionHistoryHide,
    TransactionDirection,
    TransactionStatus,
    User,
    UserLink,
    WebAccessCode,
)
from timezone import now_uzbekistan

# Statuses that count toward the materialized balance.
COUNTABLE_STATUSES = (
    TransactionStatus.CONFIRMED,
    TransactionStatus.REPAYMENT,
)


@dataclass(frozen=True)
class BalanceView:
    other: User
    amount: int
    user_owes_other: bool
    currency: str


@dataclass(frozen=True)
class BalanceBreakdown:
    lent_total: int
    borrowed_total: int
    repaid_by_user: int
    repaid_to_user: int


def format_money(amount: int, currency: str) -> str:
    return f"{amount:,}".replace(",", " ") + f" {currency}"


def format_uzs(amount: int) -> str:
    """Backward-compatible helper for the UZS-only algorithm tests."""
    return format_money(amount, "UZS")


def parse_due_date(raw: str, today: date) -> date:
    """Parse a user-entered due date (Tashkent calendar).

    Accepts DD.MM.YYYY, DD.MM (this year, or next year if already past)
    and YYYY-MM-DD. Raises ValueError with an Uzbek message when the text
    is not a valid date or lies in the past.
    """
    text = raw.strip().replace("/", ".").replace("-", ".")
    parts = text.split(".")
    try:
        if len(parts) == 3 and len(parts[0]) == 4:
            value = date(int(parts[0]), int(parts[1]), int(parts[2]))
        elif len(parts) == 3:
            value = date(int(parts[2]), int(parts[1]), int(parts[0]))
        elif len(parts) == 2:
            value = date(today.year, int(parts[1]), int(parts[0]))
            if value < today:
                value = date(today.year + 1, int(parts[1]), int(parts[0]))
        else:
            raise ValueError
    except (ValueError, TypeError):
        raise ValueError(
            "Sana formati noto'g'ri. Masalan: <code>20.08.2026</code> "
            "yoki <code>20.08</code>"
        )
    if value < today:
        raise ValueError("Muddat o'tmishda bo'lishi mumkin emas.")
    return value




@dataclass(frozen=True)
class QuickEntry:
    amount: int
    currency: str
    username: str | None
    note: str | None


def parse_quick_entry(args: str) -> QuickEntry:
    """Parse quick-add command arguments.

    Format: `<summa> [VALYUTA] [@username] [izoh...]` — currency defaults
    to UZS, @username may appear anywhere after the amount. Raises
    ValueError with an Uzbek explanation on bad input.
    """
    tokens = (args or "").split()
    if not tokens:
        raise ValueError("Summa ko'rsatilmadi.")

    raw_amount = tokens[0].replace(",", "").replace("_", "")
    if not raw_amount.isdigit() or int(raw_amount) <= 0:
        raise ValueError(
            f"Summa noto'g'ri: <code>{html_escape(tokens[0][:20])}</code>. "
            "Birinchi bo'lib noldan katta butun son yozing."
        )
    amount = int(raw_amount)
    rest = tokens[1:]

    currency = "UZS"
    # Only an UPPERCASE 3-letter token counts as a currency code, so an
    # ordinary lowercase note word ("non", "osh") is never mistaken for one.
    if (
        rest
        and not rest[0].startswith("@")
        and len(rest[0]) == 3
        and rest[0].isascii()
        and rest[0].isalpha()
        and rest[0].isupper()
    ):
        currency = rest[0]
        rest = rest[1:]

    username = None
    note_tokens = []
    for token in rest:
        if username is None and token.startswith("@") and len(token) > 1:
            username = token[1:]
        else:
            note_tokens.append(token)

    note = " ".join(note_tokens) if note_tokens else None
    return QuickEntry(
        amount=amount, currency=currency, username=username, note=note
    )


async def register_pin_failure(session: AsyncSession, user_id: int, now) -> int:
    """Atomically record a wrong PIN attempt.

    Re-reads the User row under SELECT ... FOR UPDATE (a no-op lock on
    SQLite, which serializes writers anyway), so concurrent wrong attempts
    cannot lose the counter update and bypass the 3-attempt lockout.
    Returns remaining attempts; 0 means locked out (now or already).
    Caller commits.
    """
    from pin import lockout_remaining as _lockout_remaining
    from pin import register_failure as _register_failure

    user = await session.scalar(
        select(User).where(User.id == user_id).with_for_update()
    )
    if user is None:
        return 0
    if _lockout_remaining(user.pin_locked_until, now) > 0:
        return 0
    remaining = _register_failure(user, now)
    await session.flush()
    return remaining


async def find_contact_by_username(
    session: AsyncSession, user: User, username: str
) -> User | None:
    """Find a linked contact by Telegram username (case-insensitive)."""
    result = await session.execute(
        select(User)
        .join(UserLink, UserLink.contact_id == User.id)
        .where(
            UserLink.user_id == user.id,
            func.lower(User.username) == username.lower().lstrip("@"),
        )
    )
    return result.scalars().first()


def calculate_user_pair_net(
    *,
    user_id: int,
    other_user_id: int,
    transactions: list[Transaction],
) -> int:
    """Return positive when user owes the other person, negative otherwise.

    Only confirmed transactions and repayments count; pending and rejected
    ones are excluded. Legacy rows without a status are treated as confirmed.
    """
    total = 0
    for tx in transactions:
        status = getattr(tx, "status", TransactionStatus.CONFIRMED)
        if status not in COUNTABLE_STATUSES:
            continue
        if tx.debtor_id == user_id and tx.creditor_id == other_user_id:
            total += tx.amount
        elif tx.debtor_id == other_user_id and tx.creditor_id == user_id:
            total -= tx.amount
    return total


async def upsert_user(session: AsyncSession, telegram_user) -> User:
    result = await session.execute(
        select(User).where(User.telegram_id == telegram_user.id)
    )
    user = result.scalar_one_or_none()
    if user is None:
        user = User(
            telegram_id=telegram_user.id,
            username=telegram_user.username,
            first_name=telegram_user.first_name or "Foydalanuvchi",
            last_name=telegram_user.last_name,
        )
        session.add(user)
    else:
        user.username = telegram_user.username
        user.first_name = telegram_user.first_name or user.first_name
        user.last_name = telegram_user.last_name
    await session.flush()
    return user


async def upsert_shared_user(session: AsyncSession, shared_user) -> User:
    """Create or refresh a user selected with Telegram's contact picker."""
    result = await session.execute(
        select(User).where(User.telegram_id == shared_user.user_id)
    )
    user = result.scalar_one_or_none()
    if user is None:
        user = User(
            telegram_id=shared_user.user_id,
            username=shared_user.username,
            first_name=shared_user.first_name or "Telegram foydalanuvchisi",
            last_name=shared_user.last_name,
        )
        session.add(user)
    else:
        if shared_user.username is not None:
            user.username = shared_user.username
        if shared_user.first_name:
            user.first_name = shared_user.first_name
        if shared_user.last_name is not None:
            user.last_name = shared_user.last_name
    await session.flush()
    return user


async def get_user_by_telegram_id(
    session: AsyncSession, telegram_id: int
) -> User | None:
    result = await session.execute(select(User).where(User.telegram_id == telegram_id))
    return result.scalar_one_or_none()


async def link_users(
    session: AsyncSession, first: User, second: User
) -> None:
    if first.id == second.id:
        return
    for owner, contact in [(first, second), (second, first)]:
        existing = await session.scalar(
            select(UserLink).where(
                UserLink.user_id == owner.id,
                UserLink.contact_id == contact.id,
            )
        )
        if existing is None:
            session.add(UserLink(user_id=owner.id, contact_id=contact.id))
    await session.flush()


async def add_pending_invite(
    session: AsyncSession, inviter: User, invitee_telegram_id: int
) -> None:
    existing = await session.scalar(
        select(PendingInvite).where(
            PendingInvite.inviter_id == inviter.id,
            PendingInvite.invitee_telegram_id == invitee_telegram_id,
        )
    )
    if existing is None:
        session.add(
            PendingInvite(
                inviter_id=inviter.id,
                invitee_telegram_id=invitee_telegram_id,
            )
        )
    await session.flush()


async def create_web_access_code(session: AsyncSession, user: User) -> str:
    """Issue a short-lived, one-time code for the web and mobile clients."""
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    code = "".join(secrets.choice(alphabet) for _ in range(8))
    session.add(
        WebAccessCode(
            user_id=user.id,
            code_hash=hashlib.sha256(code.encode()).hexdigest(),
            expires_at=datetime.now(now_uzbekistan().tzinfo) + timedelta(minutes=10),
        )
    )
    await session.flush()
    return code


async def get_pending_confirmations(
    session: AsyncSession, user: User
) -> list[Transaction]:
    """Pending personal transactions where this user is the counterparty."""
    result = await session.execute(
        select(Transaction)
        .where(
            Transaction.scope_chat_id == 0,
            Transaction.status.in_(
                (TransactionStatus.PENDING, TransactionStatus.REPAYMENT_PENDING)
            ),
            Transaction.entered_by_id != user.id,
            or_(
                Transaction.debtor_id == user.id,
                Transaction.creditor_id == user.id,
            ),
        )
        .order_by(Transaction.created_at.desc())
    )
    return list(result.scalars().all())


async def consume_pending_invite(
    session: AsyncSession, invitee_telegram_id: int
) -> User | None:
    result = await session.execute(
        select(PendingInvite, User)
        .join(User, User.id == PendingInvite.inviter_id)
        .where(PendingInvite.invitee_telegram_id == invitee_telegram_id)
        .order_by(PendingInvite.created_at)
    )
    pending_rows = result.all()
    inviter = pending_rows[0][1] if pending_rows else None
    for pending, _ in pending_rows:
        await session.delete(pending)
    if pending_rows:
        await session.flush()
    return inviter


async def get_contacts(session: AsyncSession, user: User) -> list[User]:
    result = await session.execute(
        select(User)
        .join(UserLink, UserLink.contact_id == User.id)
        .where(UserLink.user_id == user.id)
        .order_by(User.first_name, User.last_name)
    )
    return list(result.scalars().all())


async def create_transaction(
    session: AsyncSession,
    *,
    entered_by: User,
    other: User,
    direction: TransactionDirection,
    amount: int,
    currency: str = "UZS",
    scope_chat_id: int = 0,
    note: str | None = None,
    status: TransactionStatus = TransactionStatus.CONFIRMED,
    due_date: date | None = None,
) -> Transaction:
    if entered_by.id == other.id:
        raise ValueError("O'zingizga tranzaksiya kiritib bo'lmaydi.")
    if amount <= 0:
        raise ValueError("Summa noldan katta bo'lishi kerak.")
    currency = currency.upper()
    if not is_valid_currency_code(currency):
        raise ValueError("Valyuta ISO kodi 3 ta lotin harfidan iborat bo'lishi kerak.")

    if direction == TransactionDirection.RECEIVED:
        debtor_id, creditor_id = entered_by.id, other.id
    else:
        debtor_id, creditor_id = other.id, entered_by.id

    transaction = Transaction(
        debtor_id=debtor_id,
        creditor_id=creditor_id,
        entered_by_id=entered_by.id,
        amount=amount,
        currency=currency,
        scope_chat_id=scope_chat_id,
        direction=direction,
        status=status,
        note=note.strip() if note and note.strip() else None,
        due_date=due_date,
    )
    session.add(transaction)
    await session.flush()
    if status in (
        TransactionStatus.PENDING,
        TransactionStatus.REPAYMENT_PENDING,
    ):
        session.add(
            PendingNotification(
                transaction_id=transaction.id,
                recipient_telegram_id=other.telegram_id,
                kind=(
                    "repayment"
                    if status == TransactionStatus.REPAYMENT_PENDING
                    else "debt"
                ),
            )
        )
    await _recalculate_debt(
        session, debtor_id, creditor_id, currency, scope_chat_id
    )
    return transaction


async def _pair_status_net(
    session: AsyncSession,
    low_id: int,
    high_id: int,
    currency: str,
    scope_chat_id: int,
    statuses: tuple[TransactionStatus, ...],
) -> int:
    """Signed low→high net over the given statuses only."""
    signed_amount = case(
        (Transaction.debtor_id == low_id, Transaction.amount),
        else_=-Transaction.amount,
    )
    result = await session.execute(
        select(func.coalesce(func.sum(signed_amount), 0)).where(
            or_(
                (Transaction.debtor_id == low_id)
                & (Transaction.creditor_id == high_id),
                (Transaction.debtor_id == high_id)
                & (Transaction.creditor_id == low_id),
            ),
            Transaction.currency == currency,
            Transaction.scope_chat_id == scope_chat_id,
            Transaction.status.in_(statuses),
        )
    )
    return int(result.scalar_one())


async def _pair_status_direction_totals(
    session: AsyncSession,
    low_id: int,
    high_id: int,
    currency: str,
    scope_chat_id: int,
    statuses: tuple[TransactionStatus, ...],
) -> tuple[int, int]:
    """Return gross low→high and high→low totals for the given statuses."""
    low_to_high = case(
        (
            (Transaction.debtor_id == low_id)
            & (Transaction.creditor_id == high_id),
            Transaction.amount,
        ),
        else_=0,
    )
    high_to_low = case(
        (
            (Transaction.debtor_id == high_id)
            & (Transaction.creditor_id == low_id),
            Transaction.amount,
        ),
        else_=0,
    )
    result = await session.execute(
        select(
            func.coalesce(func.sum(low_to_high), 0),
            func.coalesce(func.sum(high_to_low), 0),
        ).where(
            or_(
                (Transaction.debtor_id == low_id)
                & (Transaction.creditor_id == high_id),
                (Transaction.debtor_id == high_id)
                & (Transaction.creditor_id == low_id),
            ),
            Transaction.currency == currency,
            Transaction.scope_chat_id == scope_chat_id,
            Transaction.status.in_(statuses),
        )
    )
    low_to_high_total, high_to_low_total = result.one()
    return int(low_to_high_total), int(high_to_low_total)


async def _recalculate_debt(
    session: AsyncSession,
    first_user_id: int,
    second_user_id: int,
    currency: str,
    scope_chat_id: int,
) -> Debt:
    """Recompute and store the pair balance under a row lock.

    All mutation paths (create, confirm/reject, repayment, edit, delete)
    funnel through here. The pair's Debt row is locked (SELECT ... FOR
    UPDATE on PostgreSQL) BEFORE the ledger is summed, so concurrent
    mutations of the same pair serialize instead of overwriting each
    other's balance with stale reads.

    Also enforces the repayment invariant: recorded repayments must never
    exceed the underlying confirmed debt (i.e. a repayment can't flip
    into a new loan because the original transaction was edited/deleted).
    Raises ValueError when the resulting ledger would violate it.
    """
    low_id, high_id = sorted((first_user_id, second_user_id))

    # A transaction-scoped advisory lock exists even before the Debt row
    # does, so two first-ever transactions for a new pair serialize here
    # instead of racing to insert the same Debt row.
    bind = session.get_bind()
    if bind is not None and bind.dialect.name == "postgresql":
        lock_key = f"debt:{low_id}:{high_id}:{currency}:{scope_chat_id}"
        await session.execute(
            select(
                func.pg_advisory_xact_lock(
                    func.hashtextextended(lock_key, 0)
                )
            )
        )

    debt = await session.scalar(
        select(Debt)
        .where(
            Debt.user_low_id == low_id,
            Debt.user_high_id == high_id,
            Debt.currency == currency,
            Debt.scope_chat_id == scope_chat_id,
        )
        .with_for_update()
    )

    confirmed_low_to_high, confirmed_high_to_low = await _pair_status_direction_totals(
        session, low_id, high_id, currency, scope_chat_id,
        (TransactionStatus.CONFIRMED,),
    )
    repayment_low_to_high, repayment_high_to_low = await _pair_status_direction_totals(
        session, low_id, high_id, currency, scope_chat_id,
        (TransactionStatus.REPAYMENT,),
    )
    pending_repayment_low_to_high, pending_repayment_high_to_low = (
        await _pair_status_direction_totals(
            session,
            low_id,
            high_id,
            currency,
            scope_chat_id,
            (TransactionStatus.REPAYMENT_PENDING,),
        )
    )
    # A repayment is saved in the reverse direction of the debt it reduces.
    # Compare gross totals per direction rather than the pair's net balance:
    # a newly confirmed debt in the other direction must not make an earlier,
    # valid repayment look like an overpayment.
    if (
        repayment_low_to_high + pending_repayment_low_to_high
        > confirmed_high_to_low
        or repayment_high_to_low + pending_repayment_high_to_low
        > confirmed_low_to_high
    ):
        raise ValueError(
            "Bu amal mavjud qaytarish tranzaksiyalariga zid keladi. "
            "Avval tegishli qaytarishlarni o'chiring."
        )
    net = (
        confirmed_low_to_high
        - confirmed_high_to_low
        + repayment_low_to_high
        - repayment_high_to_low
    )

    if debt is None:
        debt = Debt(
            user_low_id=low_id,
            user_high_id=high_id,
            currency=currency,
            scope_chat_id=scope_chat_id,
            balance_low_to_high=net,
        )
        session.add(debt)
    else:
        debt.balance_low_to_high = net
    await session.flush()
    return debt


async def set_transaction_status(
    session: AsyncSession,
    transaction: Transaction,
    status: TransactionStatus,
    *,
    expected_status: TransactionStatus | None = None,
) -> bool:
    """Change a transaction status and refresh the materialized balance.

    When expected_status is given, the change is a conditional UPDATE so two
    concurrent button presses (confirm vs reject) cannot both win. Returns
    False if the row was no longer in the expected status.
    """
    if expected_status is not None:
        result = await session.execute(
            update(Transaction)
            .where(
                Transaction.id == transaction.id,
                Transaction.status == expected_status,
            )
            .values(status=status)
        )
        if result.rowcount == 0:
            return False
        transaction.status = status
    else:
        transaction.status = status
    if status in (
        TransactionStatus.CONFIRMED,
        TransactionStatus.REJECTED,
        TransactionStatus.REPAYMENT,
    ):
        await session.execute(
            delete(PendingNotification).where(
                PendingNotification.transaction_id == transaction.id
            )
        )
    await session.flush()
    await _recalculate_debt(
        session,
        transaction.debtor_id,
        transaction.creditor_id,
        transaction.currency,
        transaction.scope_chat_id,
    )
    return True


async def get_transaction(
    session: AsyncSession, transaction_id: int
) -> Transaction | None:
    return await session.get(Transaction, transaction_id)


async def get_entered_transactions(
    session: AsyncSession,
    user_id: int,
    scope_chat_id: int = 0,
    limit: int = 10,
) -> list[Transaction]:
    """Recent transactions the user entered themselves (for edit/delete)."""
    result = await session.execute(
        select(Transaction)
        .where(
            Transaction.entered_by_id == user_id,
            Transaction.scope_chat_id == scope_chat_id,
            Transaction.status != TransactionStatus.REJECTED,
        )
        .order_by(desc(Transaction.created_at))
        .limit(limit)
    )
    return list(result.scalars().all())


async def update_transaction(
    session: AsyncSession,
    transaction: Transaction,
    *,
    amount: int | None = None,
    note: str | None = None,
) -> Transaction:
    if amount is not None:
        if amount <= 0:
            raise ValueError("Summa noldan katta bo'lishi kerak.")
        transaction.amount = amount
    if note is not None:
        transaction.note = note.strip() if note.strip() else None
    await session.flush()
    await _recalculate_debt(
        session,
        transaction.debtor_id,
        transaction.creditor_id,
        transaction.currency,
        transaction.scope_chat_id,
    )
    return transaction


async def delete_transaction(
    session: AsyncSession, transaction: Transaction
) -> None:
    debtor_id = transaction.debtor_id
    creditor_id = transaction.creditor_id
    currency = transaction.currency
    scope_chat_id = transaction.scope_chat_id
    await session.delete(transaction)
    await session.flush()
    await _recalculate_debt(session, debtor_id, creditor_id, currency, scope_chat_id)


async def get_debt_between(
    session: AsyncSession,
    user_id: int,
    other_user_id: int,
    currency: str,
    scope_chat_id: int = 0,
) -> int:
    """Signed debt for user: positive when the user owes the other person.

    This is a plain informational read. It intentionally takes NO locks:
    every balance mutation funnels through `_recalculate_debt`, which
    always acquires the pair advisory lock BEFORE the Debt row lock, so a
    single consistent lock order exists and deadlocks are impossible by
    construction. Overdraft protection is enforced authoritatively by the
    repayment invariant inside `_recalculate_debt`, not by this read.
    """
    low_id, high_id = sorted((user_id, other_user_id))
    debt = await session.scalar(
        select(Debt).where(
            Debt.user_low_id == low_id,
            Debt.user_high_id == high_id,
            Debt.currency == currency,
            Debt.scope_chat_id == scope_chat_id,
        )
    )
    if debt is None:
        return 0
    return debt.balance_low_to_high if user_id == low_id else -debt.balance_low_to_high


async def get_nearest_due_date(
    session: AsyncSession,
    debtor_id: int,
    creditor_id: int,
    currency: str,
    scope_chat_id: int = 0,
) -> date | None:
    """Earliest due date among the debtor's countable transactions."""
    result = await session.execute(
        select(func.min(Transaction.due_date)).where(
            Transaction.debtor_id == debtor_id,
            Transaction.creditor_id == creditor_id,
            Transaction.currency == currency,
            Transaction.scope_chat_id == scope_chat_id,
            Transaction.status == TransactionStatus.CONFIRMED,
            Transaction.due_date.is_not(None),
        )
    )
    return result.scalar_one_or_none()


async def get_balances(
    session: AsyncSession, user: User, scope_chat_id: int = 0
) -> list[BalanceView]:
    result = await session.execute(
        select(Debt, User)
        .join(
            User,
            case(
                (Debt.user_low_id == user.id, Debt.user_high_id),
                else_=Debt.user_low_id,
            )
            == User.id,
        )
        .where(
            or_(Debt.user_low_id == user.id, Debt.user_high_id == user.id),
            Debt.balance_low_to_high != 0,
            Debt.scope_chat_id == scope_chat_id,
        )
        .order_by(desc(Debt.updated_at))
    )
    balances: list[BalanceView] = []
    for debt, other in result.all():
        user_is_low = debt.user_low_id == user.id
        signed_for_user = (
            debt.balance_low_to_high
            if user_is_low
            else -debt.balance_low_to_high
        )
        balances.append(
            BalanceView(
                other=other,
                amount=abs(signed_for_user),
                user_owes_other=signed_for_user > 0,
                currency=debt.currency,
            )
        )
    return balances


async def get_balance_breakdown(
    session: AsyncSession,
    *,
    user_id: int,
    other_user_id: int,
    currency: str,
    scope_chat_id: int = 0,
) -> BalanceBreakdown:
    """Separate original debt and repayment totals for one user pair."""
    pair_filter = or_(
        (Transaction.debtor_id == user_id)
        & (Transaction.creditor_id == other_user_id),
        (Transaction.debtor_id == other_user_id)
        & (Transaction.creditor_id == user_id),
    )
    result = await session.execute(
        select(
            func.coalesce(
                func.sum(
                    case(
                        (
                            (Transaction.status == TransactionStatus.CONFIRMED)
                            & (Transaction.creditor_id == user_id),
                            Transaction.amount,
                        ),
                        else_=0,
                    )
                ),
                0,
            ),
            func.coalesce(
                func.sum(
                    case(
                        (
                            (Transaction.status == TransactionStatus.CONFIRMED)
                            & (Transaction.debtor_id == user_id),
                            Transaction.amount,
                        ),
                        else_=0,
                    )
                ),
                0,
            ),
            func.coalesce(
                func.sum(
                    case(
                        (
                            (Transaction.status == TransactionStatus.REPAYMENT)
                            & (Transaction.entered_by_id == user_id),
                            Transaction.amount,
                        ),
                        else_=0,
                    )
                ),
                0,
            ),
            func.coalesce(
                func.sum(
                    case(
                        (
                            (Transaction.status == TransactionStatus.REPAYMENT)
                            & (Transaction.entered_by_id != user_id),
                            Transaction.amount,
                        ),
                        else_=0,
                    )
                ),
                0,
            ),
        ).where(
            pair_filter,
            Transaction.currency == currency,
            Transaction.scope_chat_id == scope_chat_id,
            Transaction.status.in_(COUNTABLE_STATUSES),
        )
    )
    lent_total, borrowed_total, repaid_by_user, repaid_to_user = result.one()
    return BalanceBreakdown(
        lent_total=int(lent_total),
        borrowed_total=int(borrowed_total),
        repaid_by_user=int(repaid_by_user),
        repaid_to_user=int(repaid_to_user),
    )


async def get_pair_transactions(
    session: AsyncSession,
    *,
    user_id: int,
    other_user_id: int,
    scope_chat_id: int = 0,
    limit: int = 30,
) -> list[Transaction]:
    result = await session.execute(
        select(Transaction)
        .where(
            or_(
                (Transaction.debtor_id == user_id)
                & (Transaction.creditor_id == other_user_id),
                (Transaction.debtor_id == other_user_id)
                & (Transaction.creditor_id == user_id),
            ),
            Transaction.scope_chat_id == scope_chat_id,
            ~exists().where(
                TransactionHistoryHide.transaction_id == Transaction.id,
                TransactionHistoryHide.user_id == user_id,
            ),
        )
        .order_by(desc(Transaction.created_at))
        .limit(limit)
    )
    return list(result.scalars().all())


async def get_all_transactions(
    session: AsyncSession,
    user_id: int,
    scope_chat_id: int = 0,
    limit: int = 30,
) -> list[Transaction]:
    result = await session.execute(
        select(Transaction)
        .where(
            or_(
                Transaction.debtor_id == user_id,
                Transaction.creditor_id == user_id,
            ),
            Transaction.scope_chat_id == scope_chat_id,
            ~exists().where(
                TransactionHistoryHide.transaction_id == Transaction.id,
                TransactionHistoryHide.user_id == user_id,
            ),
        )
        .order_by(desc(Transaction.created_at))
        .limit(limit)
    )
    return list(result.scalars().all())


async def can_hide_transaction(
    session: AsyncSession, transaction: Transaction, user_id: int
) -> bool:
    """Only a participant may hide a rejected or fully settled ledger entry."""
    if user_id not in {transaction.debtor_id, transaction.creditor_id}:
        return False
    if transaction.status == TransactionStatus.REJECTED:
        return True
    if transaction.status not in {
        TransactionStatus.CONFIRMED,
        TransactionStatus.REPAYMENT,
    }:
        return False
    low_id, high_id = sorted((transaction.debtor_id, transaction.creditor_id))
    confirmed_low_to_high, confirmed_high_to_low = (
        await _pair_status_direction_totals(
            session,
            low_id,
            high_id,
            transaction.currency,
            transaction.scope_chat_id,
            (TransactionStatus.CONFIRMED,),
        )
    )
    repayment_low_to_high, repayment_high_to_low = (
        await _pair_status_direction_totals(
            session,
            low_id,
            high_id,
            transaction.currency,
            transaction.scope_chat_id,
            (TransactionStatus.REPAYMENT,),
        )
    )
    return (
        repayment_low_to_high == confirmed_high_to_low
        and repayment_high_to_low == confirmed_low_to_high
    )


async def hide_transaction_for_user(
    session: AsyncSession, transaction: Transaction, user_id: int
) -> bool:
    """Hide an eligible transaction idempotently for exactly one user."""
    bind = session.get_bind()
    if bind is not None and bind.dialect.name == "postgresql":
        low_id, high_id = sorted((transaction.debtor_id, transaction.creditor_id))
        lock_key = (
            f"debt:{low_id}:{high_id}:{transaction.currency}:"
            f"{transaction.scope_chat_id}"
        )
        await session.execute(
            select(func.pg_advisory_xact_lock(func.hashtextextended(lock_key, 0)))
        )
    if not await can_hide_transaction(session, transaction, user_id):
        return False
    existing = await session.scalar(
        select(TransactionHistoryHide).where(
            TransactionHistoryHide.user_id == user_id,
            TransactionHistoryHide.transaction_id == transaction.id,
        )
    )
    if existing is None:
        session.add(
            TransactionHistoryHide(user_id=user_id, transaction_id=transaction.id)
        )
        try:
            await session.flush()
        except IntegrityError:
            # A second Telegram callback may race the first one. The unique
            # key makes the operation idempotent; discard only this session's
            # failed insert and let the caller continue normally.
            await session.rollback()
    return True
