from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal
from enum import StrEnum
from typing import Optional

from sqlalchemy import (
    BigInteger,
    Date,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship

from timezone import now_uzbekistan


class Base(DeclarativeBase):
    pass


class TransactionDirection(StrEnum):
    RECEIVED = "received"  # Current user selected "Oldim"
    GIVEN = "given"  # Current user selected "Berdim"


class ReportFrequency(StrEnum):
    OFF = "off"
    WEEKLY = "weekly"
    MONTHLY = "monthly"


class TransactionStatus(StrEnum):
    PENDING = "pending"  # Waiting for the counterparty's confirmation
    REPAYMENT_PENDING = "repayment_pending"  # Waiting for repayment confirmation
    CONFIRMED = "confirmed"  # Counts toward the balance
    REJECTED = "rejected"  # Declined by the counterparty; excluded from balance
    REPAYMENT = "repayment"  # Confirmed repayment of an existing debt


class PendingNotificationStatus(StrEnum):
    PENDING = "pending"
    SENT = "sent"
    PERMANENT_FAILURE = "permanent_failure"


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    telegram_id: Mapped[int] = mapped_column(BigInteger, unique=True, index=True)
    username: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    first_name: Mapped[str] = mapped_column(String(255))
    last_name: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=now_uzbekistan, server_default=func.now()
    )
    # Periodic balance report setting: off / weekly / monthly.
    report_frequency: Mapped[str] = mapped_column(
        String(8), default=ReportFrequency.OFF, server_default="off"
    )
    report_last_sent: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    # Optional privacy PIN — salted PBKDF2 hash, never the plain PIN.
    pin_hash: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    # Durable brute-force protection: wrong-attempt counter and lockout
    # deadline survive bot restarts.
    pin_failed_attempts: Mapped[int] = mapped_column(
        Integer, default=0, server_default="0"
    )
    pin_locked_until: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    transactions_entered: Mapped[list[Transaction]] = relationship(
        foreign_keys="Transaction.entered_by_id",
        back_populates="entered_by",
    )

    def display_name(self) -> str:
        if self.username:
            return f"@{self.username}"
        return " ".join(part for part in [self.first_name, self.last_name] if part)


class UserLink(Base):
    """A lightweight contact relation created through an invite deep-link."""

    __tablename__ = "user_links"
    __table_args__ = (
        UniqueConstraint("user_id", "contact_id", name="uq_user_contact"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    contact_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=now_uzbekistan, server_default=func.now()
    )


class PendingInvite(Base):
    """Invite waiting for the selected Telegram user to open the bot."""

    __tablename__ = "pending_invites"
    __table_args__ = (
        UniqueConstraint(
            "inviter_id",
            "invitee_telegram_id",
            name="uq_pending_invite_pair",
        ),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    inviter_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE")
    )
    invitee_telegram_id: Mapped[int] = mapped_column(BigInteger, index=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=now_uzbekistan, server_default=func.now()
    )


class WebAccessCode(Base):
    """Short-lived, single-use code linking a web/mobile session to Telegram."""

    __tablename__ = "web_access_codes"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), index=True
    )
    # Only the SHA-256 digest is stored; a database leak cannot authenticate a
    # browser or device with the original code.
    code_hash: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    used_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=now_uzbekistan, server_default=func.now()
    )


class Transaction(Base):
    __tablename__ = "transactions"
    __table_args__ = (
        Index("ix_transactions_pair_date", "debtor_id", "creditor_id", "created_at"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    # The person who owes money after this transaction.
    debtor_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"))
    # The person who should receive money after this transaction.
    creditor_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT")
    )
    # Telegram user who entered the transaction.
    entered_by_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT")
    )
    # 0 = private/personal report; Telegram group chat id = group report.
    scope_chat_id: Mapped[int] = mapped_column(BigInteger, default=0, index=True)
    amount: Mapped[int] = mapped_column(BigInteger)
    currency: Mapped[str] = mapped_column(String(3), default="UZS", index=True)
    direction: Mapped[TransactionDirection] = mapped_column(String(16))
    # Legacy rows have no status column; they are treated as confirmed.
    status: Mapped[TransactionStatus] = mapped_column(
        String(32), default=TransactionStatus.CONFIRMED, index=True
    )
    note: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    # Optional repayment deadline (Tashkent calendar date).
    due_date: Mapped[Optional[date]] = mapped_column(Date, nullable=True, index=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=now_uzbekistan, server_default=func.now(), index=True
    )

    debtor: Mapped[User] = relationship(foreign_keys=[debtor_id])
    creditor: Mapped[User] = relationship(foreign_keys=[creditor_id])
    entered_by: Mapped[User] = relationship(
        foreign_keys=[entered_by_id],
        back_populates="transactions_entered",
    )


class PendingNotification(Base):
    """Durable Telegram delivery work for a pending transaction."""

    __tablename__ = "pending_notifications"
    __table_args__ = (
        UniqueConstraint(
            "transaction_id",
            name="uq_pending_notification_transaction",
        ),
        Index(
            "ix_pending_notifications_due",
            "status",
            "next_attempt_at",
        ),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    transaction_id: Mapped[int] = mapped_column(
        ForeignKey("transactions.id", ondelete="CASCADE"), index=True
    )
    recipient_telegram_id: Mapped[int] = mapped_column(BigInteger, index=True)
    # "debt" or "repayment"; the transaction contains the remaining details.
    kind: Mapped[str] = mapped_column(String(16))
    attempt_count: Mapped[int] = mapped_column(
        Integer, default=0, server_default="0"
    )
    next_attempt_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=now_uzbekistan, server_default=func.now()
    )
    status: Mapped[PendingNotificationStatus] = mapped_column(
        String(24),
        default=PendingNotificationStatus.PENDING,
        server_default=PendingNotificationStatus.PENDING.value,
    )
    last_error: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=now_uzbekistan, server_default=func.now()
    )

    transaction: Mapped[Transaction] = relationship()


class TransactionHistoryHide(Base):
    """A per-user choice to hide an inactive transaction from history."""

    __tablename__ = "transaction_history_hides"
    __table_args__ = (
        UniqueConstraint(
            "user_id",
            "transaction_id",
            name="uq_transaction_history_hide_user_transaction",
        ),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), index=True
    )
    transaction_id: Mapped[int] = mapped_column(
        ForeignKey("transactions.id", ondelete="CASCADE"), index=True
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=now_uzbekistan, server_default=func.now()
    )


class ReminderLog(Base):
    """Prevents the scheduler from sending the same reminder twice."""

    __tablename__ = "reminder_logs"
    __table_args__ = (
        UniqueConstraint(
            "transaction_id",
            "kind",
            "sent_on",
            name="uq_reminder_tx_kind_day",
        ),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    transaction_id: Mapped[int] = mapped_column(
        ForeignKey("transactions.id", ondelete="CASCADE"), index=True
    )
    # e.g. "due_soon:debtor", "overdue:creditor" — one row per recipient.
    kind: Mapped[str] = mapped_column(String(32))
    sent_on: Mapped[date] = mapped_column(Date)


class Debt(Base):
    """Materialized net balance for one unordered user pair.

    user_low_id is always the smaller internal user id.
    balance_low_to_high > 0 means user_low owes user_high.
    balance_low_to_high < 0 means user_high owes user_low.
    """

    __tablename__ = "debts"
    __table_args__ = (
        UniqueConstraint(
            "user_low_id",
            "user_high_id",
            "currency",
            "scope_chat_id",
            name="uq_debt_pair_currency_scope",
        ),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_low_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE")
    )
    user_high_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE")
    )
    # 0 = private/personal report; Telegram group chat id = group report.
    scope_chat_id: Mapped[int] = mapped_column(BigInteger, default=0, index=True)
    currency: Mapped[str] = mapped_column(String(3), default="UZS", index=True)
    balance_low_to_high: Mapped[int] = mapped_column(BigInteger, default=0)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=now_uzbekistan,
        server_default=func.now(),
        onupdate=now_uzbekistan,
    )

    user_low: Mapped[User] = relationship(foreign_keys=[user_low_id])
    user_high: Mapped[User] = relationship(foreign_keys=[user_high_id])
