from aiogram.fsm.state import State, StatesGroup


class AddDebtStates(StatesGroup):
    waiting_for_contact = State()
    waiting_for_direction = State()
    waiting_for_currency = State()
    waiting_for_custom_currency = State()
    waiting_for_amount = State()
    waiting_for_note = State()
    waiting_for_due_date = State()
    waiting_for_confirmation = State()


class HistoryStates(StatesGroup):
    waiting_for_contact = State()


class RepayStates(StatesGroup):
    waiting_for_amount = State()


class EditStates(StatesGroup):
    waiting_for_amount = State()
    waiting_for_note = State()


class PinStates(StatesGroup):
    waiting_for_unlock = State()  # PIN before a protected command
    waiting_for_current = State()  # current PIN before change/remove
    waiting_for_new = State()
    waiting_for_new_confirm = State()
