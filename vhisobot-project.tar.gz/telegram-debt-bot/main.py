import asyncio
import logging

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import BotCommand
from sqlalchemy.ext.asyncio import AsyncSession

from config import get_settings
from db import engine, init_db, session_factory
from handlers import router
from scheduler import scheduler_loop


async def session_middleware(handler, event, data):
    async with session_factory() as session:
        data["session"] = session
        return await handler(event, data)


async def main() -> None:
    settings = get_settings()
    logging.basicConfig(
        level=getattr(logging, settings.log_level.upper(), logging.INFO),
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    )
    await init_db()

    bot = Bot(
        token=settings.bot_token,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    await bot.set_my_commands(
        [
            BotCommand(command="start", description="Botni boshlash"),
            BotCommand(command="add", description="Qarz kiritish"),
            BotCommand(command="oldim", description="Tezkor: oldim 50000 @user izoh"),
            BotCommand(command="berdim", description="Tezkor: berdim 50000 @user izoh"),
            BotCommand(command="balance", description="Joriy balans"),
            BotCommand(command="history", description="Kontakt bilan tarix"),
            BotCommand(command="all_history", description="Barcha tarix"),
            BotCommand(command="manage", description="Tranzaksiyani tahrirlash"),
            BotCommand(command="settings", description="Davriy hisobot sozlamalari"),
            BotCommand(command="web", description="Web va mobil ilovaga kirish kodi"),
            BotCommand(command="pending", description="Tasdiqlash kutilayotgan qarzlar"),
            BotCommand(command="invite", description="Kontakt taklif qilish"),
            BotCommand(command="help", description="Yordam"),
        ]
    )
    dispatcher = Dispatcher(storage=MemoryStorage())
    dispatcher.update.middleware(session_middleware)
    dispatcher.include_router(router)

    scheduler_task = asyncio.create_task(scheduler_loop(bot, session_factory))
    try:
        await dispatcher.start_polling(bot)
    finally:
        scheduler_task.cancel()
        try:
            await scheduler_task
        except asyncio.CancelledError:
            pass
        await bot.session.close()
        await engine.dispose()


if __name__ == "__main__":
    asyncio.run(main())
