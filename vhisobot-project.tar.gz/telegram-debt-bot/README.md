# Qarzdor — Telegram qarz hisoblagich bot

Ushbu loyiha Python, aiogram 3 va async SQLAlchemy asosida qurilgan. Bot foydalanuvchilar o‘rtasidagi pulli oldi-berdilarni tarix bilan saqlaydi va har ikki tomonga bir xil tranzaksiyani qarama-qarshi ma’noda ko‘rsatadi.

## 1. Biznes mantiq

Har bir tranzaksiya quyidagi yagona matematik shaklda saqlanadi:

```text
debtor   -> pulni qaytarishi kerak bo‘lgan foydalanuvchi
creditor -> pulni olishi kerak bo‘lgan foydalanuvchi
amount   -> musbat summa
```

Shu sababli:

| Kim kiritdi | Tanlov | Natija |
|---|---|---|
| A | Oldim 50 000 | A B ga qarzdor: +50 000 |
| A | Berdim 50 000 | B A ga qarzdor: +50 000 |

Foydalanuvchi uchun juftlik balansi:

```text
net(A, B) = A qarzdor bo‘lgan summalar - A ga qarzdor bo‘lgan summalar
```

`net > 0` bo‘lsa, foydalanuvchi qarzdor. `net < 0` bo‘lsa, boshqa tomon qarzdor.

`debts` jadvali tezkor `/balance` javobi uchun materialized net cache hisoblanadi. Har yangi tranzaksiyadan keyin juftlik bo‘yicha `SUM` qayta hisoblanadi. Shu bilan `transactions` tarixi manba sifatida saqlanib qoladi va balans buzilib ketsa qayta tiklanishi mumkin.

## Qo‘shimcha imkoniyatlar

- Barcha tranzaksiya vaqtlar `Asia/Tashkent` — O‘zbekiston vaqti bo‘yicha ko‘rsatiladi.
- Bosh menyuda `Qarz qo'shish`, `Balans`, `Tarix`, `Barcha tarix`, `Kontakt taklif qilish` va `Yordam` tugmalari bor.
- Asosiy valyutalar: `UZS`, `USD`, `TRY`, `AED`, `SAR`.
- Kerak bo‘lsa, `Boshqa valyuta` tugmasi orqali istalgan 3 harfli ISO valyuta kodini kiritish mumkin.
- Valyutalar bir-biriga avtomatik aylantirilmaydi. Masalan, `100 USD` va `100 000 UZS` alohida balans hisoblanadi.
- Botni guruhga qo‘shish mumkin. Guruhda qarz qo‘shish uchun `/add` buyrug‘ini qarz hisoblanadigan odamning xabariga reply qilib yuborish kerak.

## 2. Ma’lumotlar bazasi sxemasi

### `users`

- `id` — ichki primary key
- `telegram_id` — Telegram’dagi unikal ID
- `username`, `first_name`, `last_name`
- `created_at`

### `user_links`

Bu yordamchi jadval. `/invite` deep-link’i orqali ikki foydalanuvchini o‘zaro kontakt qiladi.

- `user_id`
- `contact_id`
- `created_at`

### `transactions`

- `id`
- `debtor_id`
- `creditor_id`
- `entered_by_id` — tranzaksiyani kim kiritgani
- `scope_chat_id` — `0` shaxsiy hisobot, guruh ID’si esa shu guruh hisoboti
- `amount` — musbat integer
- `currency` — `UZS`, `USD`, `EUR`, `RUB`, `KZT`, `TRY`, `GBP` yoki `CNY`
- `direction` — `received` yoki `given`
- `note`
- `created_at`

### `debts`

Juftlik bo‘yicha joriy net balans:

- `user_low_id`, `user_high_id` — doim `id` bo‘yicha tartiblangan juftlik
- `scope_chat_id` — har bir guruh uchun alohida balans maydoni
- `currency`
- `balance_low_to_high`
- `updated_at`

`balance_low_to_high > 0` bo‘lsa, `user_low_id` `user_high_id`ga qarzdor. Manfiy qiymat teskari yo‘nalishni anglatadi.

## 3. O‘rnatish

```bash
cd telegram-debt-bot
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

Oddiy lokal ishga tushirishda `.env` ichida BotFather bergan tokenni kiriting:

```env
BOT_TOKEN=123456:replace-me
DATABASE_URL=sqlite+aiosqlite:///./debts.db
```

Replit’da esa token `TELEGRAM_BOT_TOKEN` nomli Secret sifatida ishlatiladi va
qo‘lda `.env` yaratish shart emas.

Ishga tushirish:

```bash
python main.py
```

Algoritm testlarini ishga tushirish:

```bash
pip install -r requirements-dev.txt
pytest -q tests
```

PostgreSQL uchun:

```env
DATABASE_URL=postgresql+asyncpg://user:password@localhost:5432/debts
```

Ishlab chiqarish muhitida `create_all` o‘rniga Alembic migratsiyalaridan foydalanish tavsiya qilinadi.

## 4. Bot buyruqlari

- `/start` — ro‘yxatdan o‘tish va yordam
- `/invite` — Telegram kontakt tanlash tugmasi orqali boshqa foydalanuvchini ulash
- `/add` — `Oldim` yoki `Berdim` tranzaksiyasini kiritish
- `/balance` — kim kimga qancha qarzdorligini ko‘rish
- `/history` — tanlangan kontakt bilan tarix
- `/all_history` — barcha so‘nggi operatsiyalar
- `/id` — Telegram va ichki ID’larni ko‘rish
- `/help` — foydalanish tushuntirishi

## 5. Muhim arxitektura qarorlari

1. **Dublikat tranzaksiya yo‘q.** A kiritgan operatsiyani B nomidan ikkinchi marta yozish balansni ikki baravar oshiradi. Buning o‘rniga bitta `debtor -> creditor` yozuvi ikkala tomonda qarama-qarshi ko‘rsatiladi.
2. **Pul `int` sifatida saqlanadi.** UZS tiyin ishlatilmagan holatda `Decimal` rounding muammolari bo‘lmaydi.
3. **Tarix o‘chirilmaydi.** Audit va qayta hisoblash uchun `transactions` append-only manba sifatida qoldiriladi.
4. **Xabar yuborish bazaviy commit’dan keyin amalga oshadi.** Qarshi foydalanuvchi botni bloklagan bo‘lsa ham, asosiy tranzaksiya saqlanib qoladi.
5. **FSM input oqimini boshqaradi.** Kontakt, yo‘nalish, summa va izoh alohida bosqichlarda tekshiriladi.

## 6. Keyingi production yaxshilanishlari

- Alembic migratsiyalari
- Redis FSM storage va webhook
- tranzaksiyani bekor qilish uchun auditli reversal transaction
- PostgreSQL `SELECT ... FOR UPDATE` bilan yuqori parallelizm uchun juftlik lock’i
- webhook serveri va health-check
- rate limit va admin monitoring
