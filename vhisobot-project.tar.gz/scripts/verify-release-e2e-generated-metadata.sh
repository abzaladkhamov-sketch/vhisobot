#!/bin/sh

set -eu

if [ "$#" -ne 1 ] || [ -z "$1" ]; then
  echo "usage: $0 PLAYWRIGHT_VERSION" >&2
  exit 2
fi

project_root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
playwright_version=$1
candidate_dir=$(mktemp -d "${TMPDIR:-/tmp}/release-e2e-generated-metadata.XXXXXX")

cleanup() {
  rm -rf "$candidate_dir"
}
trap cleanup EXIT HUP INT TERM

print_root_importer_diagnostics() {
  echo "release gate generated metadata verification failed with status $1" >&2
  echo "release gate generated metadata diagnostics: pnpm $(pnpm --version), Playwright $playwright_version" >&2
  echo "--- generated pnpm-lock.yaml root importer ---" >&2
  if [ -f "$candidate_dir/pnpm-lock.yaml" ]; then
    awk '
      /^importers:/ {
        in_importers = 1
        next
      }
      in_importers && /^  \.:$/ {
        in_root_importer = 1
        print
        next
      }
      in_root_importer && /^packages:/ {
        exit
      }
      in_root_importer && /^  [^ .]/ {
        exit
      }
      in_root_importer {
        print
      }
    ' "$candidate_dir/pnpm-lock.yaml" >&2
  else
    echo "(pnpm-lock.yaml was not generated)" >&2
  fi
}

cat >"$candidate_dir/package.json" <<EOF
{
  "name": "release-e2e-generated-playwright-$playwright_version",
  "private": true,
  "devDependencies": {
    "@playwright/test": "$playwright_version"
  }
}
EOF

echo "release gate generated metadata: pnpm $(pnpm --version), Playwright $playwright_version"
if pnpm --dir "$candidate_dir" install \
  --lockfile-only \
  --ignore-scripts \
  --config.auto-install-peers=false
then
  :
else
  install_status=$?
  print_root_importer_diagnostics "$install_status" || :
  exit "$install_status"
fi

if RELEASE_E2E_PROJECT_ROOT="$candidate_dir" \
  RELEASE_E2E_DOCUMENTED_PLAYWRIGHT_VERSIONS="$playwright_version" \
  RELEASE_E2E_SKIP_COMPATIBILITY_PROBES=1 \
  sh "$project_root/scripts/verify-release-e2e-concurrency.sh"
then
  :
else
  verification_status=$?
  print_root_importer_diagnostics "$verification_status" || :
  exit "$verification_status"
fi
