#!/bin/sh

set -eu

project_root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
python_bin=${RELEASE_PYTHON_BIN:-python}
database_url=${DATABASE_URL:-}
diagnostics_dir=$(mktemp -d "${TMPDIR:-/tmp}/release-gate-mobile.XXXXXX")

cleanup() {
  rm -rf "$diagnostics_dir"
}
trap cleanup EXIT HUP INT TERM

case "$database_url" in
  postgres://*|postgresql://*|postgresql+asyncpg://*)
    ;;
  *)
    printf '%s\n' \
      "release gate mobile transaction check failed: DATABASE_URL must point to PostgreSQL" >&2
    exit 1
    ;;
esac

printf '%s\n' "release gate: running mobile PostgreSQL transaction flow"
cd "$project_root"
if MOBILE_TRANSACTION_DIAGNOSTICS_DIR="$diagnostics_dir" \
  MOBILE_TRANSACTION_TEST_FAILURE="${RELEASE_MOBILE_TEST_FAILURE:-}" \
  "$python_bin" -m pytest -q \
  telegram-debt-bot/tests/test_api_delivery_privacy_postgres.py::test_mobile_entry_creates_a_postgresql_transaction_without_telegram \
  telegram-debt-bot/tests/test_api_delivery_privacy_postgres.py::test_mobile_entry_failure_captures_real_server_diagnostics
then
  exit 0
else
  status=$?
fi

printf '%s\n' \
  "release gate mobile PostgreSQL transaction flow failed with status $status" >&2
for server in api-server mobile-server; do
  printf '%s\n' "--- $server diagnostics ---" >&2
  if [ -f "$diagnostics_dir/$server.log" ]; then
    cat "$diagnostics_dir/$server.log" >&2 || :
  else
    printf '%s\n' "(no diagnostics captured)" >&2
  fi
done
exit "$status"