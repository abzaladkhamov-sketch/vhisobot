#!/bin/sh

set -eu

project_root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)

pnpm --dir "$project_root" run test:e2e:release:install-browsers
pnpm --dir "$project_root" run test:e2e:release:mobile
CI=true sh "$project_root/scripts/run-release-e2e-playwright.sh" test
