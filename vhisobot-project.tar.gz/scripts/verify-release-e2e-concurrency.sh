#!/bin/sh

set -eu

if [ "${RELEASE_E2E_PROJECT_ROOT+x}" = x ]; then
  project_root=$RELEASE_E2E_PROJECT_ROOT
else
  project_root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
fi

# Keep this documented compatibility set at the minimum supported Playwright
# version and the version currently resolved by pnpm-lock.yaml. The validation
# below fails when either package.json or pnpm-lock.yaml changes without this
# set being updated. Override the probe list when adding a temporary candidate,
# for example:
# RELEASE_E2E_PLAYWRIGHT_VERSIONS="1.56.1 1.62.1 1.63.0" pnpm run test:e2e:release:concurrency
default_documented_playwright_versions="1.56.1 1.62.1"
documented_playwright_versions=${RELEASE_E2E_DOCUMENTED_PLAYWRIGHT_VERSIONS:-$default_documented_playwright_versions}

normalize_versions() {
  for version in $1; do
    printf '%s\n' "$version"
  done | sort -u | tr '\n' ' ' | sed 's/ $//'
}

package_playwright_metadata=$(
  node - "$project_root/package.json" <<'NODE'
const fs = require("fs");

const packagePath = process.argv[2];
const packageJson = JSON.parse(fs.readFileSync(packagePath, "utf8"));
const specifier = packageJson.devDependencies?.["@playwright/test"];
const minimumVersion = String(specifier ?? "").match(/\d+\.\d+\.\d+/)?.[0];

if (!specifier || !minimumVersion) {
  console.error(
    "release gate Playwright compatibility failed: package.json has no semver-based @playwright/test version range",
  );
  console.error(
    'release gate Playwright compatibility remediation: set devDependencies["@playwright/test"] to a semver-based range (for example, ^1.56.1), then run pnpm install',
  );
  process.exit(1);
}

process.stdout.write(`${specifier}\n${minimumVersion}\n`);
NODE
)
package_playwright_specifier=$(printf '%s\n' "$package_playwright_metadata" | sed -n '1p')
package_playwright_minimum=$(printf '%s\n' "$package_playwright_metadata" | sed -n '2p')

lockfile_playwright_metadata=$(
  awk '
    /^importers:/ {
      in_importers = 1
      next
    }
    in_importers && /^  \.:$/ {
      in_root_importer = 1
      next
    }
    in_root_importer && /^  [^ .]/ {
      exit
    }
    in_root_importer && /^      .*@playwright\/test.*:$/ {
      in_playwright_dependency = 1
      playwright_dependency_found = 1
      next
    }
    in_playwright_dependency && /^      [^ ]/ {
      in_playwright_dependency = 0
      next
    }
    in_playwright_dependency && /^        specifier:/ {
      specifier = $2
      next
    }
    in_playwright_dependency && /^        version:/ {
      raw_version = $2
      version = raw_version
      sub(/[^0-9.].*/, "", version)
      next
    }
    END {
      if (playwright_dependency_found) {
        print specifier
        print version
        print raw_version
        print "present"
      }
    }
  ' "$project_root/pnpm-lock.yaml"
)
lockfile_playwright_specifier=$(printf '%s\n' "$lockfile_playwright_metadata" | sed -n '1p')
lockfile_playwright_version=$(printf '%s\n' "$lockfile_playwright_metadata" | sed -n '2p')
lockfile_playwright_raw_version=$(printf '%s\n' "$lockfile_playwright_metadata" | sed -n '3p')
lockfile_playwright_dependency=$(printf '%s\n' "$lockfile_playwright_metadata" | sed -n '4p')

if [ -z "$lockfile_playwright_dependency" ]; then
  echo "release gate Playwright compatibility failed: pnpm-lock.yaml has no root @playwright/test importer" >&2
  echo "release gate Playwright compatibility remediation: run pnpm install, then review documented_playwright_versions in scripts/verify-release-e2e-concurrency.sh" >&2
  exit 1
fi

if [ -z "$lockfile_playwright_specifier" ] || [ -z "$lockfile_playwright_raw_version" ]; then
  missing_lockfile_metadata=""
  if [ -z "$lockfile_playwright_specifier" ]; then
    missing_lockfile_metadata="specifier"
  fi
  if [ -z "$lockfile_playwright_raw_version" ]; then
    if [ -n "$missing_lockfile_metadata" ]; then
      missing_lockfile_metadata="$missing_lockfile_metadata and resolved version"
    else
      missing_lockfile_metadata="resolved version"
    fi
  fi
  echo "release gate Playwright compatibility failed: pnpm-lock.yaml has incomplete root @playwright/test importer metadata (missing $missing_lockfile_metadata)" >&2
  echo "release gate Playwright compatibility remediation: run pnpm install to restore the root @playwright/test specifier and resolved version, then review documented_playwright_versions in scripts/verify-release-e2e-concurrency.sh" >&2
  exit 1
fi

if ! node - "$lockfile_playwright_raw_version" <<'NODE'
const rawVersion = process.argv[2];
const versionWithoutPeerContext = rawVersion.replace(/\(.*/, "");
const semverPattern =
  /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(-[0-9A-Za-z-]+(\.[0-9A-Za-z-]+)*)?(\+[0-9A-Za-z-]+(\.[0-9A-Za-z-]+)*)?$/;
const semverPrefixPattern =
  /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(-[0-9A-Za-z-]+(\.[0-9A-Za-z-]+)*)?(\+[0-9A-Za-z-]+(\.[0-9A-Za-z-]+)*)?/;
const packageNamePattern = /^(?:@[a-z0-9._-]+\/)?[a-z0-9._-]+$/i;
const peerContext = rawVersion.slice(versionWithoutPeerContext.length);

function parsePeerDescriptor(value, start) {
  if (value[start] !== "(") {
    return -1;
  }

  let position = start + 1;
  const atSign = value[position] === "@"
    ? value.indexOf("@", position + 1)
    : value.indexOf("@", position);

  if (atSign === -1) {
    return -1;
  }

  const packageName = value.slice(position, atSign);
  if (!packageNamePattern.test(packageName)) {
    return -1;
  }

  position = atSign + 1;
  const versionMatch = value.slice(position).match(semverPrefixPattern);
  if (!versionMatch) {
    return -1;
  }
  position += versionMatch[0].length;

  while (value[position] === "(") {
    position = parsePeerDescriptor(value, position);
    if (position === -1) {
      return -1;
    }
  }

  return value[position] === ")" ? position + 1 : -1;
}

function isValidPeerContext(value) {
  let position = 0;
  while (position < value.length) {
    position = parsePeerDescriptor(value, position);
    if (position === -1) {
      return false;
    }
  }
  return true;
}

if (!semverPattern.test(versionWithoutPeerContext) || (peerContext && !isValidPeerContext(peerContext))) {
  process.exit(1);
}
NODE
then
  echo "release gate Playwright compatibility failed: pnpm-lock.yaml has malformed root @playwright/test resolved version ($lockfile_playwright_raw_version)" >&2
  echo "release gate Playwright compatibility remediation: run pnpm install to restore a valid root @playwright/test resolved version, then review documented_playwright_versions in scripts/verify-release-e2e-concurrency.sh" >&2
  exit 1
fi

if [ "$package_playwright_specifier" != "$lockfile_playwright_specifier" ]; then
  echo "release gate Playwright compatibility failed: package.json and pnpm-lock.yaml disagree about @playwright/test" >&2
  echo "  package.json: $package_playwright_specifier" >&2
  echo "  pnpm-lock.yaml: $lockfile_playwright_specifier" >&2
  echo "release gate Playwright compatibility remediation: run pnpm install to refresh pnpm-lock.yaml, then update documented_playwright_versions if the resolved version changed" >&2
  exit 1
fi

expected_playwright_versions="$package_playwright_minimum $lockfile_playwright_version"
normalized_documented_versions=$(normalize_versions "$documented_playwright_versions")
normalized_expected_versions=$(normalize_versions "$expected_playwright_versions")

if [ "$normalized_documented_versions" != "$normalized_expected_versions" ]; then
  echo "release gate Playwright compatibility failed: documented compatibility set is stale" >&2
  echo "  documented: $normalized_documented_versions" >&2
  echo "  expected:   $normalized_expected_versions" >&2
  echo "release gate Playwright compatibility remediation: update documented_playwright_versions in scripts/verify-release-e2e-concurrency.sh to include the package minimum and lockfile-resolved version" >&2
  exit 1
fi

echo "release gate Playwright compatibility metadata: documented set matches package minimum $package_playwright_minimum and lockfile-resolved version $lockfile_playwright_version"

if [ "${RELEASE_E2E_SKIP_COMPATIBILITY_PROBES:-0}" = 1 ]; then
  echo "release gate Playwright compatibility probes: skipped by test fixture"
  exit 0
fi

if [ "${RELEASE_E2E_PLAYWRIGHT_VERSIONS+x}" = x ]; then
  playwright_versions=$RELEASE_E2E_PLAYWRIGHT_VERSIONS
else
  playwright_versions=$documented_playwright_versions
fi

if [ -z "$playwright_versions" ]; then
  echo "release gate Playwright compatibility failed: no Playwright versions configured" >&2
  exit 1
fi

if [ "${RELEASE_E2E_FORCE_LOCK_CHECK_FAILURE:-0}" = 1 ]; then
  echo "release gate lock check failed: forced failure for short-circuit regression" >&2
  exit 1
fi

verify_release_diagnostics() {
temp_dir=$(mktemp -d "${TMPDIR:-/tmp}/release-e2e-concurrency.XXXXXX")
lock_file="$temp_dir/release.lock"

probe_command='printf "release-gate probe %s\n" "$RELEASE_E2E_PROBE_ID"; sleep 1'
if [ "${RELEASE_E2E_FORCE_APPLICATION_FAILURE:-0}" = 1 ]; then
  probe_command='printf "release-gate probe %s\n" "$RELEASE_E2E_PROBE_ID"; exit 1'
fi

run_gate() {
  probe_id=$1
  RELEASE_E2E_PROBE_ID="$probe_id" \
    RELEASE_E2E_LOCK_FILE="$lock_file" \
    RELEASE_E2E_COMMAND="$probe_command" \
    pnpm run test:e2e:release >"$temp_dir/$probe_id.log" 2>&1
}

run_gate first &
first_pid=$!

attempt=0
while ! grep -q "release-gate probe first" "$temp_dir/first.log" 2>/dev/null; do
  attempt=$((attempt + 1))
  if [ "$attempt" -ge 100 ]; then
    echo "release gate lock check failed: first invocation never acquired the lock" >&2
    exit 1
  fi
  sleep 0.05
done

run_gate second &
second_pid=$!

set +e
wait "$first_pid"
first_status=$?
wait "$second_pid"
second_status=$?
set -e

if [ "$first_status" -ne 0 ] || [ "$second_status" -ne 0 ]; then
  failure_status=$first_status
  if [ "$failure_status" -eq 0 ]; then
    failure_status=$second_status
  fi
  echo "release gate application failures: first=$first_status second=$second_status" >&2
  echo "--- first invocation ---" >&2
  cat "$temp_dir/first.log" >&2 || :
  echo "--- second invocation ---" >&2
  cat "$temp_dir/second.log" >&2 || :
  exit "$failure_status"
fi

if ! awk '
  /flock: getting lock took/ && $6 > 0 {
    waited = 1
  }
  END {
    exit waited ? 0 : 1
  }
' "$temp_dir/second.log"; then
  echo "release gate lock check failed: second invocation did not report waiting" >&2
  echo "--- first invocation ---" >&2
  cat "$temp_dir/first.log" >&2
  echo "--- second invocation ---" >&2
  cat "$temp_dir/second.log" >&2
  exit 1
fi

echo "release gate lock behavior: second invocation waited for the shared lock"
echo "release gate application status: both invocations exited successfully"

set +e
application_failure_output=$(
  RELEASE_E2E_COMMAND='pnpm run test:e2e:release:application-failure' \
    pnpm run test:e2e:release 2>&1
)
application_failure_status=$?
set -e

application_failure_report="release gate application failures: Playwright test exited with status $application_failure_status"

if [ "$application_failure_status" -eq 0 ]; then
  echo "release gate application-failure regression failed: Playwright failure unexpectedly passed" >&2
  printf '%s\n' "$application_failure_output" >&2
  exit 1
fi

if ! printf '%s\n' "$application_failure_report" | grep -q "release gate application failures:"; then
  echo "release gate application-failure regression failed: failure output did not identify the application" >&2
  printf '%s\n' "$application_failure_output" >&2
  exit 1
fi

if printf '%s\n' "$application_failure_output" | grep -q "release gate lock check failed:"; then
  echo "release gate application-failure regression failed: application failure was reported as a lock failure" >&2
  printf '%s\n' "$application_failure_output" >&2
  exit 1
fi

echo "$application_failure_report"
echo "release gate failure behavior: application failure remained distinct from lock-check failure"

set +e
setup_failure_output=$(
  RELEASE_E2E_COMMAND='pnpm run test:e2e:release:setup-failure' \
    pnpm run test:e2e:release 2>&1
)
setup_failure_status=$?
set -e

setup_failure_marker="release gate test-server setup fixture failed"
setup_failure_report="release gate setup failures: Playwright test-server setup exited with status $setup_failure_status"

if [ "$setup_failure_status" -eq 0 ]; then
  echo "release gate setup-failure regression failed: setup failure unexpectedly passed" >&2
  printf '%s\n' "$setup_failure_output" >&2
  exit 1
fi

if ! printf '%s\n' "$setup_failure_output" | grep -q "$setup_failure_marker"; then
  echo "release gate setup-failure regression failed: failure output did not identify test-server setup" >&2
  printf '%s\n' "$setup_failure_output" >&2
  exit 1
fi

if printf '%s\n' "$setup_failure_output" | grep -q "release gate lock check failed:"; then
  echo "release gate setup-failure regression failed: setup failure was reported as a lock failure" >&2
  printf '%s\n' "$setup_failure_output" >&2
  exit 1
fi

echo "$setup_failure_report"
echo "release gate failure behavior: test-server setup failure remained distinct from lock-check failure"

set +e
browser_install_failure_output=$(
  RELEASE_E2E_COMMAND='pnpm run test:e2e:release:browser-install-failure' \
    pnpm run test:e2e:release 2>&1
)
browser_install_failure_status=$?
set -e

browser_install_failure_marker="release gate browser setup failures:"
browser_install_failure_report="$browser_install_failure_marker Playwright browser installation exited with status $browser_install_failure_status"

if [ "$browser_install_failure_status" -eq 0 ]; then
  echo "release gate browser-install-failure regression failed: browser installation unexpectedly passed" >&2
  printf '%s\n' "$browser_install_failure_output" >&2
  exit 1
fi

if ! printf '%s\n' "$browser_install_failure_output" | grep -q "$browser_install_failure_marker"; then
  echo "release gate browser-install-failure regression failed: failure output did not identify browser setup" >&2
  printf '%s\n' "$browser_install_failure_output" >&2
  exit 1
fi

if printf '%s\n' "$browser_install_failure_output" | grep -q "release gate application failures:"; then
  echo "release gate browser-install-failure regression failed: browser setup failure was reported as an application failure" >&2
  printf '%s\n' "$browser_install_failure_output" >&2
  exit 1
fi

if printf '%s\n' "$browser_install_failure_output" | grep -q "release gate lock check failed:"; then
  echo "release gate browser-install-failure regression failed: browser setup failure was reported as a lock failure" >&2
  printf '%s\n' "$browser_install_failure_output" >&2
  exit 1
fi

echo "$browser_install_failure_report"
echo "release gate failure behavior: browser installation failure remained distinct from application and lock-check failures"

browser_marker="$temp_dir/browser-release-started"
set +e
short_circuit_output=$(
  RELEASE_E2E_FORCE_LOCK_CHECK_FAILURE=1 \
    RELEASE_E2E_COMMAND=": > \"$browser_marker\"" \
    pnpm run prebuild 2>&1
)
short_circuit_status=$?
set -e

if [ "$short_circuit_status" -eq 0 ]; then
  echo "release gate lock-check regression failed: forced failure unexpectedly passed" >&2
  printf '%s\n' "$short_circuit_output" >&2
  exit 1
fi

if [ -e "$browser_marker" ]; then
  echo "release gate lock-check regression failed: browser release command started after lock-check failure" >&2
  printf '%s\n' "$short_circuit_output" >&2
  exit 1
fi

if ! printf '%s\n' "$short_circuit_output" | grep -q "release gate lock check failed:"; then
  echo "release gate lock-check regression failed: failure output did not identify the lock check" >&2
  printf '%s\n' "$short_circuit_output" >&2
  exit 1
fi

if printf '%s\n' "$short_circuit_output" | grep -q "release gate application failures:"; then
  echo "release gate lock-check regression failed: lock failure was reported as an application failure" >&2
  printf '%s\n' "$short_circuit_output" >&2
  exit 1
fi

echo "release gate failure behavior: lock-check failure skipped the browser release command"
}

for playwright_version in $playwright_versions; do
  candidate_dir=$(mktemp -d "${TMPDIR:-/tmp}/release-e2e-playwright.XXXXXX")
  candidate_cleanup() {
    rm -rf "$candidate_dir" "${temp_dir:-}"
  }
  trap candidate_cleanup EXIT HUP INT TERM

  printf '{"name":"release-e2e-playwright-%s","private":true}\n' "$playwright_version" >"$candidate_dir/package.json"
  mkdir -p "$candidate_dir/tests"
  cp "$project_root/playwright.release-failure.config.ts" "$candidate_dir/"
  cp -R "$project_root/tests/release" "$candidate_dir/tests/"
  pnpm --dir "$candidate_dir" add --save-dev --ignore-scripts "@playwright/test@$playwright_version"

  echo "release gate Playwright compatibility: testing version $playwright_version"
  RELEASE_E2E_PLAYWRIGHT_BIN="$candidate_dir/node_modules/.bin/playwright" \
    RELEASE_E2E_PLAYWRIGHT_CWD="$candidate_dir" \
    verify_release_diagnostics

  candidate_cleanup
  trap - EXIT HUP INT TERM
done
