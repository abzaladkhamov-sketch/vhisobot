#!/bin/sh

set -eu

if [ -n "${RELEASE_E2E_BROWSER_INSTALL_COMMAND:-}" ]; then
  sh -c "$RELEASE_E2E_BROWSER_INSTALL_COMMAND"
else
  playwright_bin=${RELEASE_E2E_PLAYWRIGHT_BIN:-playwright}
  "$playwright_bin" install chromium
fi
