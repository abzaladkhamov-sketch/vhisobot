const assert = require("node:assert/strict");
const { execFileSync } = require("node:child_process");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const test = require("node:test");

const projectRoot = path.resolve(__dirname, "../..");
const releaseGate = path.join(
  projectRoot,
  "scripts/verify-release-e2e-concurrency.sh",
);
const browserInstaller = path.join(
  projectRoot,
  "scripts/install-release-e2e-browsers.sh",
);
const releaseWorkflow = path.join(
  projectRoot,
  ".github/workflows/release-e2e-generated-metadata.yml",
);
const fixturesRoot = path.join(
  projectRoot,
  "scripts/tests/fixtures/playwright-metadata",
);

function workflowStep(workflow, name) {
  const header = `      - name: ${name}`;
  const start = workflow.indexOf(header);
  assert.notEqual(start, -1, `workflow step not found: ${name}`);

  const nextStep = workflow.indexOf("\n      - name: ", start + header.length);
  return workflow.slice(start, nextStep === -1 ? workflow.length : nextStep);
}

function supportedPosixShells() {
  return ["sh", "dash", "bash"].filter((shell) => {
    try {
      execFileSync("sh", ["-c", `command -v ${shell}`], {
        stdio: "ignore",
      });
      return true;
    } catch {
      return false;
    }
  });
}

function testAcrossSupportedPosixShells(name, callback) {
  for (const shell of supportedPosixShells()) {
    test(`${name} under ${shell}`, () => callback(shell));
  }
}

function runReleaseGate(fixtureName, environment = {}) {
  const fixtureRoot = path.join(fixturesRoot, fixtureName);
  const env = {
    ...process.env,
    RELEASE_E2E_PROJECT_ROOT: fixtureRoot,
    ...environment,
  };

  try {
    const stdout = execFileSync("sh", [releaseGate], {
      cwd: projectRoot,
      env,
      encoding: "utf8",
      stdio: ["ignore", "pipe", "pipe"],
    });
    return { status: 0, output: stdout };
  } catch (error) {
    return {
      status: error.status ?? 1,
      output: `${error.stdout ?? ""}${error.stderr ?? ""}`,
    };
  }
}

function probeMarkerEnvironment() {
  const tempRoot = fs.mkdtempSync(
    path.join(os.tmpdir(), "release-e2e-metadata-test-"),
  );
  const marker = path.join(tempRoot, "probe-started");

  return {
    marker,
    environment: {
      RELEASE_E2E_COMMAND: `: > '${marker}'`,
    },
  };
}

test("reports the generated root importer when verification fails", () => {
  const tempRoot = fs.mkdtempSync(
    path.join(os.tmpdir(), "release-e2e-generated-metadata-test-"),
  );
  const fakePnpm = path.join(tempRoot, "pnpm");
  const fakePnpmScript = `#!/bin/sh
if [ "$1" = "--version" ]; then
  echo "fixture-pnpm"
  exit 0
fi

if [ "$1" = "--dir" ]; then
  candidate_dir=$2
  cat >"$candidate_dir/pnpm-lock.yaml" <<'LOCKFILE'
lockfileVersion: '9.0'

importers:
  .:
    devDependencies:
      '@playwright/test':
        specifier: 1.56.1
        version: not-a-version
LOCKFILE
  exit 0
fi

echo "unexpected pnpm fixture arguments" >&2
exit 1
`;

  fs.writeFileSync(fakePnpm, fakePnpmScript, { mode: 0o755 });

  try {
    const result = execFileSync(
      "sh",
      [
        path.join(
          projectRoot,
          "scripts/verify-release-e2e-generated-metadata.sh",
        ),
        "1.56.1",
      ],
      {
        cwd: projectRoot,
        env: {
          ...process.env,
          PATH: `${tempRoot}:${process.env.PATH}`,
        },
        encoding: "utf8",
        stdio: ["ignore", "pipe", "pipe"],
      },
    );

    assert.fail(`expected generated metadata verification to fail: ${result}`);
  } catch (error) {
    const output = `${error.stdout ?? ""}${error.stderr ?? ""}`;
    assert.equal(error.status, 1, output);
    assert.match(
      output,
      /release gate Playwright compatibility failed: pnpm-lock\.yaml has malformed root @playwright\/test resolved version \(not-a-version\)/,
    );
    assert.match(
      output,
      /release gate generated metadata diagnostics: pnpm fixture-pnpm, Playwright 1\.56\.1/,
    );
    assert.match(
      output,
      /--- generated pnpm-lock\.yaml root importer ---[\s\S]*version: not-a-version/,
    );
  } finally {
    fs.rmSync(tempRoot, { recursive: true, force: true });
  }
});

test("reports when pnpm fails before generating a lockfile", () => {
  const tempRoot = fs.mkdtempSync(
    path.join(os.tmpdir(), "release-e2e-generated-metadata-test-"),
  );
  const fakePnpm = path.join(tempRoot, "pnpm");
  const fakePnpmScript = `#!/bin/sh
if [ "$1" = "--version" ]; then
  echo "fixture-pnpm"
  exit 0
fi

if [ "$1" = "--dir" ]; then
  echo "fixture pnpm install failed before lockfile generation" >&2
  exit 23
fi

echo "unexpected pnpm fixture arguments" >&2
exit 1
`;

  fs.writeFileSync(fakePnpm, fakePnpmScript, { mode: 0o755 });

  try {
    execFileSync(
      "sh",
      [
        path.join(
          projectRoot,
          "scripts/verify-release-e2e-generated-metadata.sh",
        ),
        "1.56.1",
      ],
      {
        cwd: projectRoot,
        env: {
          ...process.env,
          PATH: `${tempRoot}:${process.env.PATH}`,
        },
        encoding: "utf8",
        stdio: ["ignore", "pipe", "pipe"],
      },
    );

    assert.fail("expected generated metadata installation to fail");
  } catch (error) {
    const output = `${error.stdout ?? ""}${error.stderr ?? ""}`;
    assert.equal(error.status, 23, output);
    assert.match(
      output,
      /release gate generated metadata verification failed with status 23/,
    );
    assert.match(
      output,
      /\(pnpm-lock\.yaml was not generated\)/,
    );
  } finally {
    fs.rmSync(tempRoot, { recursive: true, force: true });
  }
});

testAcrossSupportedPosixShells(
  "preserves the install failure status when diagnostics fail",
  (shell) => {
    const tempRoot = fs.mkdtempSync(
      path.join(os.tmpdir(), "release-e2e-generated-metadata-test-"),
    );
    const fakePnpm = path.join(tempRoot, "pnpm");
    const countFile = path.join(tempRoot, "pnpm-invocations");
    const fakePnpmScript = `#!/bin/sh
count_file=\${RELEASE_E2E_TEST_COUNT_FILE:?}
count=0
if [ -f "$count_file" ]; then
  count=\$(cat "$count_file")
fi
count=$((count + 1))
printf '%s\\n' "$count" >"$count_file"

if [ "$1" = "--version" ]; then
  if [ "$count" -gt 1 ]; then
    echo "fixture pnpm diagnostics failed" >&2
    exit 91
  fi
  echo "fixture-pnpm"
  exit 0
fi

if [ "$1" = "--dir" ]; then
  echo "fixture pnpm install failed" >&2
  exit 23
fi

echo "unexpected pnpm fixture arguments" >&2
exit 1
`;

    fs.writeFileSync(fakePnpm, fakePnpmScript, { mode: 0o755 });

    try {
      execFileSync(
        shell,
        [
          path.join(
            projectRoot,
            "scripts/verify-release-e2e-generated-metadata.sh",
          ),
          "1.56.1",
        ],
        {
          cwd: projectRoot,
          env: {
            ...process.env,
            PATH: `${tempRoot}:${process.env.PATH}`,
            RELEASE_E2E_TEST_COUNT_FILE: countFile,
          },
          encoding: "utf8",
          stdio: ["ignore", "pipe", "pipe"],
        },
      );

      assert.fail("expected generated metadata installation to fail");
    } catch (error) {
      const output = `${error.stdout ?? ""}${error.stderr ?? ""}`;
      assert.equal(error.status, 23, output);
      assert.match(
        output,
        /release gate generated metadata verification failed with status 23/,
      );
      assert.match(output, /fixture pnpm diagnostics failed/);
    } finally {
      fs.rmSync(tempRoot, { recursive: true, force: true });
    }
  },
);

testAcrossSupportedPosixShells(
  "preserves a failed probe status when concurrency diagnostics fail",
  (shell) => {
    const tempRoot = fs.mkdtempSync(
      path.join(os.tmpdir(), "release-e2e-concurrency-test-"),
    );
    const fakePnpm = path.join(tempRoot, "pnpm");
    const fakeCat = path.join(tempRoot, "cat");
    const fakePnpmScript = `#!/bin/sh
if [ "$1" = "--dir" ]; then
  exit 0
fi

if [ "$1" = "run" ] && [ "$2" = "test:e2e:release" ]; then
  printf 'release-gate probe %s\\n' "$RELEASE_E2E_PROBE_ID"
  exit 23
fi

echo "unexpected pnpm fixture arguments" >&2
exit 1
`;
    const fakeCatScript = `#!/bin/sh
case "$1" in
  */first.log|*/second.log)
    echo "fixture concurrency diagnostics failed" >&2
    exit 91
    ;;
  *)
    exec /bin/cat "$@"
    ;;
esac
`;

    fs.writeFileSync(fakePnpm, fakePnpmScript, { mode: 0o755 });
    fs.writeFileSync(fakeCat, fakeCatScript, { mode: 0o755 });

    try {
      execFileSync(shell, [releaseGate], {
        cwd: projectRoot,
        env: {
          ...process.env,
          PATH: `${tempRoot}:${process.env.PATH}`,
          RELEASE_E2E_PROJECT_ROOT: projectRoot,
          RELEASE_E2E_PLAYWRIGHT_VERSIONS: "1.56.1",
        },
        encoding: "utf8",
        stdio: ["ignore", "pipe", "pipe"],
      });

      assert.fail("expected concurrency verification to fail");
    } catch (error) {
      const output = `${error.stdout ?? ""}${error.stderr ?? ""}`;
      assert.equal(error.status, 23, output);
      assert.match(
        output,
        /release gate application failures: first=23 second=23/,
      );
      assert.match(output, /fixture concurrency diagnostics failed/);
    } finally {
      fs.rmSync(tempRoot, { recursive: true, force: true });
    }
  },
);

testAcrossSupportedPosixShells(
  "preserves the browser installation failure status and message",
  (shell) => {
    const failureMessage = "release gate browser setup fixture failed";

    try {
      execFileSync(shell, [browserInstaller], {
        cwd: projectRoot,
        env: {
          ...process.env,
          RELEASE_E2E_BROWSER_INSTALL_COMMAND: `printf '%s\\n' '${failureMessage}' >&2; exit 23`,
        },
        encoding: "utf8",
        stdio: ["ignore", "pipe", "pipe"],
      });

      assert.fail("expected browser installation to fail");
    } catch (error) {
      const output = `${error.stdout ?? ""}${error.stderr ?? ""}`;
      assert.equal(error.status, 23, output);
      assert.match(output, new RegExp(escapeRegExp(failureMessage)));
    }
  },
);

test("accepts matching package, lockfile, and documented metadata", () => {
  const result = runReleaseGate("matching", {
    RELEASE_E2E_SKIP_COMPATIBILITY_PROBES: "1",
  });

  assert.equal(result.status, 0, result.output);
  assert.match(
    result.output,
    /release gate Playwright compatibility metadata: documented set matches package minimum 1\.56\.1 and lockfile-resolved version 1\.62\.1/,
  );
});

test("accepts a valid semver prerelease before compatibility probes", () => {
  const result = runReleaseGate("valid-prerelease", {
    RELEASE_E2E_DOCUMENTED_PLAYWRIGHT_VERSIONS: "1.62.1",
    RELEASE_E2E_SKIP_COMPATIBILITY_PROBES: "1",
  });

  assert.equal(result.status, 0, result.output);
  assert.match(
    result.output,
    /release gate Playwright compatibility metadata: documented set matches package minimum 1\.62\.1 and lockfile-resolved version 1\.62\.1/,
  );
  assert.match(
    result.output,
    /release gate Playwright compatibility probes: skipped by test fixture/,
  );
});

test("accepts a valid pnpm peer-context suffix before compatibility probes", () => {
  const result = runReleaseGate("valid-peer-context", {
    RELEASE_E2E_DOCUMENTED_PLAYWRIGHT_VERSIONS: "1.56.1 1.62.1",
    RELEASE_E2E_SKIP_COMPATIBILITY_PROBES: "1",
  });

  assert.equal(result.status, 0, result.output);
  assert.match(
    result.output,
    /release gate Playwright compatibility metadata: documented set matches package minimum 1\.56\.1 and lockfile-resolved version 1\.62\.1/,
  );
  assert.match(
    result.output,
    /release gate Playwright compatibility probes: skipped by test fixture/,
  );
});

for (const [fixtureName, version] of [
  ["generated-1.56.1", "1.56.1"],
  ["generated-1.62.1", "1.62.1"],
]) {
  test(`accepts pnpm-generated ${version} metadata before compatibility probes`, () => {
    const result = runReleaseGate(fixtureName, {
      RELEASE_E2E_DOCUMENTED_PLAYWRIGHT_VERSIONS: version,
      RELEASE_E2E_SKIP_COMPATIBILITY_PROBES: "1",
    });

    assert.equal(result.status, 0, result.output);
    assert.match(
      result.output,
      new RegExp(
        `release gate Playwright compatibility metadata: documented set matches package minimum ${version} and lockfile-resolved version ${version}`,
      ),
    );
    assert.match(
      result.output,
      /release gate Playwright compatibility probes: skipped by test fixture/,
    );
  });
}

for (const fixtureName of [
  "valid-scoped-peer-context",
  "valid-repeated-peer-context",
  "valid-nested-peer-context",
]) {
  test(`accepts ${fixtureName} before compatibility probes`, () => {
    const result = runReleaseGate(fixtureName, {
      RELEASE_E2E_DOCUMENTED_PLAYWRIGHT_VERSIONS: "1.56.1 1.62.1",
      RELEASE_E2E_SKIP_COMPATIBILITY_PROBES: "1",
    });

    assert.equal(result.status, 0, result.output);
    assert.match(
      result.output,
      /release gate Playwright compatibility metadata: documented set matches package minimum 1\.56\.1 and lockfile-resolved version 1\.62\.1/,
    );
    assert.match(
      result.output,
      /release gate Playwright compatibility probes: skipped by test fixture/,
    );
  });
}

function escapeRegExp(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

for (const [fixtureName, descriptor] of [
  ["malformed-peer-context", "(typescript@5.9.3"],
  ["empty-peer-context", "()"],
  ["malformed-peer-descriptor", "(typescript)"],
  [
    "malformed-nested-peer-context",
    "(typescript@5.9.3(@types/node@22.10.0)",
  ],
  [
    "malformed-repeated-peer-descriptor",
    "(typescript@5.9.3)(react@19.1.0",
  ],
]) {
  test(`rejects ${fixtureName} before compatibility probes`, () => {
    const { marker, environment } = probeMarkerEnvironment();
    const result = runReleaseGate(fixtureName, environment);

    assert.notEqual(result.status, 0, result.output);
    assert.match(
      result.output,
      new RegExp(
        `release gate Playwright compatibility failed: pnpm-lock\\.yaml has malformed root @playwright/test resolved version \\(1\\.62\\.1${escapeRegExp(descriptor)}\\)`,
      ),
    );
    assert.match(
      result.output,
      /release gate Playwright compatibility remediation: run pnpm install to restore a valid root @playwright\/test resolved version/,
    );
    assert.equal(fs.existsSync(marker), false);
  });
}

test("rejects stale documented versions before compatibility probes", () => {
  const { marker, environment } = probeMarkerEnvironment();
  const result = runReleaseGate("stale-documented-versions", {
    ...environment,
    RELEASE_E2E_DOCUMENTED_PLAYWRIGHT_VERSIONS: "1.56.1 1.61.0",
  });

  assert.notEqual(result.status, 0, result.output);
  assert.match(
    result.output,
    /release gate Playwright compatibility failed: documented compatibility set is stale/,
  );
  assert.match(
    result.output,
    /release gate Playwright compatibility remediation: update documented_playwright_versions .* package minimum and lockfile-resolved version/,
  );
  assert.equal(fs.existsSync(marker), false);
});

test("rejects a missing root package importer before compatibility probes", () => {
  const { marker, environment } = probeMarkerEnvironment();
  const result = runReleaseGate("missing-root-importer", environment);

  assert.notEqual(result.status, 0, result.output);
  assert.match(
    result.output,
    /release gate Playwright compatibility failed: pnpm-lock\.yaml has no root @playwright\/test importer/,
  );
  assert.match(
    result.output,
    /release gate Playwright compatibility remediation: run pnpm install, then review documented_playwright_versions/,
  );
  assert.equal(fs.existsSync(marker), false);
});

test("rejects a root importer missing the Playwright specifier before compatibility probes", () => {
  const { marker, environment } = probeMarkerEnvironment();
  const result = runReleaseGate("missing-root-specifier", environment);

  assert.notEqual(result.status, 0, result.output);
  assert.match(
    result.output,
    /release gate Playwright compatibility failed: pnpm-lock\.yaml has incomplete root @playwright\/test importer metadata \(missing specifier\)/,
  );
  assert.match(
    result.output,
    /release gate Playwright compatibility remediation: run pnpm install to restore the root @playwright\/test specifier and resolved version/,
  );
  assert.equal(fs.existsSync(marker), false);
});

test("rejects a root importer missing the Playwright resolved version before compatibility probes", () => {
  const { marker, environment } = probeMarkerEnvironment();
  const result = runReleaseGate("missing-root-version", environment);

  assert.notEqual(result.status, 0, result.output);
  assert.match(
    result.output,
    /release gate Playwright compatibility failed: pnpm-lock\.yaml has incomplete root @playwright\/test importer metadata \(missing resolved version\)/,
  );
  assert.match(
    result.output,
    /release gate Playwright compatibility remediation: run pnpm install to restore the root @playwright\/test specifier and resolved version/,
  );
  assert.equal(fs.existsSync(marker), false);
});

test("rejects a malformed root Playwright resolved version before compatibility probes", () => {
  const { marker, environment } = probeMarkerEnvironment();
  const result = runReleaseGate("malformed-root-version", environment);

  assert.notEqual(result.status, 0, result.output);
  assert.match(
    result.output,
    /release gate Playwright compatibility failed: pnpm-lock\.yaml has malformed root @playwright\/test resolved version \(not-a-version\)/,
  );
  assert.match(
    result.output,
    /release gate Playwright compatibility remediation: run pnpm install to restore a valid root @playwright\/test resolved version/,
  );
  assert.equal(fs.existsSync(marker), false);
});

test("rejects a package without a semver-based range before compatibility probes", () => {
  const { marker, environment } = probeMarkerEnvironment();
  const result = runReleaseGate("malformed-package-range", environment);

  assert.notEqual(result.status, 0, result.output);
  assert.match(
    result.output,
    /release gate Playwright compatibility failed: package\.json has no semver-based @playwright\/test version range/,
  );
  assert.match(
    result.output,
    /release gate Playwright compatibility remediation: set devDependencies\["@playwright\/test"\] to a semver-based range .* then run pnpm install/,
  );
  assert.equal(fs.existsSync(marker), false);
});

test("rejects package and lockfile disagreement before compatibility probes", () => {
  const { marker, environment } = probeMarkerEnvironment();
  const result = runReleaseGate("package-lock-disagreement", environment);

  assert.notEqual(result.status, 0, result.output);
  assert.match(
    result.output,
    /release gate Playwright compatibility failed: package\.json and pnpm-lock\.yaml disagree about @playwright\/test/,
  );
  assert.match(
    result.output,
    /release gate Playwright compatibility remediation: run pnpm install to refresh pnpm-lock\.yaml, then update documented_playwright_versions if the resolved version changed/,
  );
  assert.equal(fs.existsSync(marker), false);
});

test("keeps the controlled mobile diagnostics upload scoped to its probe failure", () => {
  const workflow = fs.readFileSync(releaseWorkflow, "utf8");
  const regularMobileStep = workflowStep(
    workflow,
    "Run mobile transaction flow",
  );
  const controlledProbeStep = workflowStep(
    workflow,
    "Verify controlled mobile failure diagnostics",
  );
  const uploadStep = workflowStep(
    workflow,
    "Upload controlled mobile failure diagnostics",
  );

  assert.equal(
    regularMobileStep,
    "      - name: Run mobile transaction flow\n" +
      "        run: pnpm run test:e2e:release:mobile\n",
    "the normal mobile release step must remain unchanged",
  );
  const regularMobileStepStart = workflow.indexOf(
    "      - name: Run mobile transaction flow",
  );
  const controlledProbeStepStart = workflow.indexOf(
    "      - name: Verify controlled mobile failure diagnostics",
  );
  const uploadStepStart = workflow.indexOf(
    "      - name: Upload controlled mobile failure diagnostics",
  );
  assert.ok(
    regularMobileStepStart < controlledProbeStepStart &&
      controlledProbeStepStart < uploadStepStart,
    "diagnostics must follow the normal release step and controlled probe",
  );
  assert.match(
    controlledProbeStep,
    /\n        id: verify-controlled-mobile-failure\n/,
  );

  const capturedReport = controlledProbeStep.match(
    /\n          report="([^"]+)"\n/,
  );
  assert.ok(capturedReport, "controlled probe must capture a report path");
  assert.equal(
    capturedReport[1],
    "$RUNNER_TEMP/mobile-transaction-failure-report.log",
  );

  const uploadedReport = uploadStep.match(/\n          path: (.+)\n/);
  assert.ok(uploadedReport, "diagnostics upload must specify a report path");
  assert.equal(
    uploadedReport[1],
    "${{ runner.temp }}/mobile-transaction-failure-report.log",
  );
  assert.equal(
    capturedReport[1].replace("$RUNNER_TEMP", "${{ runner.temp }}"),
    uploadedReport[1],
    "upload must use the report captured by the controlled probe",
  );

  assert.match(
    uploadStep,
    /\n        if: \$\{\{ failure\(\) && steps\.verify-controlled-mobile-failure\.outcome == 'failure' \}\}\n/,
  );
  assert.match(uploadStep, /\n        uses: actions\/upload-artifact@v4\n/);
  assert.doesNotMatch(
    uploadStep,
    /\n        continue-on-error:/,
    "diagnostics upload must not change the release result",
  );
});
