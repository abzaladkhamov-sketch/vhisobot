const assert = require("node:assert/strict");
const { execFileSync } = require("node:child_process");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const test = require("node:test");

const projectRoot = path.resolve(__dirname, "../..");
const mobileTransactionCheck = path.join(
  projectRoot,
  "scripts/run-mobile-transaction-check.sh",
);

function supportedPosixShells() {
  return ["sh", "dash", "bash"].filter((shell) => {
    try {
      execFileSync("sh", ["-c", `command -v ${shell}`], {
        stdio: "ignore",
      });
      return true;
    } catch {
      return false;
    }
  });
}

function testAcrossSupportedPosixShells(name, callback) {
  for (const shell of supportedPosixShells()) {
    test(`${name} under ${shell}`, () => callback(shell));
  }
}

function createFakePython(tempRoot) {
  const fakePython = path.join(tempRoot, "python");
  const fakePythonScript = [
    "#!/bin/sh",
    "set -eu",
    'printf "%s\\n" "fixture API diagnostics" >"$MOBILE_TRANSACTION_DIAGNOSTICS_DIR/api-server.log"',
    'printf "%s\\n" "fixture mobile diagnostics" >"$MOBILE_TRANSACTION_DIAGNOSTICS_DIR/mobile-server.log"',
    'exit "${RELEASE_MOBILE_TEST_STATUS:-17}"',
    "",
  ].join("\n");

  fs.writeFileSync(fakePython, fakePythonScript, { mode: 0o755 });
  return fakePython;
}

function createFailingCat(tempRoot) {
  const fakeCat = path.join(tempRoot, "cat");
  const fakeCatScript = [
    "#!/bin/sh",
    'case "$1" in',
    "  */api-server.log|*/mobile-server.log)",
    '    printf "%s\\n" "fixture diagnostic reader failed" >&2',
    "    exit 91",
    "    ;;",
    "  *)",
    '    exec /bin/cat "$@"',
    "    ;;",
    "esac",
    "",
  ].join("\n");

  fs.writeFileSync(fakeCat, fakeCatScript, { mode: 0o755 });
  return fakeCat;
}

function runMobileTransactionCheck(shell, environment) {
  try {
    const stdout = execFileSync(shell, [mobileTransactionCheck], {
      cwd: projectRoot,
      env: {
        ...process.env,
        DATABASE_URL: "postgresql://release-gate-fixture",
        ...environment,
      },
      encoding: "utf8",
      stdio: ["ignore", "pipe", "pipe"],
    });
    return { status: 0, output: stdout };
  } catch (error) {
    return {
      status: error.status ?? 1,
      output: `${error.stdout ?? ""}${error.stderr ?? ""}`,
    };
  }
}

testAcrossSupportedPosixShells(
  "shows API and mobile diagnostics after a failed transaction check",
  (shell) => {
    const tempRoot = fs.mkdtempSync(
      path.join(os.tmpdir(), "release-gate-mobile-check-test-"),
    );

    try {
      const result = runMobileTransactionCheck(shell, {
        RELEASE_PYTHON_BIN: createFakePython(tempRoot),
        RELEASE_MOBILE_TEST_STATUS: "17",
      });

      assert.equal(result.status, 17, result.output);
      assert.match(
        result.output,
        /release gate mobile PostgreSQL transaction flow failed with status 17/,
      );
      assert.match(
        result.output,
        /--- api-server diagnostics ---[\s\S]*fixture API diagnostics/,
      );
      assert.match(
        result.output,
        /--- mobile-server diagnostics ---[\s\S]*fixture mobile diagnostics/,
      );
    } finally {
      fs.rmSync(tempRoot, { recursive: true, force: true });
    }
  },
);

testAcrossSupportedPosixShells(
  "keeps a successful transaction check quiet",
  (shell) => {
    const tempRoot = fs.mkdtempSync(
      path.join(os.tmpdir(), "release-gate-mobile-check-test-"),
    );

    try {
      const result = runMobileTransactionCheck(shell, {
        RELEASE_PYTHON_BIN: createFakePython(tempRoot),
        RELEASE_MOBILE_TEST_STATUS: "0",
      });

      assert.equal(result.status, 0, result.output);
      assert.equal(
        result.output,
        "release gate: running mobile PostgreSQL transaction flow\n",
      );
    } finally {
      fs.rmSync(tempRoot, { recursive: true, force: true });
    }
  },
);

testAcrossSupportedPosixShells(
  "preserves the transaction failure status when diagnostics cannot be read",
  (shell) => {
    const tempRoot = fs.mkdtempSync(
      path.join(os.tmpdir(), "release-gate-mobile-check-test-"),
    );

    try {
      const fakePython = createFakePython(tempRoot);
      createFailingCat(tempRoot);
      const result = runMobileTransactionCheck(shell, {
        RELEASE_PYTHON_BIN: fakePython,
        RELEASE_MOBILE_TEST_STATUS: "37",
        PATH: `${tempRoot}:${process.env.PATH}`,
      });

      assert.equal(result.status, 37, result.output);
      assert.match(
        result.output,
        /release gate mobile PostgreSQL transaction flow failed with status 37/,
      );
      assert.match(result.output, /fixture diagnostic reader failed/);
    } finally {
      fs.rmSync(tempRoot, { recursive: true, force: true });
    }
  },
);