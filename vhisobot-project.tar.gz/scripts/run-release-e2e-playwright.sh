#!/bin/sh

set -eu

project_root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
playwright_cwd=${RELEASE_E2E_PLAYWRIGHT_CWD:-$project_root}
playwright_bin=${RELEASE_E2E_PLAYWRIGHT_BIN:-playwright}

cd "$playwright_cwd"
"$playwright_bin" "$@"
